--
-- PostgreSQL database dump
--

\restrict CAcqSgXkxBNyFYuZmh4uWDdhS4Ar6f5ZxdVXYp5Ddh5zMfFrFNUeJNSaNYEzVmk

-- Dumped from database version 16.12 (Debian 16.12-1.pgdg13+1)
-- Dumped by pg_dump version 16.12 (Debian 16.12-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: app
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO app;

--
-- Name: module_target; Type: TYPE; Schema: public; Owner: app
--

CREATE TYPE public.module_target AS ENUM (
    'SQUAT',
    'BENCH',
    'DEADLIFT',
    'OHP',
    'PULL',
    'CUSTOM'
);


ALTER TYPE public.module_target OWNER TO app;

--
-- Name: override_scope; Type: TYPE; Schema: public; Owner: app
--

CREATE TYPE public.override_scope AS ENUM (
    'PLAN',
    'WEEK',
    'SESSION',
    'EXERCISE'
);


ALTER TYPE public.override_scope OWNER TO app;

--
-- Name: plan_type; Type: TYPE; Schema: public; Owner: app
--

CREATE TYPE public.plan_type AS ENUM (
    'SINGLE',
    'COMPOSITE',
    'MANUAL'
);


ALTER TYPE public.plan_type OWNER TO app;

--
-- Name: program_type; Type: TYPE; Schema: public; Owner: app
--

CREATE TYPE public.program_type AS ENUM (
    'LOGIC',
    'MANUAL'
);


ALTER TYPE public.program_type OWNER TO app;

--
-- Name: session_status; Type: TYPE; Schema: public; Owner: app
--

CREATE TYPE public.session_status AS ENUM (
    'PLANNED',
    'DONE',
    'SKIPPED'
);


ALTER TYPE public.session_status OWNER TO app;

--
-- Name: visibility_type; Type: TYPE; Schema: public; Owner: app
--

CREATE TYPE public.visibility_type AS ENUM (
    'PUBLIC',
    'PRIVATE'
);


ALTER TYPE public.visibility_type OWNER TO app;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: app
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO app;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: app
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO app;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: app
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: exercise; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.exercise (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    category text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exercise OWNER TO app;

--
-- Name: exercise_alias; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.exercise_alias (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    exercise_id uuid NOT NULL,
    alias text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.exercise_alias OWNER TO app;

--
-- Name: generated_session; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.generated_session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    user_id text NOT NULL,
    session_key text NOT NULL,
    scheduled_at timestamp with time zone,
    status public.session_status DEFAULT 'PLANNED'::public.session_status NOT NULL,
    snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.generated_session OWNER TO app;

--
-- Name: migration_run_log; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.migration_run_log (
    id bigint NOT NULL,
    run_id text NOT NULL,
    runner text NOT NULL,
    host text,
    status text NOT NULL,
    error_code text,
    message text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    lock_wait_ms integer DEFAULT 0 NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.migration_run_log OWNER TO app;

--
-- Name: migration_run_log_id_seq; Type: SEQUENCE; Schema: public; Owner: app
--

CREATE SEQUENCE public.migration_run_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migration_run_log_id_seq OWNER TO app;

--
-- Name: migration_run_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app
--

ALTER SEQUENCE public.migration_run_log_id_seq OWNED BY public.migration_run_log.id;


--
-- Name: plan; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.plan (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    type public.plan_type NOT NULL,
    root_program_version_id uuid,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT plan_type_root_program_ck CHECK ((((type = ANY (ARRAY['SINGLE'::public.plan_type, 'MANUAL'::public.plan_type])) AND (root_program_version_id IS NOT NULL)) OR ((type = 'COMPOSITE'::public.plan_type) AND (root_program_version_id IS NULL))))
);


ALTER TABLE public.plan OWNER TO app;

--
-- Name: plan_module; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.plan_module (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    target public.module_target NOT NULL,
    program_version_id uuid NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plan_module OWNER TO app;

--
-- Name: plan_override; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.plan_override (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    scope public.override_scope NOT NULL,
    week_number integer,
    session_key text,
    patch jsonb NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT plan_override_session_key_ck CHECK (((scope <> 'SESSION'::public.override_scope) OR (session_key IS NOT NULL)))
);


ALTER TABLE public.plan_override OWNER TO app;

--
-- Name: plan_progress_event; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.plan_progress_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    log_id uuid,
    user_id text NOT NULL,
    event_type text NOT NULL,
    program_slug text NOT NULL,
    reason text,
    before_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    after_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plan_progress_event OWNER TO app;

--
-- Name: plan_runtime_state; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.plan_runtime_state (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id uuid NOT NULL,
    user_id text NOT NULL,
    engine_version integer DEFAULT 1 NOT NULL,
    state jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plan_runtime_state OWNER TO app;

--
-- Name: program_template; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.program_template (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    type public.program_type NOT NULL,
    visibility public.visibility_type DEFAULT 'PUBLIC'::public.visibility_type NOT NULL,
    description text,
    tags text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    owner_user_id text,
    parent_template_id uuid,
    CONSTRAINT program_template_private_owner_ck CHECK (((visibility <> 'PRIVATE'::public.visibility_type) OR (owner_user_id IS NOT NULL)))
);


ALTER TABLE public.program_template OWNER TO app;

--
-- Name: program_version; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.program_version (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_id uuid NOT NULL,
    version integer NOT NULL,
    changelog text,
    definition jsonb NOT NULL,
    defaults jsonb,
    is_deprecated boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    parent_version_id uuid
);


ALTER TABLE public.program_version OWNER TO app;

--
-- Name: seed_run_state; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.seed_run_state (
    seed_key text NOT NULL,
    seed_hash text NOT NULL,
    tracked_files jsonb DEFAULT '[]'::jsonb NOT NULL,
    runner text NOT NULL,
    host text,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.seed_run_state OWNER TO app;

--
-- Name: stats_cache; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.stats_cache (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    metric text NOT NULL,
    params_hash text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stats_cache OWNER TO app;

--
-- Name: user_setting; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.user_setting (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_setting OWNER TO app;

--
-- Name: ux_event_log; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.ux_event_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    client_event_id text NOT NULL,
    name text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    props jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ux_event_log OWNER TO app;

--
-- Name: workout_log; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.workout_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    plan_id uuid,
    generated_session_id uuid,
    performed_at timestamp with time zone DEFAULT now() NOT NULL,
    duration_minutes integer,
    notes text,
    tags text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workout_log OWNER TO app;

--
-- Name: workout_set; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.workout_set (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    log_id uuid NOT NULL,
    exercise_name text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    set_number integer DEFAULT 1 NOT NULL,
    reps integer,
    weight_kg numeric(8,2),
    rpe integer,
    is_extra boolean DEFAULT false NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    exercise_id uuid
);


ALTER TABLE public.workout_set OWNER TO app;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: app
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Name: migration_run_log id; Type: DEFAULT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.migration_run_log ALTER COLUMN id SET DEFAULT nextval('public.migration_run_log_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: app
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	839aef54054677fced2ba63987f88e9a718d3a8078dd61a5942d33d5a3ef464c	1771555615560
2	73c4eb44dec43e4f1f597b27554131e72cbde3805e3c4c5c918e0e0ca34d63f4	1771556861977
3	08ec26532a9e59506f5aaba618a35fdd7c97315704c277c3be24ff4ebce63544	1771561354203
4	92e30747781a0c9642855f2d83283d3806459ccebe1ce7d0e8b2be0cc562e905	1771564079421
5	ea32f549cfd2e7dedb4213ccca5dbe9c4adbfcb38a489be5c6ddf7b4d9785f68	1771569000000
6	6dacf428706ed67ea3de08f196d7f34ce92bc1d81d55dd6363409af683e9aab3	1771573200000
7	eb4188f2e12cc3a95e67e89834c3a7d0c99bf0b2a0083a9b42a812ca1b7fda44	1771576800000
8	a59498e05c13e8e4c0e1c08bb6915bc5e7ac902a460f893da9bde79244fa40d0	1771580400000
9	4e6e07e9528a039bad3d822675924cdda81bd8c8a21d33810dd45a22469b3fc5	1771584000000
10	bc311d4b433024c87aef185ee7c4744a6edd007e350c7e0722a4f1440d7adafb	1771587600000
11	683de2a05de3b2b463459e529e077f3ca07e825d745f4430b9c2152de6629630	1771591200000
12	8f618182648924ac2f19bd78c39dae4690f427dcae61b1c78462dbb299d13c4d	1772507222306
13	60b5c3951240a2e6d8619d897638d016e57f6d472562f712333c0f363c58430a	1772607952058
\.


--
-- Data for Name: exercise; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.exercise (id, name, category, created_at) FROM stdin;
4a8f963f-3d37-4245-9954-988f92d83f71	Back Squat	Legs	2026-03-06 07:04:44.812381+00
b61c9129-a96b-46cf-9e13-4ce0a67615f8	Bench Press	Chest	2026-03-06 07:04:44.839341+00
a293c633-5a9c-4126-9914-c4912186f6b7	Deadlift	Back	2026-03-06 07:04:44.848481+00
bf1a2647-545f-4bdf-b689-e7285bd9dc06	Overhead Press	Shoulder	2026-03-06 07:04:44.855098+00
d241071c-7730-405b-987e-247d30423fe8	Barbell Row	Back	2026-03-06 07:04:44.864626+00
e5c786ba-7020-4f4c-a533-edbff0ce3413	Pull-Up	Back	2026-03-06 07:04:44.871262+00
92776271-926e-4c9d-bd0b-b0ba8a5bff39	Power Clean	Olympic Lift	2026-03-06 07:04:44.878111+00
2b04f390-9a56-4f79-b8bd-30d5650f6b7b	Front Squat	Legs	2026-03-06 07:04:44.886428+00
514eba59-1be9-467c-ae1c-53cc9f4b4570	Incline Bench Press	Chest	2026-03-06 07:04:44.892898+00
62bd3e88-b04c-4428-b573-d412a3fcd1ce	Romanian Deadlift	Legs	2026-03-06 07:04:44.896664+00
d377bf2c-22ce-41c6-959b-74ef42916150	Leg Press	Legs	2026-03-06 07:04:44.901816+00
74ee82c9-0337-432c-ac2c-bee4250588a9	Lat Pulldown	Back	2026-03-06 07:04:44.90524+00
858b79bc-c7fb-44b3-988c-6b285888fdd4	Dumbbell Shoulder Press	Shoulder	2026-03-06 07:04:44.911253+00
33d300a0-a337-4375-a387-d8d92ff60ed1	Hip Thrust	Glute	2026-03-06 07:04:44.918177+00
\.


--
-- Data for Name: exercise_alias; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.exercise_alias (id, exercise_id, alias, created_at) FROM stdin;
eff176f1-6f58-40d5-9c1e-b7c19a326a17	4a8f963f-3d37-4245-9954-988f92d83f71	Squat	2026-03-06 07:04:44.815161+00
7038fe8a-42de-4d2c-b6fc-7f2684936096	4a8f963f-3d37-4245-9954-988f92d83f71	스쿼트	2026-03-06 07:04:44.836482+00
869997c9-9773-46c2-833f-777bff5bb0f0	b61c9129-a96b-46cf-9e13-4ce0a67615f8	Bench	2026-03-06 07:04:44.842301+00
073083de-a0b6-417b-a744-2a7bfad84243	b61c9129-a96b-46cf-9e13-4ce0a67615f8	벤치프레스	2026-03-06 07:04:44.844863+00
415374e3-142e-48e9-89ac-fb28d2ac464f	a293c633-5a9c-4126-9914-c4912186f6b7	DL	2026-03-06 07:04:44.851114+00
f70551b1-96b4-4924-b4bc-9135fcd8b65d	a293c633-5a9c-4126-9914-c4912186f6b7	데드리프트	2026-03-06 07:04:44.853141+00
4f18d7f1-6773-49a0-adce-022ba50b46c2	bf1a2647-545f-4bdf-b689-e7285bd9dc06	OHP	2026-03-06 07:04:44.857061+00
68b5b38d-ff1c-4e6e-8947-d19fef4c311b	bf1a2647-545f-4bdf-b689-e7285bd9dc06	Press	2026-03-06 07:04:44.858917+00
2b33560f-7961-42da-b8a7-b31d2954fc03	bf1a2647-545f-4bdf-b689-e7285bd9dc06	밀리터리 프레스	2026-03-06 07:04:44.86201+00
5f7f1e65-5923-4f99-9efc-5b3a4c50307b	d241071c-7730-405b-987e-247d30423fe8	BB Row	2026-03-06 07:04:44.86668+00
97752f99-b749-4013-92f2-ab72080349bd	d241071c-7730-405b-987e-247d30423fe8	바벨 로우	2026-03-06 07:04:44.868758+00
5a221d7c-da97-403b-94e8-b6090e6cb58f	e5c786ba-7020-4f4c-a533-edbff0ce3413	풀업	2026-03-06 07:04:44.873468+00
045fbc97-e105-425d-baf2-accbce98f75f	e5c786ba-7020-4f4c-a533-edbff0ce3413	턱걸이	2026-03-06 07:04:44.875446+00
82ba3ab9-ef2b-448b-887a-102359d14038	92776271-926e-4c9d-bd0b-b0ba8a5bff39	Clean	2026-03-06 07:04:44.880151+00
e12136a4-fc63-4333-9abb-2e528eff5eeb	92776271-926e-4c9d-bd0b-b0ba8a5bff39	파워 클린	2026-03-06 07:04:44.882518+00
6c6ec2d4-d0d4-4cf7-8eb4-518efd6b5687	92776271-926e-4c9d-bd0b-b0ba8a5bff39	파워클린	2026-03-06 07:04:44.884396+00
5b85363b-b4ea-412f-b0e0-d6d70cfaee87	2b04f390-9a56-4f79-b8bd-30d5650f6b7b	FSQ	2026-03-06 07:04:44.888412+00
3598337b-b15e-475d-8363-5e1853f73a3e	2b04f390-9a56-4f79-b8bd-30d5650f6b7b	프론트 스쿼트	2026-03-06 07:04:44.890767+00
3bec6e44-e8b4-47f6-9918-1c3a4ebd5db3	514eba59-1be9-467c-ae1c-53cc9f4b4570	인클라인 벤치	2026-03-06 07:04:44.894706+00
7b96a6ed-2abe-4b40-9a71-4c8ae6c8dbf5	62bd3e88-b04c-4428-b573-d412a3fcd1ce	RDL	2026-03-06 07:04:44.898462+00
353f9655-cb73-4c64-b282-f08d03afbb8e	62bd3e88-b04c-4428-b573-d412a3fcd1ce	루마니안 데드리프트	2026-03-06 07:04:44.900001+00
1826ae25-db08-46a5-8ca0-ffa0da4e4598	d377bf2c-22ce-41c6-959b-74ef42916150	레그 프레스	2026-03-06 07:04:44.90348+00
a21d938f-3fe6-4622-bd39-3edda7dd5633	74ee82c9-0337-432c-ac2c-bee4250588a9	랫풀다운	2026-03-06 07:04:44.907107+00
e8453940-05dc-403a-9136-7bcb2f9b27af	74ee82c9-0337-432c-ac2c-bee4250588a9	Lat Pull	2026-03-06 07:04:44.909091+00
a91b6d49-aa49-4b38-b890-a3b32294f10a	858b79bc-c7fb-44b3-988c-6b285888fdd4	덤벨 숄더 프레스	2026-03-06 07:04:44.912987+00
1764db75-1777-4834-9aef-c3570166a371	858b79bc-c7fb-44b3-988c-6b285888fdd4	DB Shoulder Press	2026-03-06 07:04:44.915918+00
9ec52139-cadf-4872-b073-b559bb6c9492	33d300a0-a337-4375-a387-d8d92ff60ed1	힙 쓰러스트	2026-03-06 07:04:44.920175+00
\.


--
-- Data for Name: generated_session; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.generated_session (id, plan_id, user_id, session_key, scheduled_at, status, snapshot, created_at, updated_at) FROM stdin;
ea4ea385-f20e-4cfc-97f5-d8f8b7aaa89a	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-08@C1W1D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-08@C1W1D1", "accessories": [], "sessionDate": "2026-03-08", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-08 09:38:01.783271+00	2026-03-08 09:38:01.783271+00
f823aa7a-6017-48ee-be89-667b6ab687f1	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-08@C1W1D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-08@C1W1D2", "accessories": [], "sessionDate": "2026-03-08", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-08 10:25:23.205734+00	2026-03-08 14:37:00.36+00
7df44e90-073e-456e-adb8-5c31aac9c78c	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-09@C1W1D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-09@C1W1D2", "accessories": [], "sessionDate": "2026-03-09", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-08 15:39:10.957715+00	2026-03-09 13:50:54.144+00
677b7ff5-d4d7-4828-81da-6acfe70983d7	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-10@C1W1D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-10@C1W1D2", "accessories": [], "sessionDate": "2026-03-10", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-09 09:28:17.694839+00	2026-03-10 11:58:02.354+00
9c72d990-284b-43d1-8d68-5a80015ec6ce	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-10@C1W1D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-10@C1W1D3", "accessories": [], "sessionDate": "2026-03-10", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-10 12:20:32.995108+00	2026-03-10 14:20:31.322+00
61793bcf-e95a-493a-aaf5-d59473dae0bf	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-11@C1W1D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-11@C1W1D3", "accessories": [], "sessionDate": "2026-03-11", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-11 04:42:13.166362+00	2026-03-11 14:51:16.102+00
103540ca-f074-47a9-a41b-f49fe4d88754	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-12@C1W1D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-12@C1W1D3", "accessories": [], "sessionDate": "2026-03-12", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-11 16:09:04.236967+00	2026-03-12 14:14:11.583+00
284dab63-f451-4680-8aec-308961e66e3e	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-13@C1W1D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-13@C1W1D3", "accessories": [], "sessionDate": "2026-03-13", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-12 15:28:20.322007+00	2026-03-13 14:19:35.979+00
c928d55e-0b77-4a09-ae4c-0c7550053f74	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-14@C1W1D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-14@C1W1D3", "accessories": [], "sessionDate": "2026-03-14", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-13 15:00:53.764325+00	2026-03-14 14:31:25.106+00
74eb2208-d302-41f0-b6ad-c9c7b6287e2c	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-15@C1W1D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 1, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 70}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}, {"note": "Operator W1", "reps": 5, "percent": 0.7, "targetWeightKg": 67.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-15@C1W1D3", "accessories": [], "sessionDate": "2026-03-15", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-14 15:07:36.533076+00	2026-03-15 09:42:10.286+00
37d57f8b-d79a-4042-8d18-087c76c1ae30	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-15@C1W2D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-15@C1W2D1", "accessories": [], "sessionDate": "2026-03-15", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-15 10:00:39.23805+00	2026-03-15 12:49:27.749+00
88c64956-9cde-49da-b038-bbabc2efa008	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-18@C1W2D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-18@C1W2D2", "accessories": [], "sessionDate": "2026-03-18", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-18 04:25:40.864732+00	2026-03-18 14:26:37.303+00
3a4f7c2f-37ad-4aac-a94c-4f4ec25f147a	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-16@C1W2D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-16@C1W2D1", "accessories": [], "sessionDate": "2026-03-16", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-15 15:33:32.086727+00	2026-03-16 14:56:24.958+00
0bf9aeab-d45a-4724-920f-823acd336c27	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-17@C1W2D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-17@C1W2D2", "accessories": [], "sessionDate": "2026-03-17", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-17 13:17:29.457776+00	2026-03-17 13:33:46.537+00
0751fcc3-75ec-4f8d-b412-db0b7bf3efc6	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-17@C1W2D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-17@C1W2D1", "accessories": [], "sessionDate": "2026-03-17", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-17 03:21:56.578947+00	2026-03-17 12:24:22.307+00
b2ef15c5-286c-4603-a6bf-66485093bf37	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-19@C1W2D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-19@C1W2D2", "accessories": [], "sessionDate": "2026-03-19", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-18 15:00:16.537107+00	2026-03-19 14:50:15.878+00
08a697d3-fb49-4566-a04a-ebf07b60e4dd	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-21@C1W2D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-21@C1W2D2", "accessories": [], "sessionDate": "2026-03-21", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-20 15:02:41.696088+00	2026-03-21 06:57:40.812+00
5127aac2-30f6-4c6d-b00a-36f343e1ada7	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-20@C1W2D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-20@C1W2D2", "accessories": [], "sessionDate": "2026-03-20", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-19 15:04:52.929747+00	2026-03-20 14:53:10.468+00
c25300bf-0d67-4f03-ada2-edb594aad713	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-21@C1W2D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-21@C1W2D3", "accessories": [], "sessionDate": "2026-03-21", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-21 07:42:11.471663+00	2026-03-21 14:39:01.042+00
23395dd9-9df3-4c64-af21-57c2e6a95f5c	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-24@C1W3D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-24@C1W3D1", "accessories": [], "sessionDate": "2026-03-24", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-23 13:43:27.439613+00	2026-03-24 14:20:31.34+00
1f8240c2-55c2-41aa-924d-d34808fd23a2	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-23@C1W3D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-23@C1W3D1", "accessories": [], "sessionDate": "2026-03-23", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-23 13:17:55.339243+00	2026-03-23 14:09:45.903+00
0703dd2e-6dd0-4085-bb1f-d272b20e6713	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-22@C1W2D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-22@C1W2D3", "accessories": [], "sessionDate": "2026-03-22", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-21 15:26:45.843551+00	2026-03-22 14:51:29.091+00
d1586b10-9fd0-4cd8-917b-4aece4768d2c	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-23@C1W2D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 2, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 80}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}, {"note": "Operator W2", "reps": 5, "percent": 0.8, "targetWeightKg": 75}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-23@C1W2D3", "accessories": [], "sessionDate": "2026-03-23", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-22 15:11:17.518572+00	2026-03-23 12:28:50.385+00
42d39246-9ad8-40f4-b592-b1180eb6edfa	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-25@C1W3D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-25@C1W3D1", "accessories": [], "sessionDate": "2026-03-25", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-24 15:33:50.298116+00	2026-03-25 14:31:06.5+00
3c44f99c-17dd-4b5f-b890-6c30effe0850	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-27@C1W3D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-27@C1W3D2", "accessories": [], "sessionDate": "2026-03-27", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-27 07:39:11.183136+00	2026-03-27 12:30:00.165+00
6919af8b-f664-4897-afa9-f94fbfca78f6	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-26@C1W3D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-26@C1W3D1", "accessories": [], "sessionDate": "2026-03-26", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-26 01:00:09.655669+00	2026-03-26 13:55:55.916+00
11d93a22-588c-4582-b52a-3fb4c91e95d1	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-26@C1W3D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-26@C1W3D2", "accessories": [], "sessionDate": "2026-03-26", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-26 13:56:29.50584+00	2026-03-26 13:56:29.50584+00
e4f04e41-ddea-4579-b7e8-3baf149f33e4	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-28@C1W3D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-28@C1W3D3", "accessories": [], "sessionDate": "2026-03-28", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-28 09:48:03.019807+00	2026-03-28 09:48:03.019807+00
8ce8f193-730d-4225-aba7-9f8e7f519742	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-28@C1W3D2	\N	PLANNED	{"day": 2, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-28@C1W3D2", "accessories": [], "sessionDate": "2026-03-28", "manualSession": {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D2", "overridesApplied": []}	2026-03-27 16:46:19.794661+00	2026-03-28 08:42:03.307+00
c10ec7f1-19a2-499b-a430-8b142cda7d40	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-29@C1W3D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-29@C1W3D3", "accessories": [], "sessionDate": "2026-03-29", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-29 06:35:00.367257+00	2026-03-29 14:53:00.292+00
685e18b8-6f42-4e01-91bb-ac1d3d040cb7	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-31@C1W4D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 4, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 75}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 75}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 75}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-31@C1W4D1", "accessories": [], "sessionDate": "2026-03-31", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-31 13:03:17.458849+00	2026-03-31 14:49:07.849+00
8f1be68e-a8f7-4737-96af-0453396eba81	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-30@C1W3D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-30@C1W3D3", "accessories": [], "sessionDate": "2026-03-30", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-29 15:11:00.73724+00	2026-03-30 12:56:45.719+00
9228d4ea-892c-436b-963c-133ec30d95d2	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-03-31@C1W3D3	\N	PLANNED	{"day": 3, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 3, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 90}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}, {"note": "Operator W3", "reps": 3, "percent": 0.9, "targetWeightKg": 85}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-03-31@C1W3D3", "accessories": [], "sessionDate": "2026-03-31", "manualSession": {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D3", "overridesApplied": []}	2026-03-31 04:18:09.243172+00	2026-03-31 12:04:57.625+00
2938c1b0-bb49-4923-90b9-d9b7872f710a	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	2026-04-03@C1W4D1	\N	PLANNED	{"day": 1, "plan": {"id": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "name": "Tactical Barbell Operator Custom Program", "type": "MANUAL"}, "week": 4, "program": {"name": "Tactical Barbell Operator Custom", "slug": "tactical-barbell-operator-custom-mmhk641d", "type": "MANUAL", "version": 1}, "timezone": "Asia/Seoul", "exercises": [{"role": "MAIN", "sets": [{"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}], "order": 0, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Back Squat", "progressionKey": "EX_BACK_SQUAT", "progressionTarget": "SQUAT", "sourceBlockTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 75}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 75}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 75}], "order": 1, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Pull-Up", "progressionKey": "EX_PULL_UP", "progressionTarget": "PULL", "sourceBlockTarget": "PULL"}, {"role": "MAIN", "sets": [{"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}, {"note": "Operator W4", "reps": 5, "percent": 0.75, "targetWeightKg": 72.5}], "order": 2, "rowType": "AUTO", "exerciseId": null, "exerciseName": "Bench Press", "progressionKey": "EX_BENCH_PRESS", "progressionTarget": "BENCH", "sourceBlockTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 3, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Deadlift", "progressionKey": null, "progressionTarget": "DEADLIFT", "sourceBlockTarget": "DEADLIFT"}, {"role": "MAIN", "sets": [{"reps": 5, "targetWeightKg": 0}], "order": 4, "rowType": "CUSTOM", "exerciseId": null, "exerciseName": "Overhead Press", "progressionKey": null, "progressionTarget": "OHP", "sourceBlockTarget": "OHP"}], "sessionKey": "2026-04-03@C1W4D1", "accessories": [], "sessionDate": "2026-04-03", "manualSession": {"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, "schemaVersion": 3, "manualSessionKey": "D1", "overridesApplied": []}	2026-03-31 14:46:01.700191+00	2026-03-31 14:46:01.700191+00
\.


--
-- Data for Name: migration_run_log; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.migration_run_log (id, run_id, runner, host, status, error_code, message, started_at, finished_at, lock_wait_ms, details) FROM stdin;
1	a0fe3545-dace-4ee0-befa-39b3d6957e37	compose-migrate-job	8ec3d9269d44	SUCCESS	\N	migrations applied	2026-02-26 09:12:52.037891+00	2026-02-26 09:12:52.417158+00	58	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 2010, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
2	3d1defdd-9f38-46ee-8d9e-769965b66777	compose-migrate-job	ca6e762b7803	SUCCESS	\N	migrations applied	2026-02-26 09:37:50.032827+00	2026-02-26 09:37:50.202075+00	5	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 764, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
3	f28ac04b-d1d6-4e8c-ac73-10737652893f	compose-migrate-job	8327fbfa0597	SUCCESS	\N	migrations applied	2026-02-27 01:49:09.955871+00	2026-02-27 01:49:10.451774+00	11	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1594, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
4	d4259233-8828-4213-8e91-6401724fe61f	compose-migrate-job	77cd5e4e6260	SUCCESS	\N	migrations applied	2026-02-27 02:23:31.593508+00	2026-02-27 02:23:31.91392+00	34	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1178, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
5	a38fce53-4a86-4ad0-83e2-68a308f31d4f	compose-migrate-job	91a5520d9705	SUCCESS	\N	migrations applied	2026-02-27 03:03:05.693894+00	2026-02-27 03:03:06.133986+00	57	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1003, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
6	8e4f913c-f228-482c-8d68-163a79cbfbe5	compose-migrate-job	b351f1e85b07	SUCCESS	\N	migrations applied	2026-02-27 03:12:31.799051+00	2026-02-27 03:12:31.956213+00	2	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 674, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
7	8cabb385-9c02-41a7-b5a4-12755b0697cb	compose-migrate-job	9f0fa77a58c4	SUCCESS	\N	migrations applied	2026-02-27 07:08:03.163414+00	2026-02-27 07:08:03.505425+00	7	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 802, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
8	a1db232c-af0d-4dfc-8f36-04b0a5b7e1ed	compose-migrate-job	d691d9a5fabe	SUCCESS	\N	migrations applied	2026-02-27 07:56:15.40704+00	2026-02-27 07:56:15.640707+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 446, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
9	9282e62c-918d-4e2e-979d-ee12eca91335	compose-migrate-job	79df55699ea1	SUCCESS	\N	migrations applied	2026-02-27 08:04:35.453147+00	2026-02-27 08:04:35.597131+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 829, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
10	3b6fff14-d936-4c9a-8e94-b8d82aeaedff	compose-migrate-job	03c42a3a94c3	SUCCESS	\N	migrations applied	2026-02-27 08:07:40.317236+00	2026-02-27 08:07:40.452257+00	1	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 642, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
11	707a7bc0-bfa0-44ec-acca-5b2a73a01e7d	compose-migrate-job	70f2b1e25ca4	SUCCESS	\N	migrations applied	2026-02-27 08:15:40.021595+00	2026-02-27 08:15:40.186737+00	26	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 870, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
12	c9048c74-a2d9-4e7e-9e56-79ebaa9b4464	compose-migrate-job	e5c89625d634	SUCCESS	\N	migrations applied	2026-02-27 08:23:49.96489+00	2026-02-27 08:23:50.168971+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 670, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
13	0d8da915-276f-4f42-9d9b-9427c912b21e	compose-migrate-job	d092b5da307e	SUCCESS	\N	migrations applied	2026-02-27 08:27:40.263587+00	2026-02-27 08:27:40.436176+00	2	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 526, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
14	1076d704-933a-4715-94d4-c5f8a21b21c3	compose-migrate-job	6136211d13c9	SUCCESS	\N	migrations applied	2026-02-27 08:45:05.364836+00	2026-02-27 08:45:05.672427+00	14	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1718, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
15	1392508f-94b8-496d-b82b-a9eb5e7bba2f	compose-migrate-job	de107b5d829b	SUCCESS	\N	migrations applied	2026-02-27 08:52:33.537956+00	2026-02-27 08:52:33.691609+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 701, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
16	da06089c-541b-4eb7-b831-56a0c2eea12d	compose-migrate-job	be51114658a5	SUCCESS	\N	migrations applied	2026-02-27 09:18:15.102858+00	2026-02-27 09:18:15.380371+00	1	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 719, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
17	88e887db-b958-4e7d-9dce-d9bcbd1270ae	compose-migrate-job	27c999575d9b	SUCCESS	\N	migrations applied	2026-02-28 08:08:11.811488+00	2026-02-28 08:08:12.223223+00	10	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1336, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
18	cddf5d67-8602-4922-bff5-f282442843ef	compose-migrate-job	b0d7b71c1825	SUCCESS	\N	migrations applied	2026-02-28 13:54:04.364103+00	2026-02-28 13:54:04.695436+00	67	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1037, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
19	ffe4beb5-1509-4494-a0d8-b6f3cb8351fb	compose-migrate-job	b5c05cf57e00	SUCCESS	\N	migrations applied	2026-03-03 03:35:01.9454+00	2026-03-03 03:35:03.282631+00	18	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 2978, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
20	c36d88e9-14ad-45fb-9f8a-ddc7a9fd7ff0	compose-migrate-job	c9bf07b7e486	SUCCESS	\N	migrations applied	2026-03-03 04:21:54.804719+00	2026-03-03 04:21:54.998388+00	2	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 813, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
21	7a59f9cb-1dd8-4a57-a237-e8eb94e66c4c	compose-migrate-job	da974288f7ac	SUCCESS	\N	migrations applied	2026-03-03 04:34:38.932425+00	2026-03-03 04:34:39.112147+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 409, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
22	fafc2914-dc67-460e-877b-f3df74bae3f6	compose-migrate-job	f92ce6921eef	SUCCESS	\N	migrations applied	2026-03-03 04:46:14.893652+00	2026-03-03 04:46:14.951999+00	1	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 432, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
23	a1c00472-098d-42c7-9738-490ce1007249	compose-migrate-job	2f38caba37f2	SUCCESS	\N	migrations applied	2026-03-03 05:37:10.933748+00	2026-03-03 05:37:11.253392+00	52	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1153, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
24	5d1cfbfc-3420-4efc-b899-07bf90a3144d	compose-migrate-job	1d4d13be86d6	SUCCESS	\N	migrations applied	2026-03-03 05:54:01.920774+00	2026-03-03 05:54:02.073126+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 291, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
25	eaa3866d-4747-4902-843e-455dea3f9131	compose-migrate-job	a2a4656b54d9	SUCCESS	\N	migrations applied	2026-03-03 06:09:26.188383+00	2026-03-03 06:09:26.477987+00	28	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 645, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
26	7bc6a19f-47f8-43a2-9377-692dfd25ba89	compose-migrate-job	62bfe8e36752	SUCCESS	\N	migrations applied	2026-03-03 08:16:17.106841+00	2026-03-03 08:16:17.469047+00	15	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1531, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
27	07c9f799-3f7c-48c7-8e16-38ece5375e77	compose-migrate-job	58651803d26f	SUCCESS	\N	migrations applied	2026-03-03 09:07:27.691376+00	2026-03-03 09:07:27.995885+00	11	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1189, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
28	49102d04-35e0-4054-979c-961cc0f5338b	compose-migrate-job	265c481fa595	SUCCESS	\N	migrations applied	2026-03-04 04:54:36.440905+00	2026-03-04 04:54:36.836683+00	15	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1102, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
29	3016afbc-146e-4ad4-ad41-2b0e917f9439	compose-migrate-job	4b824d959980	SUCCESS	\N	migrations applied	2026-03-04 05:10:44.691237+00	2026-03-04 05:10:45.0211+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 579, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
30	6902d760-7a6f-419e-8557-f8201001f077	compose-migrate-job	687277865c6e	SUCCESS	\N	migrations applied	2026-03-04 06:53:16.240907+00	2026-03-04 06:53:16.587873+00	85	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1224, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
31	e6b072ed-21a6-4a5b-93a1-bc61f7f1c03d	compose-migrate-job	d72eb854d0ce	SUCCESS	\N	migrations applied	2026-03-04 07:00:09.650553+00	2026-03-04 07:00:09.810688+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1582, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
32	5ea8ff7e-2b44-4fff-929d-144e57362707	compose-migrate-job	cd0f979ef961	SUCCESS	\N	migrations applied	2026-03-04 07:43:07.608313+00	2026-03-04 07:43:08.981045+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 2235, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
33	b0d64a26-3e5c-49dc-838d-cd8418f6bd8e	compose-migrate-job	6ffb335b01c5	SUCCESS	\N	migrations applied	2026-03-04 08:24:03.033972+00	2026-03-04 08:24:03.330488+00	15	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1038, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
34	db4fc6eb-f5f7-4ddd-9906-d1c52b95c24b	compose-migrate-job	d361b572cd9f	SUCCESS	\N	migrations applied	2026-03-04 08:26:35.41403+00	2026-03-04 08:26:35.546817+00	2	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 686, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
35	ccb72b08-b5d6-45e2-bec1-1765b1aebf49	compose-migrate-job	fa6f75619ffd	SUCCESS	\N	migrations applied	2026-03-04 08:33:22.058846+00	2026-03-04 08:33:22.419407+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1344, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
36	45e1e4e8-f09a-42cf-b5c2-f021605dcefe	compose-migrate-job	a3d492a43c1b	SUCCESS	\N	migrations applied	2026-03-04 08:42:11.29722+00	2026-03-04 08:42:11.401423+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 250, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
37	e01cbdfa-a7e4-4fb6-8c09-ce750f7e2c89	compose-migrate-job	b7d072fd9a9e	SUCCESS	\N	migrations applied	2026-03-04 08:42:37.248331+00	2026-03-04 08:42:37.358735+00	1	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 165, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
38	4dea6357-deb6-4d69-aaef-bb8823b0054e	compose-migrate-job	a03a51a768fd	SUCCESS	\N	migrations applied	2026-03-05 01:37:15.05258+00	2026-03-05 01:37:15.602054+00	81	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1828, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
39	aa6526d7-c47e-43ec-9b31-7302ad909ddd	compose-migrate-job	ab42b17e455d	SUCCESS	\N	migrations applied	2026-03-05 01:55:13.874984+00	2026-03-05 01:55:14.33709+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 796, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
40	adcb6a9f-a68c-4380-ac77-b944986c0845	compose-migrate-job	39a2893d3c8b	SUCCESS	\N	migrations applied	2026-03-05 06:40:17.88864+00	2026-03-05 06:40:18.382821+00	60	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1534, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
41	40e01109-e934-4934-a9b7-86ba849e816f	compose-migrate-job	6afe6e13689f	SUCCESS	\N	migrations applied	2026-03-06 06:47:18.038071+00	2026-03-06 06:47:18.398272+00	35	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1250, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
42	e03a79d2-b6a9-497a-9eef-10f3fc1ee3ce	compose-migrate-job	b3836addd647	SUCCESS	\N	migrations applied	2026-03-06 07:01:37.786904+00	2026-03-06 07:01:37.864374+00	5	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 888, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
43	2ec26ccc-0719-4cbe-a02e-f48d5c760e00	compose-migrate-job	84124ca1da3b	SUCCESS	\N	migrations applied	2026-03-07 05:23:10.383033+00	2026-03-07 05:23:12.378972+00	478	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 5372, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
44	995ad1e5-52a3-4755-aa88-5ec7421c26af	compose-migrate-job	e2489e76ebc1	SUCCESS	\N	migrations applied	2026-03-07 05:24:39.667616+00	2026-03-07 05:24:39.919416+00	1	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 931, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
45	cc455eaa-9652-44af-94cc-752e42f73abb	compose-migrate-job	57e5bd5550f7	SUCCESS	\N	migrations applied	2026-03-07 05:40:41.861852+00	2026-03-07 05:40:42.267116+00	28	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1202, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
46	102c2343-6d90-4814-a82f-93142bc4b471	compose-migrate-job	9baed22fb363	SUCCESS	\N	migrations applied	2026-03-07 06:02:32.648086+00	2026-03-07 06:02:32.979749+00	27	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 972, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
47	5366d8b2-c374-40d5-913e-10ad48891fe8	compose-migrate-job	c3c09d3fa05c	SUCCESS	\N	migrations applied	2026-03-07 06:12:20.185515+00	2026-03-07 06:12:20.434969+00	22	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 425, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
48	efcfa60e-68db-47ac-9f4b-d9f7fc57784e	compose-migrate-job	4c40b7a6d7a5	SUCCESS	\N	migrations applied	2026-03-07 06:22:53.641038+00	2026-03-07 06:22:53.925057+00	75	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 535, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
49	ed9a03d4-e154-43db-b0a4-a06ab854de6d	compose-migrate-job	f9907dff97bb	SUCCESS	\N	migrations applied	2026-03-07 07:35:00.654123+00	2026-03-07 07:35:01.18327+00	35	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1263, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
50	78acfb49-40a3-477f-908b-e1c3cfc8a3d6	compose-migrate-job	3ee8bc7333f0	SUCCESS	\N	migrations applied	2026-03-07 08:09:05.160472+00	2026-03-07 08:09:05.413065+00	24	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 980, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
51	fe54e0a6-c493-42e3-8cfe-23fcd0a12242	compose-migrate-job	c4194af8b375	SUCCESS	\N	migrations applied	2026-03-07 14:42:57.925711+00	2026-03-07 14:42:58.340868+00	46	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1628, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
52	2c08712a-d598-49b3-ba74-c2d4aa222d19	compose-migrate-job	597daa12c1c1	SUCCESS	\N	migrations applied	2026-03-07 15:21:00.877369+00	2026-03-07 15:21:01.183074+00	52	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1043, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
53	d5082405-5e21-452c-ac2a-a7cc2ef0c62d	compose-migrate-job	0d5e37d02597	SUCCESS	\N	migrations applied	2026-03-07 15:33:28.945116+00	2026-03-07 15:33:29.281011+00	25	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1630, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
54	4da6577d-e994-4c47-935f-0dd37da50eb3	compose-migrate-job	c2b6390c080c	SUCCESS	\N	migrations applied	2026-03-07 16:01:32.474004+00	2026-03-07 16:01:32.751388+00	56	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1240, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
55	4296078e-095c-48cb-81ae-50ee067d77b0	compose-migrate-job	ee18ca3e1f68	SUCCESS	\N	migrations applied	2026-03-07 17:15:05.995102+00	2026-03-07 17:15:06.378313+00	64	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1215, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
56	d25d0754-c6c5-4c24-929e-a6e1a7b20402	compose-migrate-job	3f24692402f3	SUCCESS	\N	migrations applied	2026-03-07 17:48:52.173219+00	2026-03-07 17:48:52.533165+00	21	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1356, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
57	f2e34c6a-a2cb-4d7f-b216-3521c8729dfb	compose-migrate-job	d2a8f89928a8	SUCCESS	\N	migrations applied	2026-03-08 07:36:34.378622+00	2026-03-08 07:36:34.845793+00	77	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1337, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
62	20fd52b8-5de8-4a17-b768-9e63d81b7e3b	compose-migrate-job	d79f5c4ee5c7	SUCCESS	\N	migrations applied	2026-03-09 03:33:35.794115+00	2026-03-09 03:33:36.08501+00	62	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1100, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
58	49966d60-1be6-4fa0-9565-a5ee06cb7be1	compose-migrate-job	6bdb2589a37e	SUCCESS	\N	migrations applied	2026-03-08 13:40:28.419646+00	2026-03-08 13:40:28.696105+00	33	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 797, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
63	f72f02dd-4f2f-4364-bf11-36c70013b598	compose-migrate-job	06e8dd577f15	SUCCESS	\N	migrations applied	2026-03-09 04:44:11.462187+00	2026-03-09 04:44:11.770983+00	26	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 828, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
59	3c42670b-1f28-41b6-a315-75e29f7a7ae6	compose-migrate-job	a8c2b96fb23f	SUCCESS	\N	migrations applied	2026-03-08 14:07:52.078485+00	2026-03-08 14:07:52.358316+00	31	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1167, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
64	e6b0abaf-a9c8-4de4-be9b-fd3e0a5529a9	compose-migrate-job	74bed490db91	SUCCESS	\N	migrations applied	2026-03-09 05:38:46.379002+00	2026-03-09 05:38:46.639871+00	23	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 824, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
60	04fe4e2a-31f0-4cf2-bee2-f02801edb19f	compose-migrate-job	b1a22acbecd2	SUCCESS	\N	migrations applied	2026-03-08 14:59:37.574367+00	2026-03-08 14:59:38.045463+00	65	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1573, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
135	a94ddbc5-d74a-408f-a944-ecb598878056	compose-migrate-job	b17a2ac2592c	SUCCESS	\N	migrations applied	2026-03-13 03:31:16.289865+00	2026-03-13 03:31:16.574242+00	33	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1001, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
61	8febfa86-5f58-4e77-8066-7bcd952f7304	compose-migrate-job	e092c4465553	SUCCESS	\N	migrations applied	2026-03-09 02:34:47.410907+00	2026-03-09 02:34:47.706422+00	10	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1020, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
65	771c6309-cf0a-4c40-9cc7-d1dd89eabfe9	compose-migrate-job	3dddca46ed8f	SUCCESS	\N	migrations applied	2026-03-09 06:31:48.698734+00	2026-03-09 06:31:49.073098+00	14	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1209, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
66	e8629ff2-92ca-4d7a-a881-8aa69122c418	compose-migrate-job	a9041c135a4a	SUCCESS	\N	migrations applied	2026-03-09 07:48:09.965902+00	2026-03-09 07:48:10.259002+00	23	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1021, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
67	ee2cbdc9-263e-474e-8f46-f40b4cfc4d2e	compose-migrate-job	563ef56f5cfc	SUCCESS	\N	migrations applied	2026-03-09 08:36:13.377477+00	2026-03-09 08:36:13.717118+00	32	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1453, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
68	b7e025ab-0dd3-4b84-b328-744d46a57a09	compose-migrate-job	b6eca12670b3	SUCCESS	\N	migrations applied	2026-03-09 08:47:48.544408+00	2026-03-09 08:47:48.739579+00	33	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 570, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
69	545a2063-04cb-498d-928f-d5b53f4de143	compose-migrate-job	b75e29264a9c	SUCCESS	\N	migrations applied	2026-03-09 09:00:05.066956+00	2026-03-09 09:00:05.310275+00	2	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1271, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
70	440e1841-03e9-4c5c-94ba-b1a5fadf173c	compose-migrate-job	6754cc40362f	SUCCESS	\N	migrations applied	2026-03-09 09:24:34.43336+00	2026-03-09 09:24:34.814323+00	42	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1085, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
71	c2f9fb37-8f8d-49be-abd3-c8333b677ec1	compose-migrate-job	48d748116150	SUCCESS	\N	migrations applied	2026-03-09 13:11:15.979853+00	2026-03-09 13:11:16.518761+00	16	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1440, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
72	b03029b4-8b73-4e90-bc2c-b6b0b6f3d151	compose-migrate-job	7fb193658163	SUCCESS	\N	migrations applied	2026-03-09 13:24:09.738199+00	2026-03-09 13:24:09.979157+00	7	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 930, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
73	324f34bd-a3c7-42a8-b9a1-558da2c90dfa	compose-migrate-job	bb0ecfbe0142	SUCCESS	\N	migrations applied	2026-03-09 13:49:43.509755+00	2026-03-09 13:49:43.864187+00	12	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 870, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
74	6c6dbe25-496c-4a33-ab73-3dcee1ffbe46	compose-migrate-job	4b445818102c	SUCCESS	\N	migrations applied	2026-03-09 14:28:29.455582+00	2026-03-09 14:28:29.901412+00	57	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1323, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
75	51eb3ddf-6efc-4c02-8567-960064d9632d	compose-migrate-job	73bfa7fc5ecd	SUCCESS	\N	migrations applied	2026-03-09 15:37:42.33486+00	2026-03-09 15:37:42.609732+00	44	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 426, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
76	3f39fc6f-4dbd-4083-8ed8-07800f4fc0e7	compose-migrate-job	ca09e34bc6dc	SUCCESS	\N	migrations applied	2026-03-09 15:52:25.554785+00	2026-03-09 15:52:25.886744+00	43	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1454, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
77	2d9ba0ee-b52e-4502-aaa0-98ba55a715db	compose-migrate-job	ee86ecc9963d	SUCCESS	\N	migrations applied	2026-03-09 16:16:50.433939+00	2026-03-09 16:16:50.709859+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 935, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
78	9cd28c9a-6909-4c62-9884-cdac61dc6a4c	compose-migrate-job	4118a4349fba	SUCCESS	\N	migrations applied	2026-03-09 16:35:16.968471+00	2026-03-09 16:35:17.530117+00	38	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1271, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
79	4061ddff-4ec4-448e-8494-2126d71d3e02	compose-migrate-job	f2bf5b05065a	SUCCESS	\N	migrations applied	2026-03-09 16:52:44.196755+00	2026-03-09 16:52:44.323174+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 598, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
80	e6e6be84-e195-4339-ab81-e609b9536261	compose-migrate-job	3da481d31f64	SUCCESS	\N	migrations applied	2026-03-09 17:07:21.373051+00	2026-03-09 17:07:21.773648+00	40	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1267, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
81	cfe7bffa-17fc-453d-8a7f-b0b119d0b892	compose-migrate-job	6f484e7ad793	SUCCESS	\N	migrations applied	2026-03-09 17:24:04.516867+00	2026-03-09 17:24:04.728873+00	5	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 773, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
82	85478f9d-7521-4fc4-9231-926849c0dbeb	compose-migrate-job	f991905e4c5d	SUCCESS	\N	migrations applied	2026-03-10 01:11:13.001947+00	2026-03-10 01:11:13.544434+00	37	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1548, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
83	678a892b-75b5-417a-b633-9f78f396cffc	compose-migrate-job	5666edb4e602	SUCCESS	\N	migrations applied	2026-03-10 02:49:53.400921+00	2026-03-10 02:49:53.600782+00	41	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1173, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
84	e310dd37-cf53-4d71-a5c5-6eaafb504c9f	compose-migrate-job	d4649f81544b	SUCCESS	\N	migrations applied	2026-03-10 03:27:09.597078+00	2026-03-10 03:27:09.920211+00	33	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1095, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
85	ac99be54-eb84-4951-8eb2-5b1875220e44	compose-migrate-job	6c63aa2b033e	SUCCESS	\N	migrations applied	2026-03-10 08:26:17.307684+00	2026-03-10 08:26:17.701161+00	20	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1211, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
86	81064982-7b4d-440c-b502-fe99725407ef	compose-migrate-job	45fc96eb21ad	SUCCESS	\N	migrations applied	2026-03-11 01:26:59.817008+00	2026-03-11 01:27:00.486043+00	31	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1655, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
87	a54e5e12-f8a2-41e8-8e7b-e0e2bf71317b	compose-migrate-job	a0509e754a07	SUCCESS	\N	migrations applied	2026-03-11 05:27:26.288679+00	2026-03-11 05:27:26.587892+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1110, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
88	d6050719-8966-478b-95fc-5464a9a958fb	compose-migrate-job	876b03a1931a	SUCCESS	\N	migrations applied	2026-03-11 05:45:17.174339+00	2026-03-11 05:45:17.378293+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 779, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
89	a460b21c-e0fc-46e2-bc5e-209f3796ca10	compose-migrate-job	c29792afe186	SUCCESS	\N	migrations applied	2026-03-11 06:47:36.135629+00	2026-03-11 06:47:36.499649+00	25	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1458, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
90	68b2c200-a48f-4c9e-b4de-e0f7e8f40e28	compose-migrate-job	e1e387eff517	SUCCESS	\N	migrations applied	2026-03-11 07:53:56.088826+00	2026-03-11 07:53:56.482864+00	29	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1384, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
91	92765d96-bfe9-49e4-a09b-d9f27e16193a	compose-migrate-job	c6d6e249a143	SUCCESS	\N	migrations applied	2026-03-11 08:09:09.181481+00	2026-03-11 08:09:09.385019+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 545, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
92	1b1cf796-2f27-47c8-aa1e-91eaaa5c8d2c	compose-migrate-job	0571a3943dd0	SUCCESS	\N	migrations applied	2026-03-11 08:45:09.570984+00	2026-03-11 08:45:09.895115+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 946, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
93	2f78cd93-e3b6-4ba2-826a-f18cff257f50	compose-migrate-job	6fecb3fdf5f6	SUCCESS	\N	migrations applied	2026-03-11 09:03:33.748767+00	2026-03-11 09:03:34.142292+00	37	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 790, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
94	08d1c7a8-1c82-4a8b-9539-3fbbedd6c82e	compose-migrate-job	8a347cafe332	SUCCESS	\N	migrations applied	2026-03-11 09:35:09.737277+00	2026-03-11 09:35:10.164763+00	12	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1304, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
95	20a12a74-8b52-448e-b058-e77001adc373	compose-migrate-job	b89f0f00421f	SUCCESS	\N	migrations applied	2026-03-11 09:55:56.334202+00	2026-03-11 09:55:56.613559+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 608, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
96	9985b687-4558-46b0-b1e4-3e2c84869393	compose-migrate-job	2838f6aae598	SUCCESS	\N	migrations applied	2026-03-11 12:55:54.839526+00	2026-03-11 12:55:55.367482+00	45	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1043, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
97	adfa7fbc-459c-4115-9501-6ee6cf0a5ecb	compose-migrate-job	f9c05feb7e3e	SUCCESS	\N	migrations applied	2026-03-11 13:12:28.013997+00	2026-03-11 13:12:28.186553+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 564, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
98	00d84267-7518-47ee-8e93-60817ef3cb5f	compose-migrate-job	999b568a0b0b	SUCCESS	\N	migrations applied	2026-03-11 13:28:43.114977+00	2026-03-11 13:28:43.248858+00	5	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 904, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
99	a4ff0d54-6660-4ecc-a74f-e32b3339fc88	compose-migrate-job	53149b61885f	SUCCESS	\N	migrations applied	2026-03-11 13:42:19.879506+00	2026-03-11 13:42:20.298704+00	53	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1380, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
100	489ce13b-3d57-4d79-8287-41dd24bebc86	compose-migrate-job	b34bc14dd980	SUCCESS	\N	migrations applied	2026-03-11 13:55:38.757784+00	2026-03-11 13:55:38.903807+00	2	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 566, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
101	7a179987-c8a2-4d52-ad67-70a46434db41	compose-migrate-job	54d2b98f45b4	SUCCESS	\N	migrations applied	2026-03-11 14:10:02.528929+00	2026-03-11 14:10:02.759195+00	25	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1040, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
102	2d1926bc-c195-4f31-ace5-0931cff667b0	compose-migrate-job	31fa00a5072d	SUCCESS	\N	migrations applied	2026-03-11 14:21:14.096032+00	2026-03-11 14:21:14.282524+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 563, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
103	b72a2e93-f44f-449b-bcf6-2a72076273f9	compose-migrate-job	07488e360e3f	SUCCESS	\N	migrations applied	2026-03-11 14:45:41.282959+00	2026-03-11 14:45:41.564754+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 860, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
104	87e445dd-d858-42af-847f-a7dcf55384e3	compose-migrate-job	884faa81b3da	SUCCESS	\N	migrations applied	2026-03-12 05:51:54.020265+00	2026-03-12 05:51:54.557679+00	47	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1581, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
105	e25d67b1-7d45-49cc-9756-c6ffc675ac5a	compose-migrate-job	5170e761fa4d	SUCCESS	\N	migrations applied	2026-03-12 06:15:42.56812+00	2026-03-12 06:15:42.747771+00	5	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1906, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
106	110e3679-3bf4-40fd-be04-d5f8a5f39f52	compose-migrate-job	8f479b9b9c7b	SUCCESS	\N	migrations applied	2026-03-12 06:24:52.430419+00	2026-03-12 06:24:52.947518+00	14	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1323, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
107	9cd133a4-7089-458f-856b-2dfe415a88d5	compose-migrate-job	3f4a950e20d7	SUCCESS	\N	migrations applied	2026-03-12 07:05:12.160718+00	2026-03-12 07:05:12.522023+00	12	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1257, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
108	2a1a034a-2b24-4516-bf60-60c26f173579	compose-migrate-job	80558d476df3	SUCCESS	\N	migrations applied	2026-03-12 07:38:27.78162+00	2026-03-12 07:38:28.118884+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1367, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
109	268efe11-a307-4f35-8e67-a1f102126452	compose-migrate-job	528efce6e93a	SUCCESS	\N	migrations applied	2026-03-12 07:51:29.591763+00	2026-03-12 07:51:29.878083+00	27	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1099, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
110	2a7fc3c6-5a49-4c23-aaa5-9de6797449ff	compose-migrate-job	e2c13bc7b5ea	SUCCESS	\N	migrations applied	2026-03-12 08:08:37.369334+00	2026-03-12 08:08:37.624085+00	28	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1104, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
111	71f39943-1beb-477c-a19b-81d2b280abee	compose-migrate-job	2b695d43227e	SUCCESS	\N	migrations applied	2026-03-12 08:21:27.492037+00	2026-03-12 08:21:27.695206+00	14	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 850, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
112	1986c311-7cea-4564-96a7-0fa868d51155	compose-migrate-job	f6ca0e76ff9e	SUCCESS	\N	migrations applied	2026-03-12 08:42:19.367868+00	2026-03-12 08:42:19.703472+00	37	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1422, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
113	a09d800e-4b56-4800-9233-576af4209600	compose-migrate-job	e1d0388b7a58	SUCCESS	\N	migrations applied	2026-03-12 08:56:07.015382+00	2026-03-12 08:56:07.182029+00	33	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1075, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
114	a717916b-7905-4dd3-839a-72f7e2956c8c	compose-migrate-job	6f47b2e1265e	SUCCESS	\N	migrations applied	2026-03-12 09:15:58.646681+00	2026-03-12 09:15:59.030463+00	40	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1376, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
115	4d742b57-125f-44ac-b0cc-ced2a2561592	compose-migrate-job	b20551cff9b9	SUCCESS	\N	migrations applied	2026-03-12 09:30:43.182313+00	2026-03-12 09:30:43.485143+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 879, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
116	dd516ef7-b98d-4f34-8470-44d30c8fea2e	compose-migrate-job	26cf1a3bf767	SUCCESS	\N	migrations applied	2026-03-12 09:58:37.352937+00	2026-03-12 09:58:37.603049+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1143, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
117	73eecac1-6168-4ee7-93ad-cda6eade935c	compose-migrate-job	f348731c4ccc	SUCCESS	\N	migrations applied	2026-03-12 12:38:23.052388+00	2026-03-12 12:38:23.476924+00	18	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1115, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
118	fc6e3c85-9f61-44dd-8d1d-d241f1a7b848	compose-migrate-job	d6b28631b826	SUCCESS	\N	migrations applied	2026-03-12 13:09:54.791865+00	2026-03-12 13:09:55.086537+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1278, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
119	5a737956-85e4-4c90-a8e6-bc71227f49ee	compose-migrate-job	188c0c8645a1	SUCCESS	\N	migrations applied	2026-03-12 13:33:28.073469+00	2026-03-12 13:33:28.50421+00	29	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1181, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
120	7f92eb73-1b40-414f-b6a2-683f9733421f	compose-migrate-job	816fa6e2bc4a	SUCCESS	\N	migrations applied	2026-03-12 13:54:59.641161+00	2026-03-12 13:54:59.928751+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1263, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
121	05e015aa-c838-4cb8-b31b-9623331b326b	compose-migrate-job	1a4da45e1528	SUCCESS	\N	migrations applied	2026-03-12 14:12:10.64362+00	2026-03-12 14:12:10.980288+00	11	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1627, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
122	76504214-6c90-4295-bd26-5acb83874d3a	compose-migrate-job	be60f750cf5e	SUCCESS	\N	migrations applied	2026-03-12 15:21:20.866188+00	2026-03-12 15:21:21.243201+00	10	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 717, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
123	c958ebe1-1294-4451-ae4d-1d8b5d28b49a	compose-migrate-job	5cc8cdc06660	SUCCESS	\N	migrations applied	2026-03-12 23:38:35.745157+00	2026-03-12 23:38:36.206742+00	27	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1302, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
124	5728638f-2067-48a1-9f7d-5f77ddbaae9b	compose-migrate-job	9b56947bd6ea	SUCCESS	\N	migrations applied	2026-03-13 00:23:05.403488+00	2026-03-13 00:23:05.747711+00	11	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1117, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
125	c2cb4f34-6452-465b-ba27-d2957f289879	compose-migrate-job	b7f3c3039a04	SUCCESS	\N	migrations applied	2026-03-13 00:50:56.20589+00	2026-03-13 00:50:56.495146+00	14	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1027, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
126	d1e58556-3e53-4701-ba3a-93f8390779b2	compose-migrate-job	499d08adc7b0	SUCCESS	\N	migrations applied	2026-03-13 01:28:45.656815+00	2026-03-13 01:28:46.334969+00	95	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1828, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
127	8c9ec55c-c6c0-4c89-b9c9-ba63dfe7310f	compose-migrate-job	5b3e959fd05e	SUCCESS	\N	migrations applied	2026-03-13 01:39:57.414469+00	2026-03-13 01:39:57.70889+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 653, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
128	507a07ef-6fd7-4def-a9e4-52373a6fb3e2	compose-migrate-job	21ea33f33b99	SUCCESS	\N	migrations applied	2026-03-13 01:53:16.893684+00	2026-03-13 01:53:17.020752+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 791, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
129	d62de35b-0a4b-4486-ba89-578fddb635e4	compose-migrate-job	3fbca743ff6b	SUCCESS	\N	migrations applied	2026-03-13 02:09:12.469292+00	2026-03-13 02:09:12.693593+00	42	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 595, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
130	7f8b6e3f-8429-411a-b498-45d8227043de	compose-migrate-job	9a594ecef6f6	SUCCESS	\N	migrations applied	2026-03-13 02:14:19.89353+00	2026-03-13 02:14:20.096433+00	1	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 632, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
131	b7e9f6bd-36fd-49c1-89c1-d09fdd40f146	compose-migrate-job	e4858e904648	SUCCESS	\N	migrations applied	2026-03-13 02:27:27.036468+00	2026-03-13 02:27:27.362048+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 626, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
132	a190eda8-49d9-4a83-bb8c-2cc444e4f364	compose-migrate-job	503e6c76804f	SUCCESS	\N	migrations applied	2026-03-13 02:53:07.362141+00	2026-03-13 02:53:07.605063+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 838, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
133	2ad0aa5d-a6ba-496b-8342-c7383386fa90	compose-migrate-job	3fb313d73fa2	SUCCESS	\N	migrations applied	2026-03-13 03:05:38.971911+00	2026-03-13 03:05:39.384871+00	67	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 976, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
136	157634bc-9a2c-470c-a81b-ae9a67e34a03	compose-migrate-job	4443bb105dd8	SUCCESS	\N	migrations applied	2026-03-13 03:42:25.706806+00	2026-03-13 03:42:25.956674+00	36	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 508, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
134	68af178e-3205-405c-bb10-9dd875ae2942	compose-migrate-job	35b8ba536dc4	SUCCESS	\N	migrations applied	2026-03-13 03:18:38.88892+00	2026-03-13 03:18:39.21247+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 847, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
137	f6a6fefc-9079-43aa-9487-e2da24afc7bd	compose-migrate-job	5eee55470876	SUCCESS	\N	migrations applied	2026-03-13 03:52:06.159273+00	2026-03-13 03:52:06.335501+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 732, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
138	148e0884-2d12-4398-9bd1-640b1330e345	compose-migrate-job	64d8a646781c	SUCCESS	\N	migrations applied	2026-03-13 04:06:04.782306+00	2026-03-13 04:06:05.116248+00	12	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1079, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
139	c5723456-e893-4d2a-b841-456ff1971235	compose-migrate-job	83112811ffa7	SUCCESS	\N	migrations applied	2026-03-13 04:24:37.641463+00	2026-03-13 04:24:37.932497+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1112, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
140	19119080-91e8-4e89-80d6-b6f2b436215f	compose-migrate-job	1cdea64a85b8	SUCCESS	\N	migrations applied	2026-03-13 04:42:57.556007+00	2026-03-13 04:42:57.941233+00	41	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1140, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
228	eca72fb4-2a17-476d-9e37-b5d8dcb205c3	compose-migrate-job	7083f5d5e393	SUCCESS	\N	migrations applied	2026-03-19 05:59:51.614219+00	2026-03-19 05:59:51.913183+00	17	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1043, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
141	e176fbd2-228e-41e8-8655-fba5b3b6454d	compose-migrate-job	3bbd66777325	SUCCESS	\N	migrations applied	2026-03-13 04:57:56.125861+00	2026-03-13 04:57:56.316233+00	5	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 889, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
142	d47f2a0b-bcfc-4084-a4a2-ae51d5458488	compose-migrate-job	fb42c60b240e	SUCCESS	\N	migrations applied	2026-03-13 05:16:59.786317+00	2026-03-13 05:16:59.987268+00	15	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 994, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
143	0df87429-f3bc-4c2e-9b04-3361062efbf5	compose-migrate-job	1f8be385b774	SUCCESS	\N	migrations applied	2026-03-13 09:45:12.090578+00	2026-03-13 09:45:12.437067+00	15	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1677, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
144	37587be8-62b1-4c20-a59d-a2e1e575aecc	compose-migrate-job	728eea2e225a	SUCCESS	\N	migrations applied	2026-03-13 12:01:00.095272+00	2026-03-13 12:01:00.261705+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1195, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
145	7370a9f3-e690-456e-9e7a-e7bea772b008	compose-migrate-job	ae1a2f6d8c7d	SUCCESS	\N	migrations applied	2026-03-13 12:13:58.374512+00	2026-03-13 12:13:58.777954+00	11	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1646, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
146	f26785ce-2c68-4bd1-b724-39f512703dc3	compose-migrate-job	1adaf7347693	SUCCESS	\N	migrations applied	2026-03-13 12:59:45.941968+00	2026-03-13 12:59:46.313434+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 832, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
147	59f7144b-46a6-4c75-b39a-8681e931a8ed	compose-migrate-job	851b555373d9	SUCCESS	\N	migrations applied	2026-03-13 13:33:32.175287+00	2026-03-13 13:33:32.53521+00	18	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1333, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
148	09b966c7-4f57-4c6f-8e7a-4626f3879020	compose-migrate-job	cee3c0c62ffe	SUCCESS	\N	migrations applied	2026-03-13 13:56:09.643382+00	2026-03-13 13:56:09.939709+00	5	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 891, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
149	3e69d14e-fe1f-4b0b-84c3-2e389c47c73e	compose-migrate-job	c42c13e0712b	SUCCESS	\N	migrations applied	2026-03-13 14:18:30.147308+00	2026-03-13 14:18:30.412794+00	7	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 549, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
150	c4cbce27-eefe-403c-a4f7-79072e049c0c	compose-migrate-job	22b5b041b701	SUCCESS	\N	migrations applied	2026-03-14 05:00:43.947211+00	2026-03-14 05:00:44.424094+00	62	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1097, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
151	1974a968-b241-4c1a-ac33-1912d1bb6cb7	compose-migrate-job	98acce56260e	SUCCESS	\N	migrations applied	2026-03-14 05:42:24.532882+00	2026-03-14 05:42:24.790106+00	27	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1270, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
152	ef93ef57-b034-4b7f-8599-1f0e525e5a6c	compose-migrate-job	7cfe4653a287	SUCCESS	\N	migrations applied	2026-03-14 06:21:53.763607+00	2026-03-14 06:21:54.173861+00	10	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1105, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
153	437fde3d-7ba8-45b9-a058-ca7bd1dd9518	compose-migrate-job	3d04483ab31e	SUCCESS	\N	migrations applied	2026-03-14 06:38:52.093487+00	2026-03-14 06:38:52.484122+00	29	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1008, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
154	e0e15bec-a653-4352-938f-46104bf71743	compose-migrate-job	9dd873569d05	SUCCESS	\N	migrations applied	2026-03-14 06:54:41.596966+00	2026-03-14 06:54:41.968759+00	19	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1055, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
155	2723d48c-5526-45c0-9926-e6ff00e35469	compose-migrate-job	25075e5b0246	SUCCESS	\N	migrations applied	2026-03-14 07:07:23.951474+00	2026-03-14 07:07:24.257163+00	7	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 897, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
156	96b31c2c-de00-4c46-a411-c58c2a748224	compose-migrate-job	90e0536e51e4	SUCCESS	\N	migrations applied	2026-03-14 09:40:48.86636+00	2026-03-14 09:40:49.15925+00	45	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 983, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
157	22eb2832-cc4c-4024-adb7-1d79fb89dd5d	compose-migrate-job	3e135a33e16d	SUCCESS	\N	migrations applied	2026-03-14 14:21:27.687739+00	2026-03-14 14:21:27.977689+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1070, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
158	3ab01562-6d42-4664-9067-6492e4ab85fb	compose-migrate-job	708cbdd4b50d	SUCCESS	\N	migrations applied	2026-03-14 14:30:20.74989+00	2026-03-14 14:30:21.122817+00	13	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1784, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
159	de76a7c4-3c8c-4bca-8f10-1843148359f6	compose-migrate-job	c77915e33640	SUCCESS	\N	migrations applied	2026-03-14 15:06:30.699496+00	2026-03-14 15:06:31.032633+00	30	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1239, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
160	0ed80195-56b0-4870-aea8-30c65c6ebb4f	compose-migrate-job	798343f1dd79	SUCCESS	\N	migrations applied	2026-03-14 16:23:19.957732+00	2026-03-14 16:23:20.259807+00	25	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1002, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
161	c1b69069-ebde-41c7-a9ba-130fe9035a4a	compose-migrate-job	47ecff1b9105	SUCCESS	\N	migrations applied	2026-03-14 22:41:41.227948+00	2026-03-14 22:41:41.596113+00	13	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1163, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
162	14e31fba-2df7-4d0f-a62a-1b81ab04848d	compose-migrate-job	848271afa34b	SUCCESS	\N	migrations applied	2026-03-14 22:56:45.805345+00	2026-03-14 22:56:46.096249+00	20	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 864, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
163	773ecea9-79a5-45a8-95b2-3b190cf384f0	compose-migrate-job	719700586ceb	SUCCESS	\N	migrations applied	2026-03-14 23:18:16.617592+00	2026-03-14 23:18:17.055265+00	11	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 927, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
164	74b46871-de03-4885-b903-e69275bd0574	compose-migrate-job	8b2ab47c7db4	SUCCESS	\N	migrations applied	2026-03-15 01:12:01.107991+00	2026-03-15 01:12:01.390907+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 614, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
165	eba31242-df4c-4715-aa02-3fa4a0bcad8e	compose-migrate-job	c0b053416d32	SUCCESS	\N	migrations applied	2026-03-15 02:05:12.006339+00	2026-03-15 02:05:12.517297+00	24	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1036, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
166	0cc8f25b-17b8-4476-b725-6e821452011a	compose-migrate-job	b2c7a33a7cda	SUCCESS	\N	migrations applied	2026-03-15 02:15:57.329479+00	2026-03-15 02:15:57.539919+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 886, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
167	a5322196-3b0f-491f-a79f-cbd340df4791	compose-migrate-job	9c5133e44a34	SUCCESS	\N	migrations applied	2026-03-15 02:30:37.632053+00	2026-03-15 02:30:37.963062+00	38	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 954, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
168	8eb69962-d6a1-4339-b56b-a630d2c73c39	compose-migrate-job	9b67b10b4b8a	SUCCESS	\N	migrations applied	2026-03-15 02:43:04.293677+00	2026-03-15 02:43:04.646889+00	29	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 752, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
169	ed4fc0d2-3b63-4e9f-8536-12cc2f9d68b8	compose-migrate-job	e7ad5cfda456	SUCCESS	\N	migrations applied	2026-03-15 03:11:33.612431+00	2026-03-15 03:11:34.16405+00	10	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1510, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
170	7ce79ea7-06a5-45e2-b09c-b4f00c300f8d	compose-migrate-job	07df9809d6ee	SUCCESS	\N	migrations applied	2026-03-15 03:23:01.956888+00	2026-03-15 03:23:02.302307+00	7	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 981, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
171	0a688f56-2de0-440f-b7aa-667b313b4ab5	compose-migrate-job	0500e45379ae	SUCCESS	\N	migrations applied	2026-03-15 03:38:40.44201+00	2026-03-15 03:38:40.712139+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1091, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
172	6caf183c-4975-4556-b780-284f15ddc9ec	compose-migrate-job	468c313c371a	SUCCESS	\N	migrations applied	2026-03-15 03:57:30.651116+00	2026-03-15 03:57:30.978305+00	13	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1667, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
173	723a709e-47ec-4c4c-87ba-86ef9db7a1bd	compose-migrate-job	662db7b8c423	SUCCESS	\N	migrations applied	2026-03-15 04:10:05.916067+00	2026-03-15 04:10:06.349186+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1198, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
174	03ee09ca-2e41-4c92-9c45-de1881277db5	compose-migrate-job	0680ef9f9fb0	SUCCESS	\N	migrations applied	2026-03-15 05:29:11.962135+00	2026-03-15 05:29:12.412806+00	36	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1505, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
175	cec459b8-0df8-42fb-a798-acff35fa8a6b	compose-migrate-job	2c5ae3b97aa5	SUCCESS	\N	migrations applied	2026-03-15 06:20:48.248093+00	2026-03-15 06:20:49.638808+00	292	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 4206, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
176	8ac0199a-9a69-4bbb-8314-6a09d5f7f27e	compose-migrate-job	78b3076c5c81	SUCCESS	\N	migrations applied	2026-03-15 06:34:39.088099+00	2026-03-15 06:34:39.294394+00	10	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1181, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
177	a91a3f4c-44da-400b-b3a4-8696ac4f22d3	compose-migrate-job	2ba8910075d7	SUCCESS	\N	migrations applied	2026-03-15 06:48:28.970338+00	2026-03-15 06:48:29.308877+00	24	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 786, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
178	6b9d2685-0ba5-4f56-8273-f83b74571cb0	compose-migrate-job	e684d73d56e0	SUCCESS	\N	migrations applied	2026-03-15 07:03:41.088493+00	2026-03-15 07:03:41.318562+00	7	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 950, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
179	b1f2969b-e9da-41ac-9111-ab6c793efff7	compose-migrate-job	0154a3678036	SUCCESS	\N	migrations applied	2026-03-15 07:14:45.437297+00	2026-03-15 07:14:45.713322+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1146, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
180	7e343f07-2f94-4830-902c-d339ded2b5eb	compose-migrate-job	07f3cf80bda9	SUCCESS	\N	migrations applied	2026-03-15 07:22:30.362285+00	2026-03-15 07:22:30.621925+00	11	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1281, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
181	e4fd91ae-8edd-426d-91a9-c5d8019e4e04	compose-migrate-job	fb555a0e9e3c	SUCCESS	\N	migrations applied	2026-03-15 07:26:32.773235+00	2026-03-15 07:26:33.186585+00	10	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1048, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
182	4496cceb-fdd0-4524-88ad-132caf723a49	compose-migrate-job	a6aab3e10fe5	SUCCESS	\N	migrations applied	2026-03-15 07:30:15.712852+00	2026-03-15 07:30:15.902688+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 791, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
183	3aff30a3-240d-4e6a-bdd3-cc15f38936c7	compose-migrate-job	a1fa48e36db3	SUCCESS	\N	migrations applied	2026-03-15 07:39:39.945911+00	2026-03-15 07:39:40.276262+00	28	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 816, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
184	a88b91a0-628e-49bc-a0b7-33b889c7a808	compose-migrate-job	ee8b41cfc702	SUCCESS	\N	migrations applied	2026-03-15 07:42:50.771326+00	2026-03-15 07:42:51.080726+00	22	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 860, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
185	a15d3c0d-ee84-4985-a5dc-1c6f72053b31	compose-migrate-job	7eb6d15ffa1d	SUCCESS	\N	migrations applied	2026-03-15 07:47:01.30596+00	2026-03-15 07:47:01.439836+00	4	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 858, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
186	89818a2c-c7d4-4f11-853f-47096543ae9c	compose-migrate-job	1af336be4bd1	SUCCESS	\N	migrations applied	2026-03-15 07:50:11.087031+00	2026-03-15 07:50:11.378306+00	14	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 617, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
187	a03e9956-ea23-41f1-80f1-5ef285a942fa	compose-migrate-job	9c89ef7890ff	SUCCESS	\N	migrations applied	2026-03-15 07:53:57.845946+00	2026-03-15 07:53:58.088483+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 585, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
188	67d5eedc-fbaf-4f81-87ea-73df66abb456	compose-migrate-job	43dbbfbb5c4e	SUCCESS	\N	migrations applied	2026-03-15 07:57:05.930524+00	2026-03-15 07:57:06.223363+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 830, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
189	79eff608-661e-46ec-aaa3-1df75a42ede1	compose-migrate-job	864c1de9a2e8	SUCCESS	\N	migrations applied	2026-03-15 08:00:55.799795+00	2026-03-15 08:00:56.152206+00	39	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 714, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
190	f27d30dd-8d68-4f58-9f8d-ed2293055140	compose-migrate-job	d620751d17df	SUCCESS	\N	migrations applied	2026-03-15 08:04:55.113205+00	2026-03-15 08:04:55.438532+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 798, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
191	1a70126a-5006-413a-a9b5-1654beac1cf9	compose-migrate-job	7c837069d797	SUCCESS	\N	migrations applied	2026-03-15 08:09:09.49477+00	2026-03-15 08:09:09.797116+00	30	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1338, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
192	48afb29a-a85b-4fab-b7d7-2f920f599f24	compose-migrate-job	565bade666a2	SUCCESS	\N	migrations applied	2026-03-15 08:12:51.333127+00	2026-03-15 08:12:51.548318+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1068, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
193	dad31a6b-2828-447e-8bd6-eacb42a180f3	compose-migrate-job	39ba114f9d0d	SUCCESS	\N	migrations applied	2026-03-15 08:15:54.500009+00	2026-03-15 08:15:54.661489+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1117, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
194	eca9b5d6-b845-4d98-b9c0-c7be412dc03d	compose-migrate-job	fc33d6990fc9	SUCCESS	\N	migrations applied	2026-03-15 08:19:38.888903+00	2026-03-15 08:19:39.218434+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 484, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
195	76228cc7-bed7-45b8-b1cb-ed2901af0209	compose-migrate-job	7ceb7e54a98d	SUCCESS	\N	migrations applied	2026-03-15 12:44:33.905125+00	2026-03-15 12:44:34.354203+00	12	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1336, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
196	916824bc-8b34-4e40-ab67-e14b6415403a	compose-migrate-job	a0b279c4eaa7	SUCCESS	\N	migrations applied	2026-03-16 04:19:51.339151+00	2026-03-16 04:19:51.907501+00	27	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1879, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
197	4c4c3101-3e6a-4280-b75e-cd9c7b3050a8	compose-migrate-job	ae20f8ef6450	SUCCESS	\N	migrations applied	2026-03-16 06:07:04.488301+00	2026-03-16 06:07:05.347003+00	65	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 2179, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
198	9c60eb99-8d59-48e4-af76-20f42f8aec66	compose-migrate-job	19bfe088b074	SUCCESS	\N	migrations applied	2026-03-16 06:55:11.961676+00	2026-03-16 06:55:12.310909+00	9	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1431, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
199	7d97cb94-2b8e-4548-90c4-eea7f813cf4e	compose-migrate-job	0ce1daf93e0b	SUCCESS	\N	migrations applied	2026-03-16 07:21:29.281124+00	2026-03-16 07:21:29.682175+00	50	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1359, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
200	b3dd771a-4a8b-4b2c-adef-46c5562c5c8b	compose-migrate-job	c14a1af94df7	SUCCESS	\N	migrations applied	2026-03-16 07:31:35.598343+00	2026-03-16 07:31:35.989576+00	5	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1242, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
201	8b98544a-3b24-4088-a711-01648533751e	compose-migrate-job	a7e41c3e62e8	SUCCESS	\N	migrations applied	2026-03-17 03:19:05.140115+00	2026-03-17 03:19:05.911753+00	62	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1943, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
202	7ddcd95b-914d-4816-94b2-da51052964a3	compose-migrate-job	8a67ce250e0b	SUCCESS	\N	migrations applied	2026-03-17 04:38:44.816859+00	2026-03-17 04:38:45.233272+00	35	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1155, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
203	b5d299d8-fc3d-4b8f-a729-769e5faaef6d	compose-migrate-job	9d0b00f54b3c	SUCCESS	\N	migrations applied	2026-03-17 07:16:33.7488+00	2026-03-17 07:16:34.092495+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1656, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
204	7bfef7ab-f782-449f-a7d4-589d620cc807	compose-migrate-job	ad2d3f7d39f2	SUCCESS	\N	migrations applied	2026-03-17 07:31:45.443348+00	2026-03-17 07:31:45.949251+00	57	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1432, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
205	5b9e366f-d576-4186-b572-c1752b3e3144	compose-migrate-job	1552eb7fcf7b	SUCCESS	\N	migrations applied	2026-03-17 07:46:13.725283+00	2026-03-17 07:46:14.142985+00	33	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1184, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
206	7e8d7ec9-fa97-4297-9771-75c04aa00702	compose-migrate-job	27f228e342c8	SUCCESS	\N	migrations applied	2026-03-17 08:02:08.966537+00	2026-03-17 08:02:09.419485+00	19	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1617, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
207	e73215fa-1a80-46cf-bf78-34f7ed227690	compose-migrate-job	e0fb1feee762	SUCCESS	\N	migrations applied	2026-03-17 08:17:12.859484+00	2026-03-17 08:17:13.37589+00	26	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1322, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
208	dbde8e36-9659-4958-ae60-f365af7305ce	compose-migrate-job	9e0bba3edfd3	SUCCESS	\N	migrations applied	2026-03-18 04:37:37.467656+00	2026-03-18 04:37:37.919819+00	69	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1112, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
209	202c2c5a-8d44-440b-83b7-969d19c6014e	compose-migrate-job	c2b4414aba79	SUCCESS	\N	migrations applied	2026-03-18 05:06:05.101279+00	2026-03-18 05:06:05.502797+00	40	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1145, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
210	bfd0433e-58e2-4d1e-a2de-fd00d31083a7	compose-migrate-job	e12572b5dedb	SUCCESS	\N	migrations applied	2026-03-18 08:25:10.323641+00	2026-03-18 08:25:10.837181+00	42	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1890, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
229	9a2488a4-2356-48c2-add4-093d45dfd923	compose-migrate-job	e4e387fb1e86	SUCCESS	\N	migrations applied	2026-03-19 06:17:31.07812+00	2026-03-19 06:17:31.305413+00	2	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1807, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
211	fce36e21-6335-4cc9-b089-40c1f27c5fb8	compose-migrate-job	6da4a79ef609	SUCCESS	\N	migrations applied	2026-03-18 09:19:58.510593+00	2026-03-18 09:19:58.882877+00	13	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1479, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
230	c3dfa948-dd69-425f-aad5-1f0ec16869d0	compose-migrate-job	ed9e0b881c74	SUCCESS	\N	migrations applied	2026-03-19 06:49:12.995384+00	2026-03-19 06:49:13.453299+00	51	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 968, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
212	c3ed7034-c14b-467a-b7ce-72c3a7c43395	compose-migrate-job	9f8d6b74c5e0	SUCCESS	\N	migrations applied	2026-03-18 10:23:29.549865+00	2026-03-18 10:23:30.235598+00	113	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1137, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
231	69d29db9-7623-4f95-a0ce-0a246e241897	compose-migrate-job	8e02c454dbf6	SUCCESS	\N	migrations applied	2026-03-19 07:12:44.829419+00	2026-03-19 07:12:45.170295+00	62	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1057, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
213	2f14408e-fb35-48ff-8cae-c1611e74e97c	compose-migrate-job	8543c628a8ec	SUCCESS	\N	migrations applied	2026-03-18 12:56:27.445648+00	2026-03-18 12:56:27.997951+00	57	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1700, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
214	3501258f-1c08-42c4-968e-7ffcb4de6024	compose-migrate-job	4fbdb960e65b	SUCCESS	\N	migrations applied	2026-03-18 13:13:09.832735+00	2026-03-18 13:13:10.172962+00	47	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 777, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
215	25a9ffc9-d513-4e47-88d7-6ac6d9e1d91f	compose-migrate-job	783ed5b1ccb8	SUCCESS	\N	migrations applied	2026-03-18 13:23:08.568772+00	2026-03-18 13:23:08.913031+00	13	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1708, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
216	589e0964-49e5-4d3c-a763-1f97cb0abebf	compose-migrate-job	11d246cda03d	SUCCESS	\N	migrations applied	2026-03-18 14:23:15.718372+00	2026-03-18 14:23:16.080064+00	10	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1385, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
217	259f0303-0a78-4368-9eb6-027026f424f0	compose-migrate-job	fa5275d65fba	SUCCESS	\N	migrations applied	2026-03-18 14:59:30.348069+00	2026-03-18 14:59:30.626354+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 854, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
218	c154089b-9778-47d1-b08a-d0088b0da310	compose-migrate-job	c634a49a850b	SUCCESS	\N	migrations applied	2026-03-18 15:42:57.398279+00	2026-03-18 15:42:57.860999+00	56	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1431, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
219	3fe4ae76-6026-47ef-a1f4-a74b1f52c59f	compose-migrate-job	5d9530f8c41d	SUCCESS	\N	migrations applied	2026-03-18 16:18:31.873948+00	2026-03-18 16:18:32.353545+00	84	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1262, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
220	f1741783-5590-4586-bc1f-f7db7e472c8b	compose-migrate-job	ca9d081a4035	SUCCESS	\N	migrations applied	2026-03-19 02:43:48.827241+00	2026-03-19 02:43:50.029201+00	101	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 3389, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
221	6b93756d-06e6-4a2f-a73b-901c783132dd	compose-migrate-job	014da5592d60	SUCCESS	\N	migrations applied	2026-03-19 03:20:40.349032+00	2026-03-19 03:20:40.634149+00	26	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1107, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
222	e35f1627-364d-4d9e-b3b1-a2dc2cbe6a24	compose-migrate-job	a6ad86bd802f	SUCCESS	\N	migrations applied	2026-03-19 04:23:49.509312+00	2026-03-19 04:23:49.972289+00	12	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 926, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
223	2600b9be-6048-4dd4-9131-1b0b584e4bd7	compose-migrate-job	ad86372359b8	SUCCESS	\N	migrations applied	2026-03-19 04:39:03.150113+00	2026-03-19 04:39:03.3324+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1665, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
224	9c21b33d-9555-4e9c-a5f3-29bd2a76e0b8	compose-migrate-job	367415f1db4e	SUCCESS	\N	migrations applied	2026-03-19 04:57:25.784859+00	2026-03-19 04:57:26.235391+00	47	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 892, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
225	b2c52eae-d822-4968-b38a-cbb99ce6e9c3	compose-migrate-job	d22987242516	SUCCESS	\N	migrations applied	2026-03-19 05:04:08.0378+00	2026-03-19 05:04:08.312487+00	3	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 667, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
226	2cbc272d-f570-4b71-b5e7-0ea1ace02019	compose-migrate-job	0b50fb47a664	SUCCESS	\N	migrations applied	2026-03-19 05:12:58.660322+00	2026-03-19 05:12:58.963065+00	33	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 936, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
227	26a6d74d-ceae-43a8-8148-6e3b208b9a5f	compose-migrate-job	b366b561e1f8	SUCCESS	\N	migrations applied	2026-03-19 05:47:26.232288+00	2026-03-19 05:47:26.589247+00	25	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1415, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
232	dc399e05-07e0-4831-b5f4-eb487bbf3f33	compose-migrate-job	d8c4a5302b37	SUCCESS	\N	migrations applied	2026-03-19 07:40:00.747021+00	2026-03-19 07:40:01.043529+00	8	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 815, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
344	fca8498d-6dd7-488b-be6b-7a0da443b168	compose-migrate-job	619fdf3025c1	SUCCESS	\N	migrations applied	2026-03-24 09:43:23.563837+00	2026-03-24 09:43:23.924475+00	35	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1313, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
349	269eb9b3-c02f-4c90-864a-6e0a30cc9f84	compose-migrate-job	1b3a4b77ac09	SUCCESS	\N	migrations applied	2026-03-24 14:18:57.118341+00	2026-03-24 14:18:57.297155+00	27	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 559, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
354	df978b7b-1cd8-47fd-9ca8-7f0baa4220a2	compose-migrate-job	b7be46571f38	SUCCESS	\N	migrations applied	2026-03-25 02:05:39.22634+00	2026-03-25 02:05:39.400029+00	46	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 553, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
359	2af60aff-b4fe-4a2f-ba00-30431ee776a6	compose-migrate-job	ba303b47452e	SUCCESS	\N	migrations applied	2026-03-25 13:42:34.304637+00	2026-03-25 13:42:34.597914+00	33	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 606, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
364	e1266f64-1ce8-438e-b884-e3b2238ce02a	compose-migrate-job	ee73cefd1a89	SUCCESS	\N	migrations applied	2026-03-26 04:43:22.527488+00	2026-03-26 04:43:22.873647+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 746, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
369	9365ca3b-47c0-4c69-a9c9-92e59a0ebb28	compose-migrate-job	edc246aa3996	SUCCESS	\N	migrations applied	2026-03-26 13:24:11.637119+00	2026-03-26 13:24:11.932937+00	10	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1030, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
374	566458f3-4f5d-4e71-95ed-c6e8f3f3b5ce	compose-migrate-job	4a0575af9177	SUCCESS	\N	migrations applied	2026-03-28 06:55:14.067589+00	2026-03-28 06:55:14.296613+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 615, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
378	20946342-c88b-4ac5-a11b-94ad24b58139	compose-migrate-job	8a2a3b94f0bf	SUCCESS	\N	migrations applied	2026-03-29 08:21:35.531308+00	2026-03-29 08:21:35.734002+00	1	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 592, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
382	391c9d44-291e-4954-b772-709a5c20c04c	compose-migrate-job	5f336c75b184	SUCCESS	\N	migrations applied	2026-03-29 14:07:48.240371+00	2026-03-29 14:07:48.728528+00	71	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1400, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
386	a28470fb-72ea-408c-b512-72a5b2b337b8	compose-migrate-job	3636f81d86a6	SUCCESS	\N	migrations applied	2026-03-30 02:35:03.949371+00	2026-03-30 02:35:04.560873+00	46	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1426, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
390	fff8b9f3-c272-4144-8192-96b00613437f	compose-migrate-job	06aa5b55bab2	SUCCESS	\N	migrations applied	2026-03-30 12:26:39.397843+00	2026-03-30 12:26:39.548281+00	3	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 428, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
394	7a712ac2-9fa0-482a-9583-2ce071c57edc	compose-migrate-job	969eca8d80fe	SUCCESS	\N	migrations applied	2026-03-31 11:38:11.288794+00	2026-03-31 11:38:11.551121+00	29	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1176, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
233	1cf5c08b-ba55-4750-b8db-a719a62bb826	compose-migrate-job	ba4131a8578b	SUCCESS	\N	migrations applied	2026-03-19 08:00:58.595948+00	2026-03-19 08:00:58.996867+00	29	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1288, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
345	1a3e1354-efea-45be-8988-308474403039	compose-migrate-job	19cf96c264b0	SUCCESS	\N	migrations applied	2026-03-24 12:46:00.212738+00	2026-03-24 12:46:00.48589+00	5	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 380, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
350	9d80d485-cde4-4298-b79f-4ffb252ff253	compose-migrate-job	7d4c87c541ee	SUCCESS	\N	migrations applied	2026-03-24 15:32:20.243+00	2026-03-24 15:32:20.483396+00	10	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 883, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
355	b86c926f-c6ba-4e94-b761-a66ec20fe57c	compose-migrate-job	ba5232dc9918	SUCCESS	\N	migrations applied	2026-03-25 04:59:15.360616+00	2026-03-25 04:59:15.614608+00	9	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 742, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
360	d69c97af-47a1-4315-9a30-75057370a8c6	compose-migrate-job	3d78e1866e38	SUCCESS	\N	migrations applied	2026-03-25 13:51:44.812133+00	2026-03-25 13:51:44.998828+00	10	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1111, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
365	8d91881d-6b43-4e66-9ed2-7c3e9ee74cd7	compose-migrate-job	2d3b55ae243b	SUCCESS	\N	migrations applied	2026-03-26 04:50:06.193059+00	2026-03-26 04:50:06.37507+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 241, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
370	07903a08-7e84-45eb-8602-dda94fd432c9	compose-migrate-job	12a03f5c91de	SUCCESS	\N	migrations applied	2026-03-26 13:43:00.759787+00	2026-03-26 13:43:00.931174+00	7	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 395, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
375	66e97570-f3ad-4165-8918-5e9ceb541e81	compose-migrate-job	0190f21780e6	SUCCESS	\N	migrations applied	2026-03-28 07:19:39.213223+00	2026-03-28 07:19:39.559505+00	8	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 962, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
379	04970bba-6d6a-4792-b5f8-a895a056c5e8	compose-migrate-job	f7d6ffb6a25a	SUCCESS	\N	migrations applied	2026-03-29 08:32:52.580925+00	2026-03-29 08:32:52.757809+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 534, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
383	a118b83b-a783-4472-bc15-91c89daadc64	compose-migrate-job	8d1d8c299872	SUCCESS	\N	migrations applied	2026-03-29 14:47:53.535491+00	2026-03-29 14:47:53.780122+00	5	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 801, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
387	f4d47dc2-766d-4bce-bf0e-4f4eefea4d9f	compose-migrate-job	6e43e7d7e67c	SUCCESS	\N	migrations applied	2026-03-30 04:49:58.188734+00	2026-03-30 04:49:58.519002+00	23	{"pid": 10, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1173, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
391	354beb37-6756-462f-802a-512c55b5ef79	compose-migrate-job	a5b784428e12	SUCCESS	\N	migrations applied	2026-03-31 05:15:06.684754+00	2026-03-31 05:15:07.089817+00	48	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1312, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
234	e69571c8-1c3e-4080-bd16-9e6c43d417d3	compose-migrate-job	52602407dda8	SUCCESS	\N	migrations applied	2026-03-19 15:03:44.355107+00	2026-03-19 15:03:44.888096+00	47	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1196, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
346	28f7b77a-ebfb-4354-b81e-2fce1523674e	compose-migrate-job	4ef58a23964d	SUCCESS	\N	migrations applied	2026-03-24 13:24:52.645796+00	2026-03-24 13:24:52.876808+00	9	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 653, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
351	272284fb-720b-429c-b1e7-331d23a32746	compose-migrate-job	ae370e7e70c2	SUCCESS	\N	migrations applied	2026-03-24 16:12:54.641652+00	2026-03-24 16:12:54.950937+00	24	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 819, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
356	4b6cf8e7-67dc-46b1-8826-b61582c2287b	compose-migrate-job	377298ec5d01	SUCCESS	\N	migrations applied	2026-03-25 06:05:44.621669+00	2026-03-25 06:05:44.964348+00	11	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 754, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
361	8e27e36b-536b-4a35-806e-f48e0899e595	compose-migrate-job	0d1cd65b3d56	SUCCESS	\N	migrations applied	2026-03-25 14:28:44.099358+00	2026-03-25 14:28:44.447392+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1153, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
366	15963337-097f-44f6-8175-a839fecaaf8e	compose-migrate-job	2be5160eb961	SUCCESS	\N	migrations applied	2026-03-26 10:32:59.931875+00	2026-03-26 10:33:00.260123+00	38	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 522, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
371	f5f2e8df-9048-46ec-9137-6372c7f38880	compose-migrate-job	b1c957ae00a9	SUCCESS	\N	migrations applied	2026-03-26 13:54:04.390389+00	2026-03-26 13:54:04.572511+00	2	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 622, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
376	92af0548-1f89-4ae9-bf81-2be44aaa208e	compose-migrate-job	365893fdf07b	SUCCESS	\N	migrations applied	2026-03-29 06:33:12.066231+00	2026-03-29 06:33:12.7167+00	42	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1540, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
380	dd8f19a0-fd2c-4c39-a53a-84678ef3849e	compose-migrate-job	50d05769c8d2	SUCCESS	\N	migrations applied	2026-03-29 08:49:47.833011+00	2026-03-29 08:49:48.088732+00	21	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 871, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
384	ec1ce10e-0cbf-4a51-a80f-f838a98aae07	compose-migrate-job	b0b60c79df87	SUCCESS	\N	migrations applied	2026-03-29 15:08:21.036941+00	2026-03-29 15:08:21.32738+00	6	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 794, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
388	e4fda8b9-be35-417c-a1b4-f691924f1b7b	compose-migrate-job	56cfbebc9ccf	SUCCESS	\N	migrations applied	2026-03-30 04:56:31.673343+00	2026-03-30 04:56:31.821753+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 449, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
392	c52477cc-ed7a-4391-89c9-7f97eea57420	compose-migrate-job	6f7739729503	SUCCESS	\N	migrations applied	2026-03-31 09:56:14.527549+00	2026-03-31 09:56:14.76576+00	32	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1049, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
235	ab949efc-850b-40aa-b80e-aeef52160d9b	compose-migrate-job	2d5168178d80	SUCCESS	\N	migrations applied	2026-03-19 15:46:25.485748+00	2026-03-19 15:46:25.923194+00	7	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1632, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
347	2ce65f4a-e01c-4879-b3ff-b441ec0747e3	compose-migrate-job	ef72687facb8	SUCCESS	\N	migrations applied	2026-03-24 13:36:13.083479+00	2026-03-24 13:36:13.198161+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 271, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
352	61f53c5c-c487-4327-aa29-3460d644deea	compose-migrate-job	52a7181c3ba2	SUCCESS	\N	migrations applied	2026-03-24 23:23:49.682212+00	2026-03-24 23:23:50.021943+00	46	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 911, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
357	74c31ef9-7785-4a4d-a2be-6a4d96931f9a	compose-migrate-job	24b6b0383508	SUCCESS	\N	migrations applied	2026-03-25 09:31:12.611433+00	2026-03-25 09:31:13.095844+00	10	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1045, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
362	74afdd3f-e5bd-444b-8a7c-e7424cb8edb2	compose-migrate-job	096cc6c9006c	SUCCESS	\N	migrations applied	2026-03-26 03:34:28.164033+00	2026-03-26 03:34:28.910041+00	102	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 2040, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
367	e569a61a-ab8f-4bec-b849-bef69e8c39ef	compose-migrate-job	065b6b2d6ac0	SUCCESS	\N	migrations applied	2026-03-26 11:30:00.646943+00	2026-03-26 11:30:00.883401+00	17	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1186, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
372	04e09d52-dbd3-4c8f-b8dc-f3d0398dd00b	compose-migrate-job	5d051bf59aeb	SUCCESS	\N	migrations applied	2026-03-27 09:45:02.545403+00	2026-03-27 09:45:02.92391+00	7	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 791, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
377	b1b2ec20-5704-4312-9051-0cdc56763c02	compose-migrate-job	34410f3d76c3	SUCCESS	\N	migrations applied	2026-03-29 08:19:00.771329+00	2026-03-29 08:19:01.827187+00	30	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 2575, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
381	72232aec-dbd0-44df-846d-7c51abfc5e5d	compose-migrate-job	27950e89a278	SUCCESS	\N	migrations applied	2026-03-29 10:02:59.51092+00	2026-03-29 10:02:59.938187+00	94	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 932, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
385	d2eab47f-57eb-4f98-9b22-907b384c05b5	compose-migrate-job	aed5ea4f6b80	SUCCESS	\N	migrations applied	2026-03-29 18:05:10.874928+00	2026-03-29 18:05:11.436857+00	46	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1409, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
389	e2d8ea4a-4b74-4b5b-ace2-c7740ff1d263	compose-migrate-job	e995870fa011	SUCCESS	\N	migrations applied	2026-03-30 12:17:05.219935+00	2026-03-30 12:17:05.435887+00	35	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1511, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
393	2c0070d9-e79e-46a0-9efe-2cef927b3938	compose-migrate-job	b3ab94be53a8	SUCCESS	\N	migrations applied	2026-03-31 11:10:25.801675+00	2026-03-31 11:10:26.044323+00	4	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1137, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
236	018bf073-bd17-4244-a1a3-dce5c62baa13	compose-migrate-job	635167670a4f	SUCCESS	\N	migrations applied	2026-03-19 16:46:29.370166+00	2026-03-19 16:46:29.907779+00	64	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1090, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
237	335037d4-9d7e-4db5-b345-9292cfa278fd	compose-migrate-job	bf5548e7742a	SUCCESS	\N	migrations applied	2026-03-20 06:27:44.6414+00	2026-03-20 06:27:45.014979+00	39	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1228, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
238	d4e25983-6900-4e05-8746-dcff68d525df	compose-migrate-job	fa8e5d2e23a2	SUCCESS	\N	migrations applied	2026-03-20 06:43:37.622782+00	2026-03-20 06:43:38.016384+00	23	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1360, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
239	273c3fd2-92d8-4a45-8c9a-db9bdaf4dae2	compose-migrate-job	f2cfd064c235	SUCCESS	\N	migrations applied	2026-03-20 07:29:23.352575+00	2026-03-20 07:29:23.682029+00	13	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1233, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
240	1abc4695-e173-4115-9780-52624fbc5823	compose-migrate-job	3376a0709855	SUCCESS	\N	migrations applied	2026-03-20 07:44:11.584293+00	2026-03-20 07:44:11.841759+00	6	{"pid": 1, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1215, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
241	e1d50241-b017-4694-b36c-0c84a06e3ad2	compose-migrate-job	aa4f946190b6	SUCCESS	\N	migrations applied	2026-03-20 08:03:37.700941+00	2026-03-20 08:03:37.952511+00	6	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1093, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
242	fbc62576-384c-40e3-8e34-e4527f5772c6	compose-migrate-job	9079afdc9144	SUCCESS	\N	migrations applied	2026-03-20 08:15:56.626491+00	2026-03-20 08:15:56.927404+00	10	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 534, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
243	4872c7dc-b4ca-43fb-8def-3786a673aa19	compose-migrate-job	4ba8e6791373	SUCCESS	\N	migrations applied	2026-03-20 08:21:59.969342+00	2026-03-20 08:22:00.067759+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 170, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
244	48063828-1afe-433f-99c4-686fe3a7e43e	compose-migrate-job	ee759ca32cba	SUCCESS	\N	migrations applied	2026-03-20 08:26:29.254419+00	2026-03-20 08:26:29.354402+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 166, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
245	71c477f4-2e91-4691-9ef3-64944abbc4f7	compose-migrate-job	1073fcfe9739	SUCCESS	\N	migrations applied	2026-03-20 08:34:28.73267+00	2026-03-20 08:34:28.838629+00	3	{"pid": 7, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 174, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
246	49458ec7-5cb3-49c5-ab45-2aaaf5450388	compose-migrate-job	954adf02ab3a	SUCCESS	\N	migrations applied	2026-03-20 08:35:24.589568+00	2026-03-20 08:35:24.653399+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 127, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
247	8458973d-b90b-43e4-a65b-9daca300b796	compose-migrate-job	9616d721b3f7	SUCCESS	\N	migrations applied	2026-03-20 08:39:46.656967+00	2026-03-20 08:39:46.769468+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 286, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
248	4d22323c-ae23-4dcd-8a40-9f8f875a2f40	compose-migrate-job	bddaed94231e	SUCCESS	\N	migrations applied	2026-03-20 08:43:57.293903+00	2026-03-20 08:43:57.42772+00	1	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 196, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
249	4106fa49-2e55-48d6-a65c-bc8dafe4642c	compose-migrate-job	2a434525cd01	SUCCESS	\N	migrations applied	2026-03-20 08:47:45.391775+00	2026-03-20 08:47:45.552016+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 229, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
250	a82534c9-1715-4c25-9a32-32b559051de4	compose-migrate-job	39d36dd288d2	SUCCESS	\N	migrations applied	2026-03-20 08:53:50.483196+00	2026-03-20 08:53:50.677403+00	15	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 347, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
251	b089ef9b-2179-4e4a-924d-556b1e3947e8	compose-migrate-job	17840d1ddbc8	SUCCESS	\N	migrations applied	2026-03-20 08:58:46.751662+00	2026-03-20 08:58:46.909071+00	2	{"pid": 10, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 214, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
252	2a5e38ea-a141-4c7b-b610-6224720d808f	compose-migrate-job	07dbf5079b10	SUCCESS	\N	migrations applied	2026-03-20 09:03:46.670387+00	2026-03-20 09:03:46.820934+00	4	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 864, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
253	48062790-3fde-495e-8693-9c238a0b8b05	compose-migrate-job	c785da91350e	SUCCESS	\N	migrations applied	2026-03-20 09:05:16.473771+00	2026-03-20 09:05:16.570155+00	1	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 201, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
254	9614948a-406e-43e1-a815-5411b73be376	compose-migrate-job	e12f63c9693d	SUCCESS	\N	migrations applied	2026-03-20 09:10:43.545529+00	2026-03-20 09:10:43.674471+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 194, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
255	73a32324-98c5-4e3e-b142-82c0dee9aa08	compose-migrate-job	9089edf2af38	SUCCESS	\N	migrations applied	2026-03-20 09:14:52.372369+00	2026-03-20 09:14:52.561147+00	2	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 254, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
256	9b9c11c6-43a8-46b6-9483-2c4b7da22745	compose-migrate-job	9d63b0ee8e5f	SUCCESS	\N	migrations applied	2026-03-20 09:19:07.694778+00	2026-03-20 09:19:07.840339+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 221, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
257	b69f069d-6da2-4f06-a309-56fb1bee2e14	compose-migrate-job	eca270656ab4	SUCCESS	\N	migrations applied	2026-03-20 09:22:53.66929+00	2026-03-20 09:22:53.966004+00	26	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 599, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
258	132efbf5-846e-41c7-a3e2-2d26e848b462	compose-migrate-job	fd372bb33a09	SUCCESS	\N	migrations applied	2026-03-20 09:23:56.99487+00	2026-03-20 09:23:57.108738+00	2	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 171, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
259	6e986c6d-2d19-48da-87fe-157bb3761da7	compose-migrate-job	bac77cca4cc8	SUCCESS	\N	migrations applied	2026-03-20 09:26:00.931102+00	2026-03-20 09:26:01.113418+00	1	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 254, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
260	40b82f0d-92d7-4d75-938c-716492ad6c50	compose-migrate-job	e346b5b3cf09	SUCCESS	\N	migrations applied	2026-03-20 09:27:06.778621+00	2026-03-20 09:27:06.880153+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 164, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
261	99b355f8-ed41-40a4-957f-77ebbfc0b57d	compose-migrate-job	dcb634ccac15	SUCCESS	\N	migrations applied	2026-03-20 09:29:06.000694+00	2026-03-20 09:29:06.074868+00	1	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 128, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
262	28cf7729-df68-486f-8d44-a3eeb447e5c2	compose-migrate-job	d08cf5d7c704	SUCCESS	\N	migrations applied	2026-03-20 09:29:58.95758+00	2026-03-20 09:29:59.030488+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 132, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
263	31e4acbe-8286-447c-a9bf-2760d2d16222	compose-migrate-job	79bb308cb072	SUCCESS	\N	migrations applied	2026-03-20 09:31:43.922665+00	2026-03-20 09:31:44.072906+00	2	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 243, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
264	f025f19a-cddd-455b-b5a9-3f0f96abbd85	compose-migrate-job	cc8bf51c7701	SUCCESS	\N	migrations applied	2026-03-20 09:32:39.758352+00	2026-03-20 09:32:39.829984+00	1	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 142, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
265	48a8771c-bf63-46a7-8f8b-5fa07d423db2	compose-migrate-job	89bda6f753af	SUCCESS	\N	migrations applied	2026-03-20 09:34:18.039754+00	2026-03-20 09:34:18.139344+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 168, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
266	4771f4b6-fb34-4f0a-a531-529bccf00ba5	compose-migrate-job	c0ddcee95a39	SUCCESS	\N	migrations applied	2026-03-20 09:35:11.957857+00	2026-03-20 09:35:12.029802+00	1	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 153, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
267	12e58373-8b89-4fc1-87de-e540565f405f	compose-migrate-job	5a20ce1a3536	SUCCESS	\N	migrations applied	2026-03-20 10:04:57.888492+00	2026-03-20 10:04:58.055365+00	15	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 336, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
268	6f648568-d887-47df-baf6-62879d80fc40	compose-migrate-job	b693e36abd7d	SUCCESS	\N	migrations applied	2026-03-20 13:51:15.426387+00	2026-03-20 13:51:15.735748+00	21	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 682, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
269	b1f58894-0350-4518-8a85-f6f95b8804af	compose-migrate-job	902eb8986d7b	SUCCESS	\N	migrations applied	2026-03-20 13:58:52.969987+00	2026-03-20 13:58:53.223093+00	9	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1154, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
270	9dcf78ca-059e-4102-afd5-70a268906e0d	compose-migrate-job	c567b3fe654c	SUCCESS	\N	migrations applied	2026-03-20 14:18:28.269969+00	2026-03-20 14:18:28.484151+00	25	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 746, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
271	a9b5703c-75db-4b8e-8963-66d28df9896e	compose-migrate-job	bbf3a839ceb9	SUCCESS	\N	migrations applied	2026-03-20 14:34:01.517139+00	2026-03-20 14:34:01.665063+00	6	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 555, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
272	d29148e2-d912-450c-a070-673e255729ab	compose-migrate-job	8fea8d0c4797	SUCCESS	\N	migrations applied	2026-03-20 14:46:56.465864+00	2026-03-20 14:46:56.683354+00	22	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1050, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
273	f2b6548d-7b27-48f9-9525-43f0775609f2	compose-migrate-job	f8b26dfb5824	SUCCESS	\N	migrations applied	2026-03-20 14:57:45.931909+00	2026-03-20 14:57:46.042699+00	3	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 240, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
274	6f8d15d0-78c4-455e-84ae-7f2d84778a6d	compose-migrate-job	2b8603718746	SUCCESS	\N	migrations applied	2026-03-20 15:11:43.490156+00	2026-03-20 15:11:43.844199+00	15	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1078, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
275	753f7659-6eab-44ea-8fea-ee26d18a6cba	compose-migrate-job	57a3f76b401c	SUCCESS	\N	migrations applied	2026-03-20 15:26:11.408283+00	2026-03-20 15:26:11.751074+00	48	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1583, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
276	8394f3a9-e75d-4fcf-a44a-bdebbec56f98	compose-migrate-job	7087bc6ba45e	SUCCESS	\N	migrations applied	2026-03-20 16:23:45.847734+00	2026-03-20 16:23:46.214901+00	12	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 680, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
277	fd858feb-0873-414e-bcdb-ca2fd9bfa847	compose-migrate-job	ce3fe8e4cd26	SUCCESS	\N	migrations applied	2026-03-21 10:28:18.025037+00	2026-03-21 10:28:18.414182+00	8	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 601, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
278	b0daa7d9-29ca-4d46-a70c-ba6aa0b3eec5	compose-migrate-job	bf19df13d4b8	SUCCESS	\N	migrations applied	2026-03-21 10:43:10.235953+00	2026-03-21 10:43:10.393809+00	3	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1171, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
279	a424380a-e5d5-4d22-be2a-93f1538cae58	compose-migrate-job	2b00095310a1	SUCCESS	\N	migrations applied	2026-03-21 11:01:39.632149+00	2026-03-21 11:01:39.828327+00	9	{"pid": 10, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 808, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
280	7ec593dc-599c-46ca-b0cd-c66670125bbe	compose-migrate-job	8dcdddcb2e63	SUCCESS	\N	migrations applied	2026-03-21 11:24:04.846284+00	2026-03-21 11:24:05.026156+00	8	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 770, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
281	cb5ca902-825a-49b8-bf81-b06d5ee52d79	compose-migrate-job	47cadbd9cc57	SUCCESS	\N	migrations applied	2026-03-21 11:39:59.552979+00	2026-03-21 11:39:59.855624+00	7	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 979, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
282	63bb2bd6-2475-48d0-be49-c803169f5ff0	compose-migrate-job	adb757437fa3	SUCCESS	\N	migrations applied	2026-03-21 12:55:40.549974+00	2026-03-21 12:55:40.843906+00	23	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1526, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
283	db7b57e0-86de-4e48-a24a-36f8bff1c442	compose-migrate-job	f1ddf6c47b74	SUCCESS	\N	migrations applied	2026-03-21 13:21:55.144002+00	2026-03-21 13:21:55.455335+00	34	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 500, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
284	fc43752b-80ee-4a12-bfcd-a59d1a8a1dd7	compose-migrate-job	ca07c6fbb9ad	SUCCESS	\N	migrations applied	2026-03-21 13:37:44.941272+00	2026-03-21 13:37:45.131735+00	4	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 435, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
285	63038b64-8fc3-44a7-9971-e63766c4f6c5	compose-migrate-job	d0dcfdc8fc46	SUCCESS	\N	migrations applied	2026-03-21 13:52:50.568784+00	2026-03-21 13:52:50.890756+00	50	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 574, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
286	5b5ec234-796f-4b65-92c7-c9e9ca2ac8a2	compose-migrate-job	95117e0f2eb0	SUCCESS	\N	migrations applied	2026-03-21 14:00:30.482992+00	2026-03-21 14:00:30.710979+00	7	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1417, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
287	9b2a9bb6-25af-4f9f-852a-2a3d45d91b32	compose-migrate-job	aa16791da4de	SUCCESS	\N	migrations applied	2026-03-21 14:15:05.87383+00	2026-03-21 14:15:06.108882+00	4	{"pid": 10, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 697, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
288	85b19005-7e86-4c8f-aa5a-834534d229d5	compose-migrate-job	28568d6aba20	SUCCESS	\N	migrations applied	2026-03-21 14:25:28.998828+00	2026-03-21 14:25:29.305426+00	43	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 852, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
289	9f838866-e05f-41f5-8d47-70af7d8e1637	compose-migrate-job	9d5a5e5741e9	SUCCESS	\N	migrations applied	2026-03-21 14:37:52.168853+00	2026-03-21 14:37:52.570971+00	6	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1742, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
290	d526191a-f48b-4373-b823-1e8cdd16f1a8	compose-migrate-job	c0f733b6c3d3	SUCCESS	\N	migrations applied	2026-03-21 15:22:01.445483+00	2026-03-21 15:22:01.74497+00	14	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 643, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
291	3b998727-a0d6-489b-a3e1-af0af8fde792	compose-migrate-job	fb43529e4697	SUCCESS	\N	migrations applied	2026-03-21 15:31:03.633152+00	2026-03-21 15:31:03.912134+00	3	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1377, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
292	44437c39-c9c7-482b-bfcb-6df11dffc12a	compose-migrate-job	b293bb94215a	SUCCESS	\N	migrations applied	2026-03-21 15:37:09.752677+00	2026-03-21 15:37:10.090978+00	5	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 685, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
293	274b0866-9084-4260-8bd1-49220e135878	compose-migrate-job	e21206086b9e	SUCCESS	\N	migrations applied	2026-03-21 16:28:18.391644+00	2026-03-21 16:28:18.853335+00	31	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1112, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
294	0aaf948e-c10f-4f81-9541-013bd31ae080	compose-migrate-job	91d388d48440	SUCCESS	\N	migrations applied	2026-03-21 17:02:09.857413+00	2026-03-21 17:02:10.392224+00	94	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 807, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
295	8bcb69d0-ea3d-4b7a-ad01-92e02d863dcb	compose-migrate-job	4b5eb4624429	SUCCESS	\N	migrations applied	2026-03-21 17:12:25.111924+00	2026-03-21 17:12:25.477227+00	5	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1350, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
296	85348597-ae2e-48a0-8a31-5e3da4155034	compose-migrate-job	81e9e5a8452f	SUCCESS	\N	migrations applied	2026-03-21 17:38:14.917674+00	2026-03-21 17:38:15.173634+00	8	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 801, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
297	3b4c4e99-4d5b-4f47-b6df-15e26e59d6f1	compose-migrate-job	34a89c2139fc	SUCCESS	\N	migrations applied	2026-03-21 17:56:13.254212+00	2026-03-21 17:56:13.459861+00	5	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 616, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
298	ce6b071f-77c8-45d8-a5e9-3148f3cc2f42	compose-migrate-job	7217442bd495	SUCCESS	\N	migrations applied	2026-03-21 18:13:06.171321+00	2026-03-21 18:13:06.370189+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 591, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
299	d8d83483-22b4-46eb-837a-0eaa379cbf51	compose-migrate-job	59048c18fd25	SUCCESS	\N	migrations applied	2026-03-22 05:06:07.416214+00	2026-03-22 05:06:07.680348+00	12	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 509, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
300	c45b3632-7c64-48d7-a62e-e3eb285946f1	compose-migrate-job	b72383c9cf77	SUCCESS	\N	migrations applied	2026-03-22 05:10:55.311905+00	2026-03-22 05:10:55.523132+00	1	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 532, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
301	ce97deee-4135-4245-a10b-91d6b362f325	compose-migrate-job	c9670517a577	SUCCESS	\N	migrations applied	2026-03-22 07:24:50.471334+00	2026-03-22 07:24:51.037748+00	20	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1715, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
302	d59ea4a2-514d-400d-a79a-38e10e3e292c	compose-migrate-job	6d027ac8e12f	SUCCESS	\N	migrations applied	2026-03-22 07:41:08.908513+00	2026-03-22 07:41:09.321517+00	1	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 2556, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
303	9dbc0e63-4fb5-41cf-b8ca-59cc969995d9	compose-migrate-job	4f1ccd37f50e	SUCCESS	\N	migrations applied	2026-03-22 07:54:24.697112+00	2026-03-22 07:54:24.932599+00	11	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 560, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
304	1cfe864f-1936-4532-b850-824c453cadbb	compose-migrate-job	63bef42dac77	SUCCESS	\N	migrations applied	2026-03-22 08:14:56.348836+00	2026-03-22 08:14:56.47949+00	4	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 385, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
305	ed187242-91cc-47a4-abcd-9566bfddb098	compose-migrate-job	0b05c1394b04	SUCCESS	\N	migrations applied	2026-03-22 13:53:04.113895+00	2026-03-22 13:53:04.690135+00	17	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1364, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
306	42125fc6-71a8-43ff-9a7b-4cdc018c12a9	compose-migrate-job	ea7a6a3d9c0d	SUCCESS	\N	migrations applied	2026-03-22 14:05:43.250073+00	2026-03-22 14:05:43.329708+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 267, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
307	5240f880-688e-47d9-9c59-5ff5349d2a05	compose-migrate-job	3bfee71740b3	SUCCESS	\N	migrations applied	2026-03-22 14:18:50.173413+00	2026-03-22 14:18:50.427862+00	9	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 603, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
308	d1e39b43-5909-4ea4-ab05-772044640e82	compose-migrate-job	41f51e005917	SUCCESS	\N	migrations applied	2026-03-22 14:29:09.66973+00	2026-03-22 14:29:09.847349+00	1	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 352, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
309	b1c5d496-8f0c-471f-afe2-2b5a0ba696f5	compose-migrate-job	54cf0c4feeee	SUCCESS	\N	migrations applied	2026-03-22 14:50:29.194491+00	2026-03-22 14:50:29.440644+00	4	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1121, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
310	74830ce0-6515-4912-bda5-4a13cbb3e6d7	compose-migrate-job	7b4ea3a4d84c	SUCCESS	\N	migrations applied	2026-03-22 15:07:33.422764+00	2026-03-22 15:07:33.892379+00	17	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1581, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
311	3d52ec71-d43f-4c60-8782-00e36ad81a98	compose-migrate-job	8c4dd34f0e26	SUCCESS	\N	migrations applied	2026-03-22 15:29:00.46383+00	2026-03-22 15:29:00.714914+00	27	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 533, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
312	567b940d-b02d-44ee-b8f7-c9964dcc3d8f	compose-migrate-job	8864c9c6b291	SUCCESS	\N	migrations applied	2026-03-22 23:22:17.117611+00	2026-03-22 23:22:17.605124+00	33	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1456, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
313	7f4bbf28-1182-4935-a1b1-7e73e8680997	compose-migrate-job	0338b43b2b40	SUCCESS	\N	migrations applied	2026-03-23 00:52:31.697548+00	2026-03-23 00:52:32.0775+00	49	{"pid": 7, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1190, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
314	02db6134-dc34-49f5-bb8c-ef1d0cb9096f	compose-migrate-job	72572ad56bf9	SUCCESS	\N	migrations applied	2026-03-23 01:13:38.272801+00	2026-03-23 01:13:38.617682+00	34	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 633, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
315	0178e920-7fbb-415c-87b7-4dc426a64347	compose-migrate-job	1633a816b5ce	SUCCESS	\N	migrations applied	2026-03-23 01:28:26.180773+00	2026-03-23 01:28:26.320694+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 198, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
316	44fc9c39-c141-4b2e-8285-7d82c7b1cd45	compose-migrate-job	9563224b676c	SUCCESS	\N	migrations applied	2026-03-23 01:35:19.780476+00	2026-03-23 01:35:20.093046+00	4	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 773, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
317	395fb44e-dc5c-4d37-b1c9-25b8f9b0ece0	compose-migrate-job	b2d1450441d3	SUCCESS	\N	migrations applied	2026-03-23 01:46:50.324337+00	2026-03-23 01:46:50.556939+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 766, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
318	529857f3-931d-4b96-abde-f8f48684e64e	compose-migrate-job	ca5c8733726d	SUCCESS	\N	migrations applied	2026-03-23 02:33:25.704556+00	2026-03-23 02:33:26.250424+00	35	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1786, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
319	e401bc37-f44c-4913-96af-28bb80daa317	compose-migrate-job	463c7deefe22	SUCCESS	\N	migrations applied	2026-03-23 02:49:39.88097+00	2026-03-23 02:49:40.054709+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 600, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
320	124570a7-0e9e-425b-954b-c5bf1bb7993a	compose-migrate-job	69ca55e2d2c7	SUCCESS	\N	migrations applied	2026-03-23 05:10:54.729633+00	2026-03-23 05:10:55.10177+00	15	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1076, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
321	62d5e7d6-9130-412a-b5ac-083d33615c34	compose-migrate-job	4e6a4f28a37c	SUCCESS	\N	migrations applied	2026-03-23 05:39:28.429358+00	2026-03-23 05:39:28.725837+00	7	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 499, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
322	8e18e3bf-b5ce-48a1-a0ba-f660b4ea7d88	compose-migrate-job	133b76d2bed6	SUCCESS	\N	migrations applied	2026-03-23 09:43:39.921282+00	2026-03-23 09:43:40.321065+00	6	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 657, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
323	8631a2e7-6bd7-4442-bd02-f80b10768d2e	compose-migrate-job	e03c12c47033	SUCCESS	\N	migrations applied	2026-03-23 10:20:42.058195+00	2026-03-23 10:20:42.256183+00	38	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 758, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
324	9f26eb7d-83b9-46ab-b190-dd7d1b8791d1	compose-migrate-job	b37528d5fc64	SUCCESS	\N	migrations applied	2026-03-23 14:01:57.539608+00	2026-03-23 14:01:58.025482+00	50	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1447, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
325	b2a9cfeb-9c9e-49ff-aee6-576c70463775	compose-migrate-job	0ecf587a62ad	SUCCESS	\N	migrations applied	2026-03-23 14:19:43.464388+00	2026-03-23 14:19:43.828585+00	30	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 664, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
326	22e084ba-32be-4a48-9baf-af5e1d47f38a	compose-migrate-job	3dc371c836f3	SUCCESS	\N	migrations applied	2026-03-23 15:46:54.785672+00	2026-03-23 15:46:55.178273+00	31	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1454, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
327	702cd490-a620-4cf8-b42f-cf56496fd084	compose-migrate-job	c01abb2892ea	SUCCESS	\N	migrations applied	2026-03-23 16:23:40.056896+00	2026-03-23 16:23:40.287542+00	16	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 572, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
328	23671c19-ebcd-4255-afdf-3a3ea7f9cdd0	compose-migrate-job	1f0a7c418695	SUCCESS	\N	migrations applied	2026-03-24 01:33:54.202089+00	2026-03-24 01:33:54.77554+00	50	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1738, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
329	305b39f8-eeee-4087-a7ad-a0f051ee062f	compose-migrate-job	d95722a12940	SUCCESS	\N	migrations applied	2026-03-24 04:22:19.566173+00	2026-03-24 04:22:19.969663+00	25	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 939, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
330	deae9f3c-f751-4054-9a42-3c3ee4f91acd	compose-migrate-job	049d1fd39361	SUCCESS	\N	migrations applied	2026-03-24 06:29:37.924304+00	2026-03-24 06:29:38.325797+00	52	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1640, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
348	bd4de192-ce21-4cdf-9891-bfe0eff8f902	compose-migrate-job	9c0efd17226d	SUCCESS	\N	migrations applied	2026-03-24 13:49:46.691661+00	2026-03-24 13:49:47.134818+00	53	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1011, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
331	d8b7c6d6-b428-49ba-a7ac-f46c8643ffbc	compose-migrate-job	3e74e72b5edf	SUCCESS	\N	migrations applied	2026-03-24 06:36:46.198711+00	2026-03-24 06:36:46.332926+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 211, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
353	d95c0f59-15c8-45a8-92ae-0e2617d3cda6	compose-migrate-job	3f32355a6d4d	SUCCESS	\N	migrations applied	2026-03-25 01:46:58.863686+00	2026-03-25 01:46:59.128682+00	5	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 868, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
332	ce11b0ec-9ad9-4d70-9624-fafcc1d87ca4	compose-migrate-job	da9e18debc07	SUCCESS	\N	migrations applied	2026-03-24 06:41:48.080598+00	2026-03-24 06:41:48.211791+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 537, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
358	d9c76127-9cbf-46ed-9c6e-0e75a0dd537c	compose-migrate-job	41a3db42a06b	SUCCESS	\N	migrations applied	2026-03-25 13:19:36.357788+00	2026-03-25 13:19:36.795648+00	38	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1298, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
333	7affb404-fdc0-4a52-b74b-edcaa7fed2ed	compose-migrate-job	9886d7f26592	SUCCESS	\N	migrations applied	2026-03-24 06:47:18.656143+00	2026-03-24 06:47:18.798504+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 212, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
363	34f51a42-fae0-488c-ad7a-7bc8631f83b7	compose-migrate-job	925913c9af8f	SUCCESS	\N	migrations applied	2026-03-26 04:29:53.381805+00	2026-03-26 04:29:53.682781+00	9	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1626, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
334	773f4c24-0748-4946-883f-0b17f7b7871e	compose-migrate-job	bc45b944b396	SUCCESS	\N	migrations applied	2026-03-24 07:05:13.472912+00	2026-03-24 07:05:13.752012+00	30	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1056, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
368	37583a2d-c0bb-4d5f-a537-abe4b2aa6a82	compose-migrate-job	8db092a78f13	SUCCESS	\N	migrations applied	2026-03-26 13:17:41.802676+00	2026-03-26 13:17:42.792814+00	129	{"pid": 9, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 2693, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
335	d0cf5062-5439-4f20-b221-355df9e64430	compose-migrate-job	0ec7d11350d9	SUCCESS	\N	migrations applied	2026-03-24 07:12:06.28795+00	2026-03-24 07:12:06.424571+00	1	{"pid": 7, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 298, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
336	bd2e5c74-ca16-41e1-a997-d3f6f5a842f7	compose-migrate-job	b17928972d28	SUCCESS	\N	migrations applied	2026-03-24 07:30:25.614421+00	2026-03-24 07:30:25.925379+00	52	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 542, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
373	0138aa7d-c751-4a39-b965-24bf34c3e37c	compose-migrate-job	ea16742f9861	SUCCESS	\N	migrations applied	2026-03-28 06:36:48.614213+00	2026-03-28 06:36:49.233881+00	90	{"pid": 10, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 1522, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
337	ad939e9d-6a07-45c3-b723-e31b115bae90	compose-migrate-job	7edad039f720	SUCCESS	\N	migrations applied	2026-03-24 07:45:21.690493+00	2026-03-24 07:45:21.837643+00	2	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 377, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
338	76fc9bb8-086d-4e97-887f-a1a29433af77	compose-migrate-job	6c82e1882ea4	SUCCESS	\N	migrations applied	2026-03-24 07:55:07.740255+00	2026-03-24 07:55:07.956183+00	9	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 805, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
339	464c1510-f045-44cf-a5a6-304b5d59fc98	compose-migrate-job	3707cacab4ac	SUCCESS	\N	migrations applied	2026-03-24 08:02:36.702226+00	2026-03-24 08:02:36.80025+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 516, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
340	b3879fd1-1e8f-411d-82d8-3f10bdc49946	compose-migrate-job	88836b81f661	SUCCESS	\N	migrations applied	2026-03-24 08:05:59.206992+00	2026-03-24 08:05:59.352764+00	5	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 366, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
341	ce9ba2d9-f406-4a05-a624-5eb35593d625	compose-migrate-job	b2b87bbcd91f	SUCCESS	\N	migrations applied	2026-03-24 08:09:29.364205+00	2026-03-24 08:09:29.618985+00	10	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 581, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
342	451e5a07-8d32-4d6f-8054-1e764e948606	compose-migrate-job	385fb89184d0	SUCCESS	\N	migrations applied	2026-03-24 08:18:04.627065+00	2026-03-24 08:18:04.753799+00	1	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 481, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
343	f74ea202-1027-4d52-8700-a98cd7480c78	compose-migrate-job	74710a896c7d	SUCCESS	\N	migrations applied	2026-03-24 08:39:08.722883+00	2026-03-24 08:39:08.907179+00	3	{"pid": 8, "retry": {"delayMs": 2000, "maxAttempts": 30}, "durationMs": 280, "advisoryLock": {"lockId": 872341, "pollMs": 1500, "enabled": true, "maxWaitMs": 180000}}
\.


--
-- Data for Name: plan; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.plan (id, user_id, name, type, root_program_version_id, params, is_archived, created_at, updated_at) FROM stdin;
ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	Tactical Barbell Operator Custom Program	MANUAL	27fe4212-7141-4e9a-ab28-bd5bead7de39	{"schedule": ["D1", "D2", "D3"], "timezone": "Asia/Seoul", "startDate": "2026-03-08", "oneRepMaxKg": {"PULL": 110, "BENCH": 105, "SQUAT": 105, "EX_PULL_UP": 110, "EX_BACK_SQUAT": 105, "EX_BENCH_PRESS": 105}, "trainingMaxKg": {"PULL": 100, "BENCH": 95, "SQUAT": 95, "EX_PULL_UP": 100, "EX_BACK_SQUAT": 95, "EX_BENCH_PRESS": 95}, "sessionKeyMode": "DATE", "autoProgression": true, "sessionsPerWeek": 3}	f	2026-03-08 09:38:00.573123+00	2026-03-08 09:38:00.573123+00
\.


--
-- Data for Name: plan_module; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.plan_module (id, plan_id, target, program_version_id, priority, params, created_at) FROM stdin;
\.


--
-- Data for Name: plan_override; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.plan_override (id, plan_id, scope, week_number, session_key, patch, note, created_at) FROM stdin;
\.


--
-- Data for Name: plan_progress_event; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.plan_progress_event (id, plan_id, log_id, user_id, event_type, program_slug, reason, before_state, after_state, meta, created_at) FROM stdin;
46858f95-db6d-487e-9e65-d2d5c97e134c	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	6cce3d40-8f0e-4596-8405-d8f46c3f5158	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{"day": 2, "week": 2, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 4, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 4, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 4, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 4, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 4, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "4fe9cded-8226-424e-8191-79e1483b08a0"}	{"day": 3, "week": 2, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 5, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 5, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 5, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 5, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 5, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "6cce3d40-8f0e-4596-8405-d8f46c3f5158"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 40, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 80, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 75, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 75, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 80, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 5, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 4, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 5, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 4, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 5, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 4, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 5, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 4, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 5, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 4, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}], "didAdvanceSession": true}	2026-03-21 07:41:57.40412+00
acac97ec-d6fd-40ff-bc44-a4101d09edb4	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	b0889cb1-17fd-4a47-89a8-cab72d238571	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{"day": 3, "week": 2, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 5, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 5, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 5, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 5, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 5, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "6cce3d40-8f0e-4596-8405-d8f46c3f5158"}	{"day": 1, "week": 3, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 6, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 6, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 6, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 6, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 6, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "b0889cb1-17fd-4a47-89a8-cab72d238571"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 40, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 80, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 75, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 75, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 80, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 6, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 5, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 6, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 5, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 6, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 5, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 6, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 5, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 6, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 5, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}], "didAdvanceSession": true}	2026-03-23 13:17:53.474925+00
8869e612-d3ac-4cdb-a905-eb28cb85788f	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	40444490-586e-47eb-9616-9e55d24ddfcd	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{"day": 1, "week": 3, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 6, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 6, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 6, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 6, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 6, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "b0889cb1-17fd-4a47-89a8-cab72d238571"}	{"day": 2, "week": 3, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 7, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 7, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 7, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 7, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 7, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "40444490-586e-47eb-9616-9e55d24ddfcd"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 45, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 90, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 85, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 85, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 90, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 7, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 6, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 7, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 6, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 7, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 6, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 7, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 6, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 7, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 6, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}], "didAdvanceSession": true}	2026-03-26 13:56:28.670759+00
63fdb2d6-e294-4ede-9d7c-7e27111445cb	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{"day": 2, "week": 3, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 7, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 7, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 7, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 7, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 7, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "40444490-586e-47eb-9616-9e55d24ddfcd"}	{"day": 3, "week": 3, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 8, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 8, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 8, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 8, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 8, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 45, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 90, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 85, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 85, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 90, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 8, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 7, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 8, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 7, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 8, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 7, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 8, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 7, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 8, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 7, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}], "didAdvanceSession": true}	2026-03-28 09:48:01.553781+00
e9fb5cd4-39da-47f9-90ff-d3e8edb97726	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	ce3a8533-fb17-402c-874d-60a5b456ad67	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{}	{"day": 2, "week": 1, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 1, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 1, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 1, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 1, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 1, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "ce3a8533-fb17-402c-874d-60a5b456ad67"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 35, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 70, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 67.5, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 67.5, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 70, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 1, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 0, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 1, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 0, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 1, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 0, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 1, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 0, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}, {"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 1, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 0, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}], "didAdvanceSession": true}	2026-03-08 10:16:06.779713+00
0f02f10b-6339-46e6-9eb7-1d211c73b92f	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{"day": 2, "week": 1, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 1, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 1, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 1, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 1, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 1, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "ce3a8533-fb17-402c-874d-60a5b456ad67"}	{"day": 3, "week": 1, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 2, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 2, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 2, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 2, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 2, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "bf2f95ab-2490-481f-b5f3-9e1c1feffcd2"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 35, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 70, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 67.5, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 67.5, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 70, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 2, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 1, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 2, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 1, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 2, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 1, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 2, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 1, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 2, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 1, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}], "didAdvanceSession": true}	2026-03-10 12:20:31.320398+00
37d05d23-3c8b-4d24-861b-d3ec3cdd5a4d	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{"day": 3, "week": 1, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 2, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 2, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 2, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 2, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 2, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "bf2f95ab-2490-481f-b5f3-9e1c1feffcd2"}	{"day": 1, "week": 2, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 3, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 3, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 3, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 3, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 3, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "6d38ab34-3973-4dc5-862a-27f5adb8c7d1"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 35, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 72.5, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 67.5, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 67.5, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 70, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 3, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 2, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 3, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 2, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 3, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 2, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 3, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 2, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 3, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 2, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}], "didAdvanceSession": true}	2026-03-15 10:00:37.288854+00
4eb0ed82-f19f-46df-b4f6-7258d48a9dcf	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	4fe9cded-8226-424e-8191-79e1483b08a0	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{"day": 1, "week": 2, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 3, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 3, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 3, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 3, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 3, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "6d38ab34-3973-4dc5-862a-27f5adb8c7d1"}	{"day": 2, "week": 2, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 4, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 4, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 4, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 4, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 4, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "4fe9cded-8226-424e-8191-79e1483b08a0"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 40, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 80, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 75, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 75, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 80, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 4, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 3, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 4, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 3, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 4, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 3, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 4, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 3, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 4, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 3, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}], "didAdvanceSession": true}	2026-03-17 13:17:24.600641+00
c95c31b7-f58c-4f3e-9652-58d70c058968	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	0fe3d7bb-64f3-4668-be04-89470f55d634	dev	ADVANCE_WEEK	tactical-barbell-operator-custom-mmhk641d	advance:session	{"day": 3, "week": 3, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 8, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 8, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 8, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 8, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 8, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd"}	{"day": 1, "week": 4, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 9, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 9, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 9, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 9, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 9, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "0fe3d7bb-64f3-4668-be04-89470f55d634"}	{"outcomes": {"OHP": {"total": 1, "successful": 1, "displayTarget": "Overhead Press", "progressionKey": "OHP", "averageWeightKg": 45, "progressionTarget": "OHP"}, "PULL": {"total": 3, "successful": 3, "displayTarget": "Pull-Up", "progressionKey": "PULL", "averageWeightKg": 90, "progressionTarget": "PULL"}, "BENCH": {"total": 3, "successful": 3, "displayTarget": "Bench Press", "progressionKey": "BENCH", "averageWeightKg": 85, "progressionTarget": "BENCH"}, "SQUAT": {"total": 3, "successful": 3, "displayTarget": "Back Squat", "progressionKey": "SQUAT", "averageWeightKg": 85, "progressionTarget": "SQUAT"}, "DEADLIFT": {"total": 1, "successful": 1, "displayTarget": "Deadlift", "progressionKey": "DEADLIFT", "averageWeightKg": 90, "progressionTarget": "DEADLIFT"}}, "engineVersion": 1, "targetDecisions": [{"key": "OHP", "after": {"workKg": 35, "failureStreak": 0, "successStreak": 9, "progressionTarget": "OHP"}, "before": {"workKg": 35, "failureStreak": 0, "successStreak": 8, "progressionTarget": "OHP"}, "reason": "hold:block-success", "target": "Overhead Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "OHP"}, {"key": "PULL", "after": {"workKg": 100, "failureStreak": 0, "successStreak": 9, "progressionTarget": "PULL"}, "before": {"workKg": 100, "failureStreak": 0, "successStreak": 8, "progressionTarget": "PULL"}, "reason": "hold:block-success", "target": "Pull-Up", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "PULL"}, {"key": "BENCH", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 9, "progressionTarget": "BENCH"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 8, "progressionTarget": "BENCH"}, "reason": "hold:block-success", "target": "Bench Press", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "BENCH"}, {"key": "SQUAT", "after": {"workKg": 95, "failureStreak": 0, "successStreak": 9, "progressionTarget": "SQUAT"}, "before": {"workKg": 95, "failureStreak": 0, "successStreak": 8, "progressionTarget": "SQUAT"}, "reason": "hold:block-success", "target": "Back Squat", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "SQUAT"}, {"key": "DEADLIFT", "after": {"workKg": 70, "failureStreak": 0, "successStreak": 9, "progressionTarget": "DEADLIFT"}, "before": {"workKg": 70, "failureStreak": 0, "successStreak": 8, "progressionTarget": "DEADLIFT"}, "reason": "hold:block-success", "target": "Deadlift", "outcome": "SUCCESS", "eventType": "HOLD", "progressionTarget": "DEADLIFT"}], "didAdvanceSession": true}	2026-03-31 13:03:15.680054+00
\.


--
-- Data for Name: plan_runtime_state; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.plan_runtime_state (id, plan_id, user_id, engine_version, state, created_at, updated_at) FROM stdin;
5ce10645-6c70-4f8c-a0e3-4f7e87496164	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	dev	1	{"day": 1, "week": 4, "cycle": 1, "targets": {"OHP": {"workKg": 35, "failureStreak": 0, "successStreak": 9, "progressionTarget": "OHP"}, "PULL": {"workKg": 100, "failureStreak": 0, "successStreak": 9, "progressionTarget": "PULL"}, "BENCH": {"workKg": 95, "failureStreak": 0, "successStreak": 9, "progressionTarget": "BENCH"}, "SQUAT": {"workKg": 95, "failureStreak": 0, "successStreak": 9, "progressionTarget": "SQUAT"}, "DEADLIFT": {"workKg": 70, "failureStreak": 0, "successStreak": 9, "progressionTarget": "DEADLIFT"}}, "lastAppliedLogId": "0fe3d7bb-64f3-4668-be04-89470f55d634"}	2026-03-08 10:16:06.779713+00	2026-03-31 13:03:16.354+00
\.


--
-- Data for Name: program_template; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.program_template (id, slug, name, type, visibility, description, tags, created_at, updated_at, owner_user_id, parent_template_id) FROM stdin;
a577018f-0f4a-4d48-8e0b-24048946ad90	tactical-barbell-operator-custom-mmhk641d	Tactical Barbell Operator Custom	MANUAL	PRIVATE	Canonical A/B LP with 2x5 + 1x5+ AMRAP structure.	{manual,strength,linear,amrap}	2026-03-08 09:37:05.222741+00	2026-03-08 09:37:05.222741+00	dev	8df3c5e4-4505-402b-a4b8-00fd49b02aca
73bc1a75-ab1a-4e46-8c2a-98ce34059764	operator	Tactical Barbell Operator (Base)	LOGIC	PUBLIC	A submaximal strength program built for tactical athletes and field operators. It uses 90% of true 1RM as the training max, runs squat, bench, and deadlift through a 6-week wave, and prioritizes repeatable heavy practice without grinding failures. After each cycle, the training max is nudged upward to sustain long-term progressive overload.	{strength,barbell,operator,intermediate}	2026-03-06 07:04:44.571994+00	2026-03-06 07:04:44.571994+00	\N	\N
c275e891-6c74-4fc6-a1c8-54566f60fdf5	manual	Manual Sessions	MANUAL	PUBLIC	A fully open manual template for lifters who want to design every exercise, set, and rep themselves. There is no automatic progression engine, so each session can be logged exactly as written. It works well when you want full control instead of adapting to a prebuilt system.	{manual,custom}	2026-03-06 07:04:44.762728+00	2026-03-06 07:04:44.762728+00	\N	\N
9bb9afac-5947-4236-b2f6-6892a29bce51	wendler-531-fsl	Jim Wendler 5/3/1 + FSL	LOGIC	PUBLIC	A 5/3/1 variant that adds First Set Last work after the main sets. The first working-set load is repeated for 5x5, giving you extra technical practice and useful volume without losing the character of the original program. It is one of the most practical ways to make 5/3/1 feel more productive week to week.	{strength,barbell,5/3/1,wendler,fsl,intermediate}	2026-03-30 12:17:07.309408+00	2026-03-30 12:17:07.309408+00	\N	\N
e4f3767d-fd1d-4d28-824d-392aaeb18990	wendler-531-bbb	Jim Wendler 5/3/1 + BBB	LOGIC	PUBLIC	A 5/3/1 variant that adds Boring But Big assistance after the main work. The follow-up 5x10 sets create a much larger hypertrophy and work-capacity stimulus while the core progression still comes from the 5/3/1 top sets. It is the volume-heavy option for lifters who want more size alongside strength.	{strength,barbell,5/3/1,wendler,bbb,hypertrophy,intermediate}	2026-03-30 12:17:07.318341+00	2026-03-30 12:17:07.318341+00	\N	\N
8df3c5e4-4505-402b-a4b8-00fd49b02aca	greyskull-lp	Greyskull LP (Base)	MANUAL	PUBLIC	A novice LP built on classic barbell basics with an AMRAP final set. After the first two work sets, the last set pushes for extra reps, letting volume auto-regulate based on how the athlete feels that day. It keeps progression simple while giving beginners more flexibility and a clearer path to adding optional assistance work.	{manual,strength,linear,amrap,novice}	2026-03-06 07:04:44.804114+00	2026-03-06 07:04:44.804114+00	\N	\N
2fb791c3-7621-4f7b-a2cb-e51a573981fd	starting-strength-lp	Starting Strength LP (Base)	MANUAL	PUBLIC	Mark Rippetoe's classic novice linear progression. Train an A/B full-body split three days per week with squats, presses, deadlifts, and power cleans, adding 2.5 to 5 kg whenever the work sets are completed. The program strips away distractions and leans hard into compound barbell lifts to maximize the novice effect.	{manual,strength,linear,novice}	2026-03-06 07:04:44.773301+00	2026-03-06 07:04:44.773301+00	\N	\N
9602920d-4f1c-40c8-9473-c0c93b1b1003	stronglifts-5x5	StrongLifts 5x5 (Base)	MANUAL	PUBLIC	A novice linear progression popularized by Mehdi. It resembles Starting Strength, but most main lifts are performed for 5x5 while deadlift stays lower in volume. Weight increases happen in small, predictable jumps, and the reset rules are simple enough that new lifters can run it with very little friction.	{manual,strength,linear,novice,5x5}	2026-03-06 07:04:44.782378+00	2026-03-06 07:04:44.782378+00	\N	\N
0482a63b-3486-4e2a-9487-b6de0d9b3d7b	texas-method	Texas Method (Base)	MANUAL	PUBLIC	A weekly undulating progression for intermediate lifters who have outgrown session-to-session linear gains. The standard flow is volume day, recovery day, and intensity day within the same week, letting stress, recovery, and peak output cycle together. It is a strong bridge for athletes who still want predictable progression without novice-level recovery speed.	{manual,strength,intermediate,weekly-undulation}	2026-03-06 07:04:44.790255+00	2026-03-06 07:04:44.790255+00	\N	\N
68c99ad8-7fb8-421f-a31b-172764779a76	gzclp	GZCLP (Base T1/T2/T3)	MANUAL	PUBLIC	Cody LeFever's tiered linear progression built around T1, T2, and T3 work. T1 lifts emphasize heavy strength practice, T2 movements drive additional volume, and T3 slots add high-rep work capacity and hypertrophy. It is a good fit for beginners and early intermediates who want more exercise variety than classic novice LPs.	{manual,strength,tiers,top-set,amrap,novice}	2026-03-06 07:04:44.797279+00	2026-03-06 07:04:44.797279+00	\N	\N
918d48d3-0d9c-4c6e-aeed-c8828149f20b	wendler-531	Jim Wendler 5/3/1 (No Assistance)	LOGIC	PUBLIC	Jim Wendler's 5/3/1 base template with no additional assistance work. It runs a 4-week cycle using a 90% training max, builds around submaximal top sets, and finishes each main week with an AMRAP set to drive long-term progress. This version is clean and minimal: just the main work and the progression engine.	{strength,barbell,5/3/1,wendler,intermediate}	2026-03-30 12:17:07.265787+00	2026-03-30 12:17:07.265787+00	\N	\N
\.


--
-- Data for Name: program_version; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.program_version (id, template_id, version, changelog, definition, defaults, is_deprecated, created_at, parent_version_id) FROM stdin;
f59964ff-169f-44f3-a8b8-4547082858ad	0482a63b-3486-4e2a-9487-b6de0d9b3d7b	1	Canonical V/R/I base microcycle	{"kind": "manual", "sessions": [{"key": "V", "items": [{"sets": [{"note": "volume day", "reps": 5, "targetWeightKg": 120}, {"note": "volume day", "reps": 5, "targetWeightKg": 120}, {"note": "volume day", "reps": 5, "targetWeightKg": 120}, {"note": "volume day", "reps": 5, "targetWeightKg": 120}, {"note": "volume day", "reps": 5, "targetWeightKg": 120}], "exerciseName": "Back Squat"}, {"sets": [{"note": "volume day", "reps": 5, "targetWeightKg": 85}, {"note": "volume day", "reps": 5, "targetWeightKg": 85}, {"note": "volume day", "reps": 5, "targetWeightKg": 85}, {"note": "volume day", "reps": 5, "targetWeightKg": 85}, {"note": "volume day", "reps": 5, "targetWeightKg": 85}], "exerciseName": "Bench Press"}, {"sets": [{"note": "volume day", "reps": 5, "targetWeightKg": 75}, {"note": "volume day", "reps": 5, "targetWeightKg": 75}, {"note": "volume day", "reps": 5, "targetWeightKg": 75}, {"note": "volume day", "reps": 5, "targetWeightKg": 75}, {"note": "volume day", "reps": 5, "targetWeightKg": 75}], "exerciseName": "Barbell Row"}]}, {"key": "R", "items": [{"sets": [{"note": "recovery day", "reps": 5, "targetWeightKg": 95}, {"note": "recovery day", "reps": 5, "targetWeightKg": 95}], "exerciseName": "Back Squat"}, {"sets": [{"note": "recovery day", "reps": 5, "targetWeightKg": 55}, {"note": "recovery day", "reps": 5, "targetWeightKg": 55}, {"note": "recovery day", "reps": 5, "targetWeightKg": 55}], "exerciseName": "Overhead Press"}, {"sets": [{"note": "recovery day", "reps": 8}, {"note": "recovery day", "reps": 8}, {"note": "recovery day", "reps": 8}], "exerciseName": "Pull-Up"}]}, {"key": "I", "items": [{"sets": [{"note": "intensity top set", "reps": 5, "targetWeightKg": 130}], "exerciseName": "Back Squat"}, {"sets": [{"note": "intensity top set", "reps": 5, "targetWeightKg": 92.5}], "exerciseName": "Bench Press"}, {"sets": [{"note": "intensity top set", "reps": 5, "targetWeightKg": 150}], "exerciseName": "Deadlift"}]}]}	{}	f	2026-03-06 07:04:44.793982+00	\N
743ac855-59b1-42a0-81d9-a88cd12fd793	68c99ad8-7fb8-421f-a31b-172764779a76	1	Canonical base tier split with T3 AMRAP	{"kind": "manual", "sessions": [{"key": "D1", "items": [{"sets": [{"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 100}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 100}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 100}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 100}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 100}], "exerciseName": "Back Squat"}, {"sets": [{"note": "T2 volume", "reps": 10, "percent": 0.7, "targetWeightKg": 60}, {"note": "T2 volume", "reps": 10, "percent": 0.7, "targetWeightKg": 60}, {"note": "T2 volume", "reps": 10, "percent": 0.7, "targetWeightKg": 60}], "exerciseName": "Bench Press"}, {"sets": [{"note": "T3", "reps": 15, "targetWeightKg": 45}, {"note": "T3", "reps": 15, "targetWeightKg": 45}, {"note": "T3 AMRAP", "reps": 15, "targetWeightKg": 45}], "exerciseName": "Lat Pulldown"}]}, {"key": "D2", "items": [{"sets": [{"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 52.5}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 52.5}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 52.5}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 52.5}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 52.5}], "exerciseName": "Overhead Press"}, {"sets": [{"note": "T2 volume", "reps": 8, "percent": 0.75, "targetWeightKg": 110}, {"note": "T2 volume", "reps": 8, "percent": 0.75, "targetWeightKg": 110}, {"note": "T2 volume", "reps": 8, "percent": 0.75, "targetWeightKg": 110}], "exerciseName": "Deadlift"}, {"sets": [{"note": "T3", "reps": 15, "targetWeightKg": 50}, {"note": "T3", "reps": 15, "targetWeightKg": 50}, {"note": "T3 AMRAP", "reps": 15, "targetWeightKg": 50}], "exerciseName": "Barbell Row"}]}, {"key": "D3", "items": [{"sets": [{"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 75}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 75}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 75}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 75}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 75}], "exerciseName": "Bench Press"}, {"sets": [{"note": "T2 volume", "reps": 10, "percent": 0.72, "targetWeightKg": 90}, {"note": "T2 volume", "reps": 10, "percent": 0.72, "targetWeightKg": 90}, {"note": "T2 volume", "reps": 10, "percent": 0.72, "targetWeightKg": 90}], "exerciseName": "Back Squat"}, {"sets": [{"note": "T3", "reps": 10}, {"note": "T3", "reps": 10}, {"note": "T3 AMRAP", "reps": 10}], "exerciseName": "Pull-Up"}]}, {"key": "D4", "items": [{"sets": [{"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 140}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 140}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 140}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 140}, {"note": "T1 main", "reps": 3, "percent": 0.85, "targetWeightKg": 140}], "exerciseName": "Deadlift"}, {"sets": [{"note": "T2 volume", "reps": 10, "percent": 0.72, "targetWeightKg": 42.5}, {"note": "T2 volume", "reps": 10, "percent": 0.72, "targetWeightKg": 42.5}, {"note": "T2 volume", "reps": 10, "percent": 0.72, "targetWeightKg": 42.5}], "exerciseName": "Overhead Press"}, {"sets": [{"note": "T3", "reps": 15, "targetWeightKg": 140}, {"note": "T3", "reps": 15, "targetWeightKg": 140}, {"note": "T3 AMRAP", "reps": 15, "targetWeightKg": 140}], "exerciseName": "Leg Press"}]}]}	{}	f	2026-03-06 07:04:44.800704+00	\N
ea51f4db-b82f-4c82-b522-70b5590b09ae	c275e891-6c74-4fc6-a1c8-54566f60fdf5	1	\N	{"kind": "manual", "sessions": []}	{}	f	2026-03-06 07:04:44.766394+00	\N
c11fda09-836d-42ac-b358-e277167effc8	9602920d-4f1c-40c8-9473-c0c93b1b1003	1	Canonical A/B 5x5 with deadlift 1x5 day	{"kind": "manual", "sessions": [{"key": "A", "items": [{"sets": [{"note": "5x5 work set", "reps": 5, "targetWeightKg": 80}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 80}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 80}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 80}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 80}], "exerciseName": "Back Squat"}, {"sets": [{"note": "5x5 work set", "reps": 5, "targetWeightKg": 57.5}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 57.5}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 57.5}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 57.5}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 57.5}], "exerciseName": "Bench Press"}, {"sets": [{"note": "5x5 work set", "reps": 5, "targetWeightKg": 55}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 55}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 55}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 55}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 55}], "exerciseName": "Barbell Row"}]}, {"key": "B", "items": [{"sets": [{"note": "5x5 work set", "reps": 5, "targetWeightKg": 82.5}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 82.5}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 82.5}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 82.5}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 82.5}], "exerciseName": "Back Squat"}, {"sets": [{"note": "5x5 work set", "reps": 5, "targetWeightKg": 40}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 40}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 40}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 40}, {"note": "5x5 work set", "reps": 5, "targetWeightKg": 40}], "exerciseName": "Overhead Press"}, {"sets": [{"note": "1x5 top set", "reps": 5, "targetWeightKg": 105}], "exerciseName": "Deadlift"}]}]}	{}	f	2026-03-06 07:04:44.78522+00	\N
27fe4212-7141-4e9a-ab28-bd5bead7de39	a577018f-0f4a-4d48-8e0b-24048946ad90	1	Forked from greyskull-lp@v1	{"kind": "manual", "sessions": [{"key": "D1", "name": "Session D1", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, {"key": "D2", "name": "Session D2", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}, {"key": "D3", "name": "Session D3", "items": [{"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Back Squat", "progressionTarget": "SQUAT"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Pull-Up", "progressionTarget": "PULL"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}, {"reps": 5, "setNumber": 2, "targetWeightKg": 0}, {"reps": 5, "setNumber": 3, "targetWeightKg": 0}], "rowType": "AUTO", "exerciseName": "Bench Press", "progressionTarget": "BENCH"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Deadlift"}, {"role": "MAIN", "sets": [{"reps": 5, "setNumber": 1, "targetWeightKg": 0}], "rowType": "CUSTOM", "exerciseName": "Overhead Press"}]}], "operatorStyle": true, "programFamily": "operator"}	{}	f	2026-03-08 09:37:05.222741+00	466a7cb0-e55b-44d6-820a-cc60ac95d1a4
cb75e1b6-51ee-479f-ba1d-85f4b85180c4	73bc1a75-ab1a-4e46-8c2a-98ce34059764	1	\N	{"kind": "operator", "modules": ["SQUAT", "BENCH", "DEADLIFT"], "schedule": {"weeks": 6, "sessionsPerWeek": 3}, "dslVersion": 1, "progression": {"profile": "operator-base", "mainSets": 3, "deadliftSets": 3}}	{"tmPercent": 0.9}	f	2026-03-06 07:04:44.663767+00	\N
7f24f2d8-3e1d-4573-8cc5-e71a495904f7	2fb791c3-7621-4f7b-a2cb-e51a573981fd	1	Canonical base A/B split	{"kind": "manual", "sessions": [{"key": "A", "items": [{"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 80}, {"note": "work set", "reps": 5, "targetWeightKg": 80}, {"note": "work set", "reps": 5, "targetWeightKg": 80}], "exerciseName": "Back Squat"}, {"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 60}, {"note": "work set", "reps": 5, "targetWeightKg": 60}, {"note": "work set", "reps": 5, "targetWeightKg": 60}], "exerciseName": "Bench Press"}, {"sets": [{"note": "top set", "reps": 5, "targetWeightKg": 100}], "exerciseName": "Deadlift"}]}, {"key": "B", "items": [{"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 82.5}, {"note": "work set", "reps": 5, "targetWeightKg": 82.5}, {"note": "work set", "reps": 5, "targetWeightKg": 82.5}], "exerciseName": "Back Squat"}, {"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 42.5}, {"note": "work set", "reps": 5, "targetWeightKg": 42.5}, {"note": "work set", "reps": 5, "targetWeightKg": 42.5}], "exerciseName": "Overhead Press"}, {"sets": [{"note": "work set", "reps": 3, "targetWeightKg": 60}, {"note": "work set", "reps": 3, "targetWeightKg": 60}, {"note": "work set", "reps": 3, "targetWeightKg": 60}, {"note": "work set", "reps": 3, "targetWeightKg": 60}, {"note": "work set", "reps": 3, "targetWeightKg": 60}], "exerciseName": "Power Clean"}]}]}	{}	f	2026-03-06 07:04:44.776843+00	\N
881a0f76-d2ac-42b2-8f06-bd455f71ca4e	c275e891-6c74-4fc6-a1c8-54566f60fdf5	2	Local demo manual sessions	{"kind": "manual", "sessions": [{"key": "A", "items": [{"sets": [{"reps": 5, "targetWeightKg": 80}, {"reps": 5, "targetWeightKg": 80}, {"reps": 5, "targetWeightKg": 80}], "exerciseName": "Back Squat"}, {"sets": [{"reps": 5, "targetWeightKg": 60}, {"reps": 5, "targetWeightKg": 60}, {"reps": 5, "targetWeightKg": 60}], "exerciseName": "Bench Press"}]}, {"key": "B", "items": [{"sets": [{"reps": 5, "targetWeightKg": 100}, {"reps": 5, "targetWeightKg": 100}], "exerciseName": "Deadlift"}, {"sets": [{"reps": 6, "targetWeightKg": 40}, {"reps": 6, "targetWeightKg": 40}, {"reps": 6, "targetWeightKg": 40}], "exerciseName": "Overhead Press"}]}]}	{}	f	2026-03-06 07:04:44.769704+00	\N
41f39bf1-4ecf-4980-b3f0-69065059c62a	918d48d3-0d9c-4c6e-aeed-c8828149f20b	1	Base 5/3/1 without assistance	{"kind": "531", "modules": ["SQUAT", "BENCH", "DEADLIFT", "OHP"], "schedule": {"weeks": 4, "sessionsPerWeek": 4}, "assistance": "NONE", "dslVersion": 1}	{"tmPercent": 0.9}	f	2026-03-30 12:17:07.275109+00	\N
9b2e62fd-f347-4629-8e67-52fc94d74d68	9bb9afac-5947-4236-b2f6-6892a29bce51	1	5/3/1 with First Set Last 5x5	{"kind": "531", "modules": ["SQUAT", "BENCH", "DEADLIFT", "OHP"], "schedule": {"weeks": 4, "sessionsPerWeek": 4}, "assistance": "FSL", "dslVersion": 1}	{"tmPercent": 0.9}	f	2026-03-30 12:17:07.314042+00	\N
f90b450b-0b18-4c19-b299-ce04c8e77b62	e4f3767d-fd1d-4d28-824d-392aaeb18990	1	5/3/1 with Boring But Big 5x10	{"kind": "531", "modules": ["SQUAT", "BENCH", "DEADLIFT", "OHP"], "schedule": {"weeks": 4, "sessionsPerWeek": 4}, "assistance": "BBB", "dslVersion": 1}	{"tmPercent": 0.9}	f	2026-03-30 12:17:07.323708+00	\N
466a7cb0-e55b-44d6-820a-cc60ac95d1a4	8df3c5e4-4505-402b-a4b8-00fd49b02aca	1	Canonical base A/B 2x5 + 1x5+ structure	{"kind": "manual", "sessions": [{"key": "A", "items": [{"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 90}, {"note": "work set", "reps": 5, "targetWeightKg": 90}, {"note": "AMRAP 5+", "reps": 5, "targetWeightKg": 90}], "exerciseName": "Back Squat"}, {"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 62.5}, {"note": "work set", "reps": 5, "targetWeightKg": 62.5}, {"note": "AMRAP 5+", "reps": 5, "targetWeightKg": 62.5}], "exerciseName": "Bench Press"}, {"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 57.5}, {"note": "work set", "reps": 5, "targetWeightKg": 57.5}, {"note": "AMRAP 5+", "reps": 5, "targetWeightKg": 57.5}], "exerciseName": "Barbell Row"}]}, {"key": "B", "items": [{"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 92.5}, {"note": "work set", "reps": 5, "targetWeightKg": 92.5}, {"note": "AMRAP 5+", "reps": 5, "targetWeightKg": 92.5}], "exerciseName": "Back Squat"}, {"sets": [{"note": "work set", "reps": 5, "targetWeightKg": 42.5}, {"note": "work set", "reps": 5, "targetWeightKg": 42.5}, {"note": "AMRAP 5+", "reps": 5, "targetWeightKg": 42.5}], "exerciseName": "Overhead Press"}, {"sets": [{"note": "AMRAP 5+", "reps": 5, "targetWeightKg": 110}], "exerciseName": "Deadlift"}]}]}	{}	f	2026-03-06 07:04:44.808913+00	\N
\.


--
-- Data for Name: seed_run_state; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.seed_run_state (seed_key, seed_hash, tracked_files, runner, host, applied_at, details) FROM stdin;
base	05bc39e5c8b88d0c860a5a233cb531838b28418d49b12aee10047b19023141f9	["src/server/db/seed.ts"]	ci-deploy	e995870fa011	2026-03-30 12:17:17.614438+00	{"reasons": ["seed-hash-changed"], "appVersion": "e9c4b051c9bc0b14111ad849999cb6725fb92617", "lockWaitMs": 4, "countsAfter": {"exerciseCount": 14, "programTemplateCount": 11}, "countsBefore": {"exerciseCount": 14, "programTemplateCount": 11}}
\.


--
-- Data for Name: stats_cache; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.stats_cache (id, user_id, metric, params_hash, payload, created_at, updated_at) FROM stdin;
603129f4-32e5-43e4-88c7-f048dfd22c26	dev	bundle_v2	0d46434d9ca5de0a3ea4e972dd7df30741ec6991f461ae3a5c8e16d8154b4598	{"prs90d": [{"best": {"date": "2026-03-06", "e1rm": 102.1, "reps": 5, "weightKg": 87.5}, "latest": {"date": "2026-03-31", "e1rm": 99.6, "reps": 3, "weightKg": 90.5}, "exerciseId": "e5c786ba-7020-4f4c-a533-edbff0ce3413", "improvement": 0, "exerciseName": "Pull-Up"}, {"best": {"date": "2026-03-26", "e1rm": 99, "reps": 3, "weightKg": 90}, "latest": {"date": "2026-03-31", "e1rm": 99, "reps": 3, "weightKg": 90}, "exerciseId": "a293c633-5a9c-4126-9914-c4912186f6b7", "improvement": 26.1, "exerciseName": "Deadlift"}, {"best": {"date": "2026-03-26", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "latest": {"date": "2026-03-31", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "exerciseId": "4a8f963f-3d37-4245-9954-988f92d83f71", "improvement": 20.6, "exerciseName": "Back Squat"}, {"best": {"date": "2026-03-26", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "latest": {"date": "2026-03-31", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "exerciseId": "b61c9129-a96b-46cf-9e13-4ce0a67615f8", "improvement": 20.6, "exerciseName": "Bench Press"}, {"best": {"date": "2026-03-26", "e1rm": 49.5, "reps": 3, "weightKg": 45}, "latest": {"date": "2026-03-31", "e1rm": 49.5, "reps": 3, "weightKg": 45}, "exerciseId": "bf1a2647-545f-4bdf-b689-e7285bd9dc06", "improvement": 14.5, "exerciseName": "Overhead Press"}], "tonnage30d": 29840, "sessions30d": 12, "compliance90d": {"done": 9, "byPlan": [{"done": 9, "planId": "ddb5a45b-6a83-458d-9b7a-8d196adb5a26", "planned": 34, "planName": "Tactical Barbell Operator Custom Program", "compliance": 0.265}], "planned": 34, "compliance": 0.265}}	2026-03-31 13:13:09.340508+00	2026-03-31 14:48:04.888+00
3376c95f-f1ab-465c-ad16-9493c11254e9	dev	e1rm_best	f85dd022c731bf21f6e88f893598a81a20ef1cac8e259f47de76a52b5ee47f0d	{"to": "2026-03-31T14:48:05.046Z", "best": {"date": "2026-03-26", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "from": "2025-12-31T14:48:05.046Z", "series": [{"date": "2026-03-06", "e1rm": 72.9, "reps": 5, "weightKg": 62.5}, {"date": "2026-03-08", "e1rm": 78.8, "reps": 5, "weightKg": 67.5}, {"date": "2026-03-10", "e1rm": 78.8, "reps": 5, "weightKg": 67.5}, {"date": "2026-03-15", "e1rm": 78.8, "reps": 5, "weightKg": 67.5}, {"date": "2026-03-17", "e1rm": 87.5, "reps": 5, "weightKg": 75}, {"date": "2026-03-21", "e1rm": 87.5, "reps": 5, "weightKg": 75}, {"date": "2026-03-23", "e1rm": 87.5, "reps": 5, "weightKg": 75}, {"date": "2026-03-26", "e1rm": 93.5, "reps": 3, "weightKg": 85}, {"date": "2026-03-28", "e1rm": 93.5, "reps": 3, "weightKg": 85}, {"date": "2026-03-31", "e1rm": 93.5, "reps": 3, "weightKg": 85}], "exercise": "Back Squat", "rangeDays": 90, "exerciseId": "4a8f963f-3d37-4245-9954-988f92d83f71"}	2026-03-31 13:13:10.218704+00	2026-03-31 14:48:05.088+00
a67a5fc0-2f3f-4d0d-8dbf-71710f86dcd6	dev	e1rm_best	02daa2b957bc255665853512ec2a09f5431e446fe0b1bbd0410d0593c8917c93	{"to": "2026-03-31T13:19:46.018Z", "best": {"date": "2026-03-26", "e1rm": 99, "reps": 3, "weightKg": 90}, "from": "2025-12-31T13:19:46.018Z", "series": [{"date": "2026-03-06", "e1rm": 72.9, "reps": 5, "weightKg": 62.5}, {"date": "2026-03-08", "e1rm": 81.7, "reps": 5, "weightKg": 70}, {"date": "2026-03-10", "e1rm": 81.7, "reps": 5, "weightKg": 70}, {"date": "2026-03-15", "e1rm": 81.7, "reps": 5, "weightKg": 70}, {"date": "2026-03-17", "e1rm": 93.3, "reps": 5, "weightKg": 80}, {"date": "2026-03-21", "e1rm": 93.3, "reps": 5, "weightKg": 80}, {"date": "2026-03-23", "e1rm": 93.3, "reps": 5, "weightKg": 80}, {"date": "2026-03-26", "e1rm": 99, "reps": 3, "weightKg": 90}, {"date": "2026-03-28", "e1rm": 99, "reps": 3, "weightKg": 90}, {"date": "2026-03-31", "e1rm": 99, "reps": 3, "weightKg": 90}], "exercise": "Deadlift", "rangeDays": 90, "exerciseId": "a293c633-5a9c-4126-9914-c4912186f6b7"}	2026-03-31 13:19:46.560495+00	2026-03-31 13:19:46.558+00
03de5be7-8668-4158-a71f-96e22ff3ff23	dev	e1rm_best	841d00e07cb69be6cca23a4cc909fb65455e1b4063ac87d93e22856bb02376e8	{"to": "2026-03-31T13:20:06.913Z", "best": {"date": "2026-03-26", "e1rm": 49.5, "reps": 3, "weightKg": 45}, "from": "2025-12-31T13:20:06.913Z", "series": [{"date": "2026-03-06", "e1rm": 35, "reps": 5, "weightKg": 30}, {"date": "2026-03-08", "e1rm": 40.8, "reps": 5, "weightKg": 35}, {"date": "2026-03-10", "e1rm": 40.8, "reps": 5, "weightKg": 35}, {"date": "2026-03-15", "e1rm": 40.8, "reps": 5, "weightKg": 35}, {"date": "2026-03-17", "e1rm": 46.7, "reps": 5, "weightKg": 40}, {"date": "2026-03-21", "e1rm": 46.7, "reps": 5, "weightKg": 40}, {"date": "2026-03-23", "e1rm": 46.7, "reps": 5, "weightKg": 40}, {"date": "2026-03-26", "e1rm": 49.5, "reps": 3, "weightKg": 45}, {"date": "2026-03-28", "e1rm": 49.5, "reps": 3, "weightKg": 45}, {"date": "2026-03-31", "e1rm": 49.5, "reps": 3, "weightKg": 45}], "exercise": "Overhead Press", "rangeDays": 90, "exerciseId": "bf1a2647-545f-4bdf-b689-e7285bd9dc06"}	2026-03-31 13:20:06.945274+00	2026-03-31 13:20:06.944+00
a21f79c6-58f0-42fd-9dc2-502465f28b84	dev	e1rm_best	f5252daad890b7c1a929b71569990da6ab776f7e6a6212377634fb2e5f9a7a3c	{"to": "2026-03-31T13:20:14.107Z", "best": {"date": "2026-03-06", "e1rm": 102.1, "reps": 5, "weightKg": 87.5}, "from": "2025-12-31T13:20:14.107Z", "series": [{"date": "2026-03-06", "e1rm": 102.1, "reps": 5, "weightKg": 87.5}, {"date": "2026-03-08", "e1rm": 81.7, "reps": 5, "weightKg": 70}, {"date": "2026-03-10", "e1rm": 81.7, "reps": 5, "weightKg": 70}, {"date": "2026-03-15", "e1rm": 85.2, "reps": 5, "weightKg": 73}, {"date": "2026-03-17", "e1rm": 93.9, "reps": 5, "weightKg": 80.5}, {"date": "2026-03-21", "e1rm": 93.9, "reps": 5, "weightKg": 80.5}, {"date": "2026-03-23", "e1rm": 93.9, "reps": 5, "weightKg": 80.5}, {"date": "2026-03-26", "e1rm": 99.6, "reps": 3, "weightKg": 90.5}, {"date": "2026-03-28", "e1rm": 99.6, "reps": 3, "weightKg": 90.5}, {"date": "2026-03-31", "e1rm": 99.6, "reps": 3, "weightKg": 90.5}], "exercise": "Pull-Up", "rangeDays": 90, "exerciseId": "e5c786ba-7020-4f4c-a533-edbff0ce3413"}	2026-03-31 13:20:14.115533+00	2026-03-31 13:20:14.114+00
ebcdadb3-4aa7-47fe-90e5-a98420a90185	dev	volume_series	ecce0ddae1ce73fd831f9c693e96b304a2bb7a367abba110f8fc6e34f04a79a0	{"series": [{"reps": 55, "sets": 11, "period": "2026-03-15", "tonnage": 2550}, {"reps": 55, "sets": 11, "period": "2026-03-17", "tonnage": 2962.5}, {"reps": 55, "sets": 11, "period": "2026-03-21", "tonnage": 2962.5}, {"reps": 55, "sets": 11, "period": "2026-03-23", "tonnage": 2962.5}, {"reps": 33, "sets": 11, "period": "2026-03-26", "tonnage": 2092.5}, {"reps": 33, "sets": 11, "period": "2026-03-28", "tonnage": 2092.5}, {"reps": 33, "sets": 11, "period": "2026-03-31", "tonnage": 2092.5}]}	2026-03-31 13:03:17.424505+00	2026-03-31 14:46:15.436+00
3a399536-0986-4c01-8341-239f28b9e556	dev	prs	4cf6b043f2080c8c7aaa62289655cd687944260a93d17a45597c786c307ef287	{"items": [{"best": {"date": "2026-03-06", "e1rm": 102.1, "reps": 5, "weightKg": 87.5}, "latest": {"date": "2026-03-31", "e1rm": 99.6, "reps": 3, "weightKg": 90.5}, "exerciseId": "e5c786ba-7020-4f4c-a533-edbff0ce3413", "improvement": 0, "exerciseName": "Pull-Up"}, {"best": {"date": "2026-03-26", "e1rm": 99, "reps": 3, "weightKg": 90}, "latest": {"date": "2026-03-31", "e1rm": 99, "reps": 3, "weightKg": 90}, "exerciseId": "a293c633-5a9c-4126-9914-c4912186f6b7", "improvement": 26.1, "exerciseName": "Deadlift"}, {"best": {"date": "2026-03-26", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "latest": {"date": "2026-03-31", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "exerciseId": "4a8f963f-3d37-4245-9954-988f92d83f71", "improvement": 20.6, "exerciseName": "Back Squat"}, {"best": {"date": "2026-03-26", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "latest": {"date": "2026-03-31", "e1rm": 93.5, "reps": 3, "weightKg": 85}, "exerciseId": "b61c9129-a96b-46cf-9e13-4ce0a67615f8", "improvement": 20.6, "exerciseName": "Bench Press"}]}	2026-03-31 13:03:17.405947+00	2026-03-31 14:46:15.434+00
\.


--
-- Data for Name: user_setting; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.user_setting (id, user_id, key, value, created_at, updated_at) FROM stdin;
85742017-1995-49a1-a65f-dd4a2ef408d4	dev	prefs.minimumPlate.rulesJson	"[{\\"exerciseId\\":\\"e5c786ba-7020-4f4c-a533-edbff0ce3413\\",\\"exerciseName\\":\\"Pull-Up\\",\\"incrementKg\\":1.25}]"	2026-03-11 05:54:02.555842+00	2026-03-11 05:54:02.539+00
b1ea5214-df8d-49c3-84af-cdb4f4a2ccf9	dev	prefs.bodyweight.kg	73	2026-03-11 14:39:01.450369+00	2026-03-11 14:39:01.436+00
0693039d-46c7-4ecc-b6c9-ac05adc13888	dev	prefs.theme.mode	"SYSTEM"	2026-03-29 06:37:04.803583+00	2026-03-29 06:40:04.754+00
9d4f4084-7f12-4519-be80-544201253579	dev	prefs.locale	"en"	2026-03-30 12:18:48.770482+00	2026-03-31 14:49:02.691+00
\.


--
-- Data for Name: ux_event_log; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.ux_event_log (id, user_id, client_event_id, name, recorded_at, props, created_at) FROM stdin;
\.


--
-- Data for Name: workout_log; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.workout_log (id, user_id, plan_id, generated_session_id, performed_at, duration_minutes, notes, tags, created_at) FROM stdin;
1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	dev	\N	\N	2026-03-06 07:08:23.368+00	\N	\N	\N	2026-03-06 07:08:23.526842+00
84ad2b2c-a703-4169-8ace-e417a0b4a550	dev	\N	\N	2026-03-06 07:08:45.313+00	\N	\N	\N	2026-03-06 07:08:45.486088+00
cdb42c70-a155-4185-b8b9-971f7d92953c	dev	\N	\N	2026-03-06 07:08:10.841+00	\N	\N	\N	2026-03-06 07:08:11.03373+00
ce3a8533-fb17-402c-874d-60a5b456ad67	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	ea4ea385-f20e-4cfc-97f5-d8f8b7aaa89a	2026-03-08 10:16:05.77+00	\N	\N	\N	2026-03-08 10:16:06.779713+00
bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	677b7ff5-d4d7-4828-81da-6acfe70983d7	2026-03-10 11:58:02.448+00	\N	\N	\N	2026-03-10 12:20:31.320398+00
6d38ab34-3973-4dc5-862a-27f5adb8c7d1	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	74eb2208-d302-41f0-b6ad-c9c7b6287e2c	2026-03-15 09:42:10.395+00	\N	\N	\N	2026-03-15 10:00:37.288854+00
4fe9cded-8226-424e-8191-79e1483b08a0	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	0751fcc3-75ec-4f8d-b412-db0b7bf3efc6	2026-03-17 08:09:13.778+00	\N	\N	\N	2026-03-17 13:17:24.600641+00
6cce3d40-8f0e-4596-8405-d8f46c3f5158	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	08a697d3-fb49-4566-a04a-ebf07b60e4dd	2026-03-21 06:57:41.353+00	\N	\N	\N	2026-03-21 07:41:57.40412+00
b0889cb1-17fd-4a47-89a8-cab72d238571	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	d1586b10-9fd0-4cd8-917b-4aece4768d2c	2026-03-23 12:28:50.743+00	\N	\N	\N	2026-03-23 13:17:53.474925+00
40444490-586e-47eb-9616-9e55d24ddfcd	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	6919af8b-f664-4897-afa9-f94fbfca78f6	2026-03-26 12:34:50.929+00	\N	\N	\N	2026-03-26 13:56:28.670759+00
2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	8ce8f193-730d-4225-aba7-9f8e7f519742	2026-03-28 06:45:12.585+00	\N	\N	\N	2026-03-28 09:48:01.553781+00
0fe3d7bb-64f3-4668-be04-89470f55d634	dev	ddb5a45b-6a83-458d-9b7a-8d196adb5a26	9228d4ea-892c-436b-963c-133ec30d95d2	2026-03-31 12:04:57.861+00	\N	\N	\N	2026-03-31 13:03:15.680054+00
\.


--
-- Data for Name: workout_set; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.workout_set (id, log_id, exercise_name, sort_order, set_number, reps, weight_kg, rpe, is_extra, meta, exercise_id) FROM stdin;
62096393-7331-42a7-b284-5d42a52f226c	cdb42c70-a155-4185-b8b9-971f7d92953c	Back Squat	0	1	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
8b1490fa-76dc-42e3-84b5-7283fba9d290	cdb42c70-a155-4185-b8b9-971f7d92953c	Back Squat	1	2	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
3a7ef9da-934d-4722-aea8-3ed4d04aaaa9	cdb42c70-a155-4185-b8b9-971f7d92953c	Back Squat	2	3	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
2bfcd4f1-3ea2-40c5-889f-56191036aa5a	cdb42c70-a155-4185-b8b9-971f7d92953c	Bench Press	3	1	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
f7932c2b-0e5a-4cd8-9183-f26f27c8336a	cdb42c70-a155-4185-b8b9-971f7d92953c	Bench Press	4	2	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
110b1044-7452-4fce-9ddb-cb0d39e1b377	cdb42c70-a155-4185-b8b9-971f7d92953c	Bench Press	5	3	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
9350c170-2616-44ba-b80c-40aa29951118	cdb42c70-a155-4185-b8b9-971f7d92953c	Pull-Up	6	1	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
3bf581dd-0fda-4e98-ba96-b622780785db	cdb42c70-a155-4185-b8b9-971f7d92953c	Pull-Up	7	2	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
e6cc6e80-2360-4cb6-bb0b-c0a19f82e04e	cdb42c70-a155-4185-b8b9-971f7d92953c	Pull-Up	8	3	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
90d99d0f-e404-4881-992b-ab6f2c553971	cdb42c70-a155-4185-b8b9-971f7d92953c	Overhead Press	9	1	5	30.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
8f8780fa-f1a0-401f-a75a-798477801397	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Back Squat	0	1	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
c995bc18-93f1-43c6-b67c-ac66c22f39e2	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Back Squat	1	2	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
3ee9b1e1-083c-452f-8a96-bd25445757ab	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Back Squat	2	3	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
254ffcac-664b-40b0-9ba1-28a781ba921e	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Bench Press	3	1	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
6cecfa24-2783-4d64-a5bf-0a2efb80b3b8	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Bench Press	4	2	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
e18e7974-1b0c-4282-a98f-85ccf461f9fc	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Bench Press	5	3	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
5b353868-24bf-4fd0-be8c-bdcc2718cb36	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Pull-Up	6	1	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
d9ae0ad3-ad65-4e55-813d-12aa7bd7bb5b	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Pull-Up	7	2	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
681288d1-09da-4c10-8102-f26305181dff	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Pull-Up	8	3	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
93bf7f78-1b1f-4fce-93c4-cd36ac94721d	1bfa8af1-78ed-419b-bebd-e88c1c1e1cc5	Overhead Press	9	1	5	30.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
65cb13d4-3de6-4ad9-8e6d-f3fcc1342d2a	84ad2b2c-a703-4169-8ace-e417a0b4a550	Back Squat	0	1	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
47f101c5-22b0-4c9b-a90c-3256fb0408ad	84ad2b2c-a703-4169-8ace-e417a0b4a550	Back Squat	1	2	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
6211d60d-9da4-46a2-8649-e510ef659300	84ad2b2c-a703-4169-8ace-e417a0b4a550	Back Squat	2	3	5	62.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
c469d53e-faf5-4d2f-a014-2dc107a950a0	84ad2b2c-a703-4169-8ace-e417a0b4a550	Bench Press	3	1	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
d86ef011-e156-4d5e-922e-53849105328a	84ad2b2c-a703-4169-8ace-e417a0b4a550	Bench Press	4	2	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
d67ee12b-4d4c-43c0-b56a-bc641f335bb8	84ad2b2c-a703-4169-8ace-e417a0b4a550	Bench Press	5	3	5	62.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
93b9b899-0293-4966-9f6a-554eb8ccc4ce	84ad2b2c-a703-4169-8ace-e417a0b4a550	Pull-Up	6	1	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
af78e478-0179-4fa2-bad5-92d683f28dd8	84ad2b2c-a703-4169-8ace-e417a0b4a550	Pull-Up	7	2	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
2f4a2110-813c-4082-9e56-ed54b926e9f3	84ad2b2c-a703-4169-8ace-e417a0b4a550	Pull-Up	8	3	5	17.50	0	f	{"memo": "Operator W1", "totalLoadKg": 87.5, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
92c95298-c2ed-445a-9c12-bddf0ad27382	84ad2b2c-a703-4169-8ace-e417a0b4a550	Deadlift	9	1	5	62.50	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
382ab7ce-a21c-4e29-9357-a4d6109c3a63	ce3a8533-fb17-402c-874d-60a5b456ad67	Back Squat	0	1	5	67.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
78ed0789-518f-49d7-b247-e38fc6fdc392	ce3a8533-fb17-402c-874d-60a5b456ad67	Back Squat	1	2	5	67.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
e02bd571-82ca-4312-ae77-51218f1b8fda	ce3a8533-fb17-402c-874d-60a5b456ad67	Back Squat	2	3	5	67.50	0	f	{"memo": "Operator W1"}	4a8f963f-3d37-4245-9954-988f92d83f71
50b21efe-53a5-4d92-9441-af0e1995938e	ce3a8533-fb17-402c-874d-60a5b456ad67	Pull-Up	3	1	5	0.00	0	f	{"memo": "Operator W1", "totalLoadKg": 70, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
e57909ef-70f0-4097-ae8f-6dc6bc0e8fb3	ce3a8533-fb17-402c-874d-60a5b456ad67	Pull-Up	4	2	5	0.00	0	f	{"memo": "Operator W1", "totalLoadKg": 70, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
f46a0783-4b56-4d99-ae70-c63739246462	ce3a8533-fb17-402c-874d-60a5b456ad67	Pull-Up	5	3	5	0.00	0	f	{"memo": "Operator W1", "totalLoadKg": 70, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
be1833da-ea38-426f-9f07-92ab6719a476	ce3a8533-fb17-402c-874d-60a5b456ad67	Bench Press	6	1	5	67.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
5c125451-bae7-410d-8da5-e04720dc68e1	ce3a8533-fb17-402c-874d-60a5b456ad67	Bench Press	7	2	5	67.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
a66f4814-1030-4d0a-8f58-348fc520ef17	ce3a8533-fb17-402c-874d-60a5b456ad67	Bench Press	8	3	5	67.50	0	f	{"memo": "Operator W1"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
2a29c080-1e8c-433a-83bd-e3bb7245ed7b	ce3a8533-fb17-402c-874d-60a5b456ad67	Deadlift	9	1	5	70.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
2148521e-5af5-4bf4-b130-1dbce87635ae	ce3a8533-fb17-402c-874d-60a5b456ad67	Overhead Press	10	1	5	35.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
14e77972-5856-4fda-8011-5aec7794e3fb	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Back Squat	0	1	5	67.50	0	f	{"memo": "2초 정지"}	4a8f963f-3d37-4245-9954-988f92d83f71
635e39f1-38b0-4c71-a47d-158f358a7918	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Back Squat	1	2	5	67.50	0	f	{"memo": "2초 정지"}	4a8f963f-3d37-4245-9954-988f92d83f71
6cd90a58-3ddb-453c-b0ba-0a31454d0483	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Back Squat	2	3	5	67.50	0	f	{"memo": "2초 정지"}	4a8f963f-3d37-4245-9954-988f92d83f71
50247cce-9d0a-4121-bf9c-4b7c29d06433	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Pull-Up	3	1	5	0.00	0	f	{"totalLoadKg": 70, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
f17a039a-6d0a-47da-9a8c-5bacb45ad04e	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Pull-Up	4	2	5	0.00	0	f	{"totalLoadKg": 70, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
efa169c5-e9ce-479a-b172-557849083150	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Pull-Up	5	3	5	0.00	0	f	{"totalLoadKg": 70, "bodyweightKg": 70}	e5c786ba-7020-4f4c-a533-edbff0ce3413
1e6ee413-2a4e-4f47-927a-09043339609a	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Bench Press	6	1	5	67.50	0	f	{"memo": "1초 정지"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
5924371a-04a9-437b-bc1f-037cea8438b9	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Bench Press	7	2	5	67.50	0	f	{"memo": "1초 정지"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
1076b320-8195-4d90-99fd-7a33aab1eca9	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Bench Press	8	3	5	67.50	0	f	{"memo": "1초 정지"}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
9e01a8c3-0ec6-47c3-b103-a42e4d5730b6	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Deadlift	9	1	5	70.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
b2984096-e7e2-4eb3-af11-5b07b0260610	bf2f95ab-2490-481f-b5f3-9e1c1feffcd2	Overhead Press	10	1	5	35.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
abfa9d4c-f759-416a-8128-6d2108c1282f	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Back Squat	0	1	5	67.50	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
66dd8d72-b2d2-47d0-9079-4005c1bdcd63	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Back Squat	1	2	5	67.50	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
05743bee-dae0-4be0-9073-dec2b3aa1d5d	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Back Squat	2	3	5	67.50	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
13e21d4f-8ad1-48a0-9b8b-4bb2f61b524e	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Pull-Up	3	1	5	0.00	0	f	{"totalLoadKg": 73, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
260dc4f0-4777-4844-9ada-18c74fa418fc	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Pull-Up	4	2	5	0.00	0	f	{"totalLoadKg": 73, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
d37dcae7-dcce-44b0-be75-789d9163fb35	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Pull-Up	5	3	5	0.00	0	f	{"totalLoadKg": 73, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
c56f7cef-225b-4a6e-9e3c-ccee83875ae5	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Bench Press	6	1	5	67.50	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
cd7a1533-bb81-4ecc-b78f-77799638b31d	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Bench Press	7	2	5	67.50	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
0b9719bd-f150-46ea-9279-a78a894e2eb8	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Bench Press	8	3	5	67.50	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
3d230f61-8ff8-4c64-a78b-3486edd9c002	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Deadlift	9	1	5	70.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
3a51b3a6-5314-4b76-a8b8-e4ed87e80ab1	6d38ab34-3973-4dc5-862a-27f5adb8c7d1	Overhead Press	10	1	5	35.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
a08de460-9e6e-432d-9420-0c152200ca29	4fe9cded-8226-424e-8191-79e1483b08a0	Back Squat	0	1	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
c24a629d-c2de-42bf-9edb-3d59e3c84b79	4fe9cded-8226-424e-8191-79e1483b08a0	Back Squat	1	2	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
8a0a399e-d6ec-47be-834a-1a2a7280048c	4fe9cded-8226-424e-8191-79e1483b08a0	Back Squat	2	3	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
d20ace12-25c2-47db-a752-8504e0605ee2	4fe9cded-8226-424e-8191-79e1483b08a0	Pull-Up	3	1	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
d51fa938-ac33-496e-9e2d-72606f108c52	4fe9cded-8226-424e-8191-79e1483b08a0	Pull-Up	4	2	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
94054a48-1078-46cf-b3dd-ff7f71c56851	4fe9cded-8226-424e-8191-79e1483b08a0	Pull-Up	5	3	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
8957b9c5-454d-41d7-8fce-681ffc38716e	4fe9cded-8226-424e-8191-79e1483b08a0	Bench Press	6	1	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
ce504f7f-db06-42bd-9f54-e896cbcf82ff	4fe9cded-8226-424e-8191-79e1483b08a0	Bench Press	7	2	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
059dfd43-4f9b-4486-b044-7cf68aacbfce	4fe9cded-8226-424e-8191-79e1483b08a0	Bench Press	8	3	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
19a80395-5260-4703-8ba8-94afcfef3d70	4fe9cded-8226-424e-8191-79e1483b08a0	Deadlift	9	1	5	80.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
c2555c20-9f41-42ee-bf58-8e0aef6bca59	4fe9cded-8226-424e-8191-79e1483b08a0	Overhead Press	10	1	5	40.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
2e4d3960-d25f-4ee5-967e-cff8f8dfa637	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Back Squat	0	1	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
f724e7ad-1212-4980-947c-7e74a9aa61b5	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Back Squat	1	2	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
7cec583e-743b-4203-b83f-fbfbca78dae7	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Back Squat	2	3	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
bb5bd2a9-4e69-46be-a05b-133064002ed4	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Pull-Up	3	1	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
cf388e5f-4a63-4921-9038-eff7b9efe606	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Pull-Up	4	2	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
b2803921-8876-4d16-923f-5a9eab5af6d4	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Pull-Up	5	3	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
172f50dc-ac6b-4710-b005-4e25e144fe52	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Bench Press	6	1	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
3507a9b0-87f4-40da-9f72-cfbf67114283	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Bench Press	7	2	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
045e5848-62d0-4341-9414-70035abf8e4c	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Bench Press	8	3	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
48ddeb41-517c-4e97-842b-63402cabe106	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Deadlift	9	1	5	80.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
7c38d2af-b2c6-4717-b076-c56bc3ffd179	6cce3d40-8f0e-4596-8405-d8f46c3f5158	Overhead Press	10	1	5	40.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
12744f95-20a5-4fcf-a72c-f1f91f254d35	b0889cb1-17fd-4a47-89a8-cab72d238571	Back Squat	0	1	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
37bb9fd7-794f-4d6c-8575-3a7f14c3c35b	b0889cb1-17fd-4a47-89a8-cab72d238571	Back Squat	1	2	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
d8baddb5-4255-4653-9cf6-6121657a9cf2	b0889cb1-17fd-4a47-89a8-cab72d238571	Back Squat	2	3	5	75.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
43dda6c2-17dd-45e3-806d-9d157f8d23b9	b0889cb1-17fd-4a47-89a8-cab72d238571	Pull-Up	3	1	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
78e9acb6-c0cb-437b-aa4f-590d27788331	b0889cb1-17fd-4a47-89a8-cab72d238571	Pull-Up	4	2	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
8f8aac57-fa2b-4540-9e9a-030d56d026e1	b0889cb1-17fd-4a47-89a8-cab72d238571	Pull-Up	5	3	5	7.50	0	f	{"totalLoadKg": 80.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
620e4411-9a00-4e02-be9a-1178eca10d79	b0889cb1-17fd-4a47-89a8-cab72d238571	Bench Press	6	1	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
5c6b43ca-9919-48a9-b4e2-b737f96762c8	b0889cb1-17fd-4a47-89a8-cab72d238571	Bench Press	7	2	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
266d1649-0662-4d37-a1a2-f0ba104f3185	b0889cb1-17fd-4a47-89a8-cab72d238571	Bench Press	8	3	5	75.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
604c1abf-39bb-41e3-9013-cd5dc1c2b890	b0889cb1-17fd-4a47-89a8-cab72d238571	Deadlift	9	1	5	80.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
7f23515a-53a9-4b19-b726-54e0d72e5477	b0889cb1-17fd-4a47-89a8-cab72d238571	Overhead Press	10	1	5	40.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
8bebacfe-518c-4b94-aa2e-a9804c43a75f	40444490-586e-47eb-9616-9e55d24ddfcd	Back Squat	0	1	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
f322dde9-f8ba-4079-9a8e-4a78a1124b67	40444490-586e-47eb-9616-9e55d24ddfcd	Back Squat	1	2	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
e085d660-29a8-4256-9a9e-b6ee982af128	40444490-586e-47eb-9616-9e55d24ddfcd	Back Squat	2	3	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
33fa3c82-61db-4a85-8e8f-fb2124578582	40444490-586e-47eb-9616-9e55d24ddfcd	Pull-Up	3	1	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
a8ed75cd-3a5d-4aa6-a80d-d256ac818d86	40444490-586e-47eb-9616-9e55d24ddfcd	Pull-Up	4	2	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
de7a76ca-2d17-45bf-b82e-8d794f4630bb	40444490-586e-47eb-9616-9e55d24ddfcd	Pull-Up	5	3	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
31bca019-5c9d-4de5-a047-6467d61ac88b	40444490-586e-47eb-9616-9e55d24ddfcd	Bench Press	6	1	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
c5030148-801e-4a31-bf4d-2411df589aff	40444490-586e-47eb-9616-9e55d24ddfcd	Bench Press	7	2	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
55d78a74-46c0-44db-8255-a719756fd6ce	40444490-586e-47eb-9616-9e55d24ddfcd	Bench Press	8	3	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
6c397dba-6843-4c4a-83c9-ca6bbc1923c4	40444490-586e-47eb-9616-9e55d24ddfcd	Deadlift	9	1	3	90.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
6ce1b63e-101b-4eea-b124-497196380540	40444490-586e-47eb-9616-9e55d24ddfcd	Overhead Press	10	1	3	45.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
007127cf-f4d6-4d00-8e67-fa5cb9ae4c5c	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Back Squat	0	1	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
5831b1cb-07ac-4154-8304-56a2cb0e1e04	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Back Squat	1	2	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
29aa175b-cde5-4716-b2f3-ed303be6994b	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Back Squat	2	3	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
c13851a5-ad59-40fc-8d62-d008f30820d3	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Pull-Up	3	1	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
48177deb-4686-4633-a025-4b5ca254da1a	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Pull-Up	4	2	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
680ac405-4605-41c8-9f29-47c2c346f3e3	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Pull-Up	5	3	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
11871b2c-248d-49c0-9acf-9a55c8500e0d	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Bench Press	6	1	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
b21b7d2c-5777-4f8b-8bb8-367713c37a14	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Bench Press	7	2	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
04be6539-0254-4d1c-9c34-7da87ab1eb53	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Bench Press	8	3	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
141fcb7e-c5f4-4ac1-8bc7-098a8cd44afd	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Deadlift	9	1	3	90.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
297b8170-0f5a-42e0-9055-cb50fccae3e2	2cd77e22-a0a4-4f33-bbec-9cdcc619c5cd	Overhead Press	10	1	3	45.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
ba473e7f-2042-49f5-9cb3-cd937027cf53	0fe3d7bb-64f3-4668-be04-89470f55d634	Back Squat	0	1	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
88d245d1-c536-418a-ac08-0fb8cea723c4	0fe3d7bb-64f3-4668-be04-89470f55d634	Back Squat	1	2	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
bd00c8a1-501b-4dc0-b9b3-90821ddab033	0fe3d7bb-64f3-4668-be04-89470f55d634	Back Squat	2	3	3	85.00	0	f	{}	4a8f963f-3d37-4245-9954-988f92d83f71
b746d114-6b1f-4e65-b36a-a8f423a7482a	0fe3d7bb-64f3-4668-be04-89470f55d634	Pull-Up	3	1	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
72647e83-067f-4028-96d3-e56161473152	0fe3d7bb-64f3-4668-be04-89470f55d634	Pull-Up	4	2	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
f111a52e-5429-497e-aba0-044ef53cbecb	0fe3d7bb-64f3-4668-be04-89470f55d634	Pull-Up	5	3	3	17.50	0	f	{"totalLoadKg": 90.5, "bodyweightKg": 73}	e5c786ba-7020-4f4c-a533-edbff0ce3413
bdd18417-7a4e-4a70-8a0a-8eed98471cb2	0fe3d7bb-64f3-4668-be04-89470f55d634	Bench Press	6	1	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
59b43a2b-56b9-44dc-b664-f0d22b38a615	0fe3d7bb-64f3-4668-be04-89470f55d634	Bench Press	7	2	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
96c2ecb2-349c-4c2b-a580-0a7607a06ea9	0fe3d7bb-64f3-4668-be04-89470f55d634	Bench Press	8	3	3	85.00	0	f	{}	b61c9129-a96b-46cf-9e13-4ce0a67615f8
ece87d52-4b8a-4106-96dd-a2eec27924bb	0fe3d7bb-64f3-4668-be04-89470f55d634	Deadlift	9	1	3	90.00	0	f	{}	a293c633-5a9c-4126-9914-c4912186f6b7
5424e98c-24ef-4734-b2c8-aa0d8a9559f9	0fe3d7bb-64f3-4668-be04-89470f55d634	Overhead Press	10	1	3	45.00	0	f	{}	bf1a2647-545f-4bdf-b689-e7285bd9dc06
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: app
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 13, true);


--
-- Name: migration_run_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app
--

SELECT pg_catalog.setval('public.migration_run_log_id_seq', 394, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: app
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: exercise_alias exercise_alias_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.exercise_alias
    ADD CONSTRAINT exercise_alias_pkey PRIMARY KEY (id);


--
-- Name: exercise exercise_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT exercise_pkey PRIMARY KEY (id);


--
-- Name: generated_session generated_session_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.generated_session
    ADD CONSTRAINT generated_session_pkey PRIMARY KEY (id);


--
-- Name: migration_run_log migration_run_log_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.migration_run_log
    ADD CONSTRAINT migration_run_log_pkey PRIMARY KEY (id);


--
-- Name: plan plan_id_user_id_uq; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan
    ADD CONSTRAINT plan_id_user_id_uq UNIQUE (id, user_id);


--
-- Name: plan_module plan_module_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_module
    ADD CONSTRAINT plan_module_pkey PRIMARY KEY (id);


--
-- Name: plan_override plan_override_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_override
    ADD CONSTRAINT plan_override_pkey PRIMARY KEY (id);


--
-- Name: plan plan_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan
    ADD CONSTRAINT plan_pkey PRIMARY KEY (id);


--
-- Name: plan_progress_event plan_progress_event_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_progress_event
    ADD CONSTRAINT plan_progress_event_pkey PRIMARY KEY (id);


--
-- Name: plan_runtime_state plan_runtime_state_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_runtime_state
    ADD CONSTRAINT plan_runtime_state_pkey PRIMARY KEY (id);


--
-- Name: program_template program_template_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.program_template
    ADD CONSTRAINT program_template_pkey PRIMARY KEY (id);


--
-- Name: program_version program_version_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.program_version
    ADD CONSTRAINT program_version_pkey PRIMARY KEY (id);


--
-- Name: seed_run_state seed_run_state_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.seed_run_state
    ADD CONSTRAINT seed_run_state_pkey PRIMARY KEY (seed_key);


--
-- Name: stats_cache stats_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.stats_cache
    ADD CONSTRAINT stats_cache_pkey PRIMARY KEY (id);


--
-- Name: user_setting user_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.user_setting
    ADD CONSTRAINT user_setting_pkey PRIMARY KEY (id);


--
-- Name: ux_event_log ux_event_log_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.ux_event_log
    ADD CONSTRAINT ux_event_log_pkey PRIMARY KEY (id);


--
-- Name: workout_log workout_log_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.workout_log
    ADD CONSTRAINT workout_log_pkey PRIMARY KEY (id);


--
-- Name: workout_set workout_set_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.workout_set
    ADD CONSTRAINT workout_set_pkey PRIMARY KEY (id);


--
-- Name: exercise_alias_alias_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX exercise_alias_alias_uq ON public.exercise_alias USING btree (alias);


--
-- Name: exercise_alias_exercise_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX exercise_alias_exercise_idx ON public.exercise_alias USING btree (exercise_id);


--
-- Name: exercise_name_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX exercise_name_uq ON public.exercise USING btree (name);


--
-- Name: generated_session_plan_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX generated_session_plan_idx ON public.generated_session USING btree (plan_id);


--
-- Name: generated_session_plan_session_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX generated_session_plan_session_uq ON public.generated_session USING btree (plan_id, session_key);


--
-- Name: generated_session_user_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX generated_session_user_idx ON public.generated_session USING btree (user_id);


--
-- Name: migration_run_log_run_id_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX migration_run_log_run_id_uq ON public.migration_run_log USING btree (run_id);


--
-- Name: migration_run_log_started_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX migration_run_log_started_idx ON public.migration_run_log USING btree (started_at DESC);


--
-- Name: migration_run_log_status_started_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX migration_run_log_status_started_idx ON public.migration_run_log USING btree (status, started_at DESC);


--
-- Name: plan_module_plan_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_module_plan_idx ON public.plan_module USING btree (plan_id);


--
-- Name: plan_module_plan_target_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX plan_module_plan_target_uq ON public.plan_module USING btree (plan_id, target);


--
-- Name: plan_override_plan_scope_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_override_plan_scope_idx ON public.plan_override USING btree (plan_id, scope);


--
-- Name: plan_override_plan_week_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_override_plan_week_idx ON public.plan_override USING btree (plan_id, week_number);


--
-- Name: plan_progress_event_plan_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_progress_event_plan_idx ON public.plan_progress_event USING btree (plan_id, created_at);


--
-- Name: plan_progress_event_plan_log_slug_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX plan_progress_event_plan_log_slug_uq ON public.plan_progress_event USING btree (plan_id, log_id, program_slug);


--
-- Name: plan_progress_event_user_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_progress_event_user_idx ON public.plan_progress_event USING btree (user_id, created_at);


--
-- Name: plan_runtime_state_plan_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX plan_runtime_state_plan_uq ON public.plan_runtime_state USING btree (plan_id);


--
-- Name: plan_runtime_state_updated_at_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_runtime_state_updated_at_idx ON public.plan_runtime_state USING btree (updated_at);


--
-- Name: plan_runtime_state_user_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_runtime_state_user_idx ON public.plan_runtime_state USING btree (user_id);


--
-- Name: plan_type_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_type_idx ON public.plan USING btree (type);


--
-- Name: plan_user_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX plan_user_idx ON public.plan USING btree (user_id);


--
-- Name: program_template_owner_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX program_template_owner_idx ON public.program_template USING btree (owner_user_id);


--
-- Name: program_template_slug_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX program_template_slug_uq ON public.program_template USING btree (slug);


--
-- Name: program_template_type_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX program_template_type_idx ON public.program_template USING btree (type);


--
-- Name: program_version_template_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX program_version_template_idx ON public.program_version USING btree (template_id);


--
-- Name: program_version_template_version_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX program_version_template_version_uq ON public.program_version USING btree (template_id, version);


--
-- Name: stats_cache_updated_at_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX stats_cache_updated_at_idx ON public.stats_cache USING btree (updated_at);


--
-- Name: stats_cache_user_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX stats_cache_user_idx ON public.stats_cache USING btree (user_id);


--
-- Name: stats_cache_user_metric_params_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX stats_cache_user_metric_params_uq ON public.stats_cache USING btree (user_id, metric, params_hash);


--
-- Name: user_setting_user_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX user_setting_user_idx ON public.user_setting USING btree (user_id);


--
-- Name: user_setting_user_key_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX user_setting_user_key_uq ON public.user_setting USING btree (user_id, key);


--
-- Name: user_setting_user_updated_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX user_setting_user_updated_idx ON public.user_setting USING btree (user_id, updated_at);


--
-- Name: ux_event_log_user_client_event_uq; Type: INDEX; Schema: public; Owner: app
--

CREATE UNIQUE INDEX ux_event_log_user_client_event_uq ON public.ux_event_log USING btree (user_id, client_event_id);


--
-- Name: ux_event_log_user_name_recorded_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX ux_event_log_user_name_recorded_idx ON public.ux_event_log USING btree (user_id, name, recorded_at);


--
-- Name: ux_event_log_user_recorded_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX ux_event_log_user_recorded_idx ON public.ux_event_log USING btree (user_id, recorded_at);


--
-- Name: workout_log_generated_session_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_log_generated_session_idx ON public.workout_log USING btree (generated_session_id);


--
-- Name: workout_log_plan_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_log_plan_idx ON public.workout_log USING btree (plan_id);


--
-- Name: workout_log_user_day_bucket_utc_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_log_user_day_bucket_utc_idx ON public.workout_log USING btree (user_id, date_trunc('day'::text, (performed_at AT TIME ZONE 'UTC'::text)));


--
-- Name: workout_log_user_month_bucket_utc_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_log_user_month_bucket_utc_idx ON public.workout_log USING btree (user_id, date_trunc('month'::text, (performed_at AT TIME ZONE 'UTC'::text)));


--
-- Name: workout_log_user_performed_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_log_user_performed_idx ON public.workout_log USING btree (user_id, performed_at);


--
-- Name: workout_log_user_week_bucket_utc_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_log_user_week_bucket_utc_idx ON public.workout_log USING btree (user_id, date_trunc('week'::text, (performed_at AT TIME ZONE 'UTC'::text)));


--
-- Name: workout_set_exercise_id_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_set_exercise_id_idx ON public.workout_set USING btree (exercise_id);


--
-- Name: workout_set_exercise_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_set_exercise_idx ON public.workout_set USING btree (exercise_name);


--
-- Name: workout_set_exercise_name_lower_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_set_exercise_name_lower_idx ON public.workout_set USING btree (lower(exercise_name));


--
-- Name: workout_set_log_idx; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX workout_set_log_idx ON public.workout_set USING btree (log_id);


--
-- Name: exercise_alias exercise_alias_exercise_id_exercise_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.exercise_alias
    ADD CONSTRAINT exercise_alias_exercise_id_exercise_id_fk FOREIGN KEY (exercise_id) REFERENCES public.exercise(id) ON DELETE CASCADE;


--
-- Name: generated_session generated_session_plan_id_plan_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.generated_session
    ADD CONSTRAINT generated_session_plan_id_plan_id_fk FOREIGN KEY (plan_id) REFERENCES public.plan(id) ON DELETE CASCADE;


--
-- Name: generated_session generated_session_plan_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.generated_session
    ADD CONSTRAINT generated_session_plan_user_fk FOREIGN KEY (plan_id, user_id) REFERENCES public.plan(id, user_id) ON DELETE CASCADE;


--
-- Name: plan_module plan_module_plan_id_plan_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_module
    ADD CONSTRAINT plan_module_plan_id_plan_id_fk FOREIGN KEY (plan_id) REFERENCES public.plan(id) ON DELETE CASCADE;


--
-- Name: plan_module plan_module_program_version_id_program_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_module
    ADD CONSTRAINT plan_module_program_version_id_program_version_id_fk FOREIGN KEY (program_version_id) REFERENCES public.program_version(id) ON DELETE RESTRICT;


--
-- Name: plan_override plan_override_plan_id_plan_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_override
    ADD CONSTRAINT plan_override_plan_id_plan_id_fk FOREIGN KEY (plan_id) REFERENCES public.plan(id) ON DELETE CASCADE;


--
-- Name: plan_progress_event plan_progress_event_log_id_workout_log_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_progress_event
    ADD CONSTRAINT plan_progress_event_log_id_workout_log_id_fk FOREIGN KEY (log_id) REFERENCES public.workout_log(id) ON DELETE CASCADE;


--
-- Name: plan_progress_event plan_progress_event_plan_id_plan_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_progress_event
    ADD CONSTRAINT plan_progress_event_plan_id_plan_id_fk FOREIGN KEY (plan_id) REFERENCES public.plan(id) ON DELETE CASCADE;


--
-- Name: plan plan_root_program_version_id_program_version_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan
    ADD CONSTRAINT plan_root_program_version_id_program_version_id_fk FOREIGN KEY (root_program_version_id) REFERENCES public.program_version(id) ON DELETE RESTRICT;


--
-- Name: plan_runtime_state plan_runtime_state_plan_id_plan_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.plan_runtime_state
    ADD CONSTRAINT plan_runtime_state_plan_id_plan_id_fk FOREIGN KEY (plan_id) REFERENCES public.plan(id) ON DELETE CASCADE;


--
-- Name: program_version program_version_template_id_program_template_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.program_version
    ADD CONSTRAINT program_version_template_id_program_template_id_fk FOREIGN KEY (template_id) REFERENCES public.program_template(id) ON DELETE CASCADE;


--
-- Name: workout_log workout_log_generated_session_id_generated_session_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.workout_log
    ADD CONSTRAINT workout_log_generated_session_id_generated_session_id_fk FOREIGN KEY (generated_session_id) REFERENCES public.generated_session(id) ON DELETE SET NULL;


--
-- Name: workout_log workout_log_plan_id_plan_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.workout_log
    ADD CONSTRAINT workout_log_plan_id_plan_id_fk FOREIGN KEY (plan_id) REFERENCES public.plan(id) ON DELETE SET NULL;


--
-- Name: workout_set workout_set_exercise_id_exercise_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.workout_set
    ADD CONSTRAINT workout_set_exercise_id_exercise_id_fk FOREIGN KEY (exercise_id) REFERENCES public.exercise(id) ON DELETE SET NULL;


--
-- Name: workout_set workout_set_log_id_workout_log_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.workout_set
    ADD CONSTRAINT workout_set_log_id_workout_log_id_fk FOREIGN KEY (log_id) REFERENCES public.workout_log(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict CAcqSgXkxBNyFYuZmh4uWDdhS4Ar6f5ZxdVXYp5Ddh5zMfFrFNUeJNSaNYEzVmk

